package com.example.stores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MoreOnlineImagesAdapter extends RecyclerView.Adapter<MoreOnlineImagesAdapter.imageViewHolder> {

    Context context;
    ArrayList<MoreOnlineImages>moreOnlineImagesArrayList;

    public MoreOnlineImagesAdapter(Context context, ArrayList<MoreOnlineImages>moreOnlineImagesArrayList) {
        this.context = context;
        this.moreOnlineImagesArrayList = moreOnlineImagesArrayList;
    }

    @NonNull
    @Override
    public imageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.more_category_support_layout,parent,false);

        return new imageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull imageViewHolder holder, int position) {
        MoreOnlineImages moreonlineImages = moreOnlineImagesArrayList.get(position);
        holder.imageTitle.setText(moreonlineImages.getMoreTitle());

        String imgurl;
        imgurl=moreonlineImages.getMoreImage();
        Picasso.get().load(imgurl).into(holder.moreOnlineImageView);

    }

    @Override
    public int getItemCount() {
        return moreOnlineImagesArrayList.size();
    }

    public class imageViewHolder extends RecyclerView.ViewHolder{

        ImageView moreOnlineImageView;
        TextView imageTitle;
        public imageViewHolder(@NonNull View itemView) {
            super(itemView);

            moreOnlineImageView= itemView.findViewById(R.id.MoreOnlineImage);
            imageTitle=itemView.findViewById(R.id.MoreTitleName);
        }
    }
}
