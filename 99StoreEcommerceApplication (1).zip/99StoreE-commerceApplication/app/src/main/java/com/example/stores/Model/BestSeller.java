package com.example.stores.Model;

public class BestSeller {

//    private int image;

    private String offer;

    private String image2;

    public BestSeller(String offer, String image2){
      //  this.image = image;
        this.offer = offer;
        this.image2 = image2;
    }

//    public int getImage() {
//        return image;
//    }

    public String getOffer() {
        return offer;
    }
    public String getImage2() {
        return image2;
    }
}
