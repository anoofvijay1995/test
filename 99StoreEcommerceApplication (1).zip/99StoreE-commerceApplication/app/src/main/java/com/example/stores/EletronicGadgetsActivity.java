package com.example.stores;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class EletronicGadgetsActivity extends AppCompatActivity {

    static ViewPager viewPager1;
    static TabLayout tabLayout1;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eletronic_gadgets);

        viewPager1 = (ViewPager) findViewById(R.id.viewpager);
        tabLayout1 = (TabLayout) findViewById(R.id.tabs);

        if (viewPager1 != null) {
            setupViewPager(viewPager1);
            tabLayout1.setupWithViewPager(viewPager1);
        }



    }
    @Override
    protected void onResume() {
        super.onResume();
        invalidateOptionsMenu();
    }

    private void setupViewPager(ViewPager viewPager) {
        Adapter adapter = new EletronicGadgetsActivity.Adapter(getSupportFragmentManager());
        ElectronicGadgetsFragment fragment = new ElectronicGadgetsFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("type", 1);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_17));
        viewPager.setAdapter(adapter);
        fragment = new ElectronicGadgetsFragment();
        bundle = new Bundle();
        bundle.putInt("type", 2);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_18));
        viewPager.setAdapter(adapter);

        fragment = new ElectronicGadgetsFragment();
        bundle = new Bundle();
        bundle.putInt("type", 3);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_19));
        viewPager.setAdapter(adapter);
        fragment = new ElectronicGadgetsFragment();
        bundle = new Bundle();
        bundle.putInt("type", 4);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_20));
        viewPager.setAdapter(adapter);

        fragment = new ElectronicGadgetsFragment();
        bundle = new Bundle();
        bundle.putInt("type", 4);
        fragment.setArguments(bundle);
        adapter.addFragment(fragment, getString(R.string.item_21));
        viewPager.setAdapter(adapter);
    }

    static class Adapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragments = new ArrayList<>();
        private final List<String> mFragmentTitles = new ArrayList<>();

        public Adapter(FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment fragment, String title) {
            mFragments.add(fragment);
            mFragmentTitles.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            return mFragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitles.get(position);
        }
    }

}