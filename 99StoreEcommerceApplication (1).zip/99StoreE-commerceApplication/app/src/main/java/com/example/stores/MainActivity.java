package com.example.stores;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.stores.Adapter.BestSellerAdapter;
import com.example.stores.Adapter.ClothingAdapter;
import com.example.stores.Adapter.OfferAdapter;
import com.example.stores.Adapter.The_Slide_items_Pager_Adapter;
import com.example.stores.Model.BestSeller;
import com.example.stores.Model.Clothing;
import com.example.stores.Model.The_Slide_Items_Model_Class;
import com.google.android.material.badge.BadgeDrawable;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    //BOTTOM NAVIGATION

    BottomNavigationView bottomNavigationView;
    HomeFragment fragmentHome = new HomeFragment();
    StoreFragment storeFragment = new StoreFragment();
    NotificationFragment notificationFragment = new NotificationFragment();
    AccountFragment fragmentAccount = new AccountFragment();
    CartFragment cartFragment = new CartFragment();

    public static int notificationCountCart = 0;
//
////    RECYLERVIEWS
//    private RecyclerView offerRecyclerView , bestSellerRecyclerView , clothingRecyclerView , bestSellerRecyclerView2;
//
//    private List<The_Slide_Items_Model_Class> listItems;
//
//    //LINEARLAYOUTS
//    LinearLayout linearLayout,linearLayout1,linearLayout3,linearLayout4,linearLayout5,linearLayout6,linearLayout7,linearLayout8,linearLayout9,linearLayout10,
//            linearLayout11,linearLayout12,linearLayout13,linearLayout14,linearLayout15,linearLayout16,linearLayout17,linearLayout18,linearLayout19,linearLayout20;
//    private ViewPager page;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        getSupportActionBar().setLogo(R.drawable.logo);
//        getSupportActionBar().setDisplayUseLogoEnabled(true);

////        linearLayout = findViewById(R.id.viewMoviesIcon);
//        linearLayout1 = findViewById(R.id.viewMoviesIcon2);
//        linearLayout3 = findViewById(R.id.viewSportsIcon2);
//        linearLayout4 = findViewById(R.id.viewMusicIcon2);
//        linearLayout5 = findViewById(R.id.viewseeIcon2);
//        linearLayout6 = findViewById(R.id.foot2);
//        linearLayout7 = findViewById(R.id.watch2);
//        linearLayout8 = findViewById(R.id.sports2);
//        linearLayout9 = findViewById(R.id.viewActivitiesIcon2);
//        linearLayout10 = findViewById(R.id.viewMoviesIcon);
//        linearLayout11 = findViewById(R.id.viewSportsIcon);
//        linearLayout12 = findViewById(R.id.viewMusicIcon);
//        linearLayout13 = findViewById(R.id.viewActivitiesIcon);
//        linearLayout14 = findViewById(R.id.HomeCeremony);
//       linearLayout15 = findViewById(R.id.BirthdayCeremony);
//       linearLayout16 = findViewById(R.id.MarriagesCeremony);
//       linearLayout17 = findViewById(R.id.viewseeIcon);
//       linearLayout18 = findViewById(R.id.watch);
//       linearLayout19 = findViewById(R.id.foot);
//       linearLayout20 = findViewById(R.id.sports);
//
//
//
//
//
////        linearLayout.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                startActivity(new Intent(getApplicationContext(),GroceryActivity.class));
////            }
////        });
//
//        linearLayout1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),PaintingServicesActivity.class));
//            }
//        });
//
//        linearLayout3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),CarpenterServicesActivity.class));
//            }
//        });
//
//
//        linearLayout4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),PlumbingServicesActivity.class));
//            }
//        });
//
//
//        linearLayout5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),CLeaningServicesActivity.class));
//            }
//        });
//
//
//        linearLayout6.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),CivilWorkServicesActivity.class));
//            }
//        });
//
//
//        linearLayout7.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),LandSalesActivity.class));
//            }
//        });
//
//
//        linearLayout8.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),RentsActivity.class));
//            }
//        });
//
//
//        linearLayout9.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),ElectricServicesActivity.class));
//            }
//        });
//
//
//
//        linearLayout10.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),GroceryActivity.class));
//            }
//        });
//
//
//
//        linearLayout11.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),EletronicGadgetsActivity.class));
//            }
//        });
//
//
//        linearLayout12.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),ClothingActivity.class));
//            }
//        });
//
//
//
//        linearLayout13.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),HomeAppliances.class));
//            }
//        });
//
//
//        linearLayout14.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),HomeCeremonyActivity.class));
//            }
//        });
//
//        linearLayout15.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),BirthdayCeremonyActivity.class));
//            }
//        });
//
//        linearLayout16.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),MarraigeActivity.class));
//            }
//        });
//
//        linearLayout17.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),ToysActivity.class));
//            }
//        });
//
//        linearLayout17.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),ToysActivity.class));
//            }
//        });
//        linearLayout17.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),ToysActivity.class));
//            }
//        });
//
//
//        linearLayout18.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),WatchesAndBagssActivity.class));
//            }
//        });
//
//
//        linearLayout19.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),FootWearActivity.class));
//            }
//        });
//
//        linearLayout20.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(getApplicationContext(),SportsActivity.class));
//            }
//        });
//
//        /// offer RecyclerView
//        offerRecyclerView = findViewById(R.id.offerRecyclerView);
//        page = findViewById(R.id.my_pager);
//
//        listItems = new ArrayList<>() ;
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner1,"Slider 1 Title"));
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner2,"Slider 2 Title"));
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner3,"Slider 3 Title"));
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner5,"Slider 4 Title"));
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner7,"Slider 5 Title"));
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner9,"Slider 6 Title"));
//        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner10,"Slider 7 Title"));
//
//        The_Slide_items_Pager_Adapter itemsPager_adapter = new The_Slide_items_Pager_Adapter(this, listItems);
//        page.setAdapter(itemsPager_adapter);
//
//        offerRecyclerView.setHasFixedSize(true);
//        offerRecyclerView.setLayoutManager(new LinearLayoutManager(this , LinearLayoutManager.HORIZONTAL , false));
//
//        List<Integer> imageList = new ArrayList<>();
//
//        imageList.add(R.drawable.offer_shoping);
//        imageList.add(R.drawable.nikon_canon_offer);
//        imageList.add(R.drawable.tv_offer);
//
//        OfferAdapter offerAdapter = new OfferAdapter(imageList);
//
//        offerRecyclerView.setAdapter(offerAdapter);
//
//        // best RecyclerView
//
//        bestSellerRecyclerView = findViewById(R.id.bestSellerRecyclerview);
//        bestSellerRecyclerView.setHasFixedSize(true);
//        bestSellerRecyclerView.setLayoutManager(new LinearLayoutManager(this , LinearLayoutManager.HORIZONTAL , false));
//
//        List<BestSeller> bestSellerList = new ArrayList<>();
//
//        bestSellerList.add(new BestSeller("Up to 20% off", "https://static.langimg.com/thumb/94637799/grocery-items-on-amazon-94637799.jpg?imgsize=104346&width=540&height=405&resizemode=75"));
//        bestSellerList.add(new BestSeller("Up to 20% off" , "https://drive.google.com/uc?export=view&id=1ZHjvewZBU5H2I-VybTq0T7PqY4OE6ZH6"));
//        bestSellerList.add(new BestSeller("Up to 20% off" , "https://drive.google.com/uc?export=view&id=1vIfgFff-2NZDR-4C1qyfpPYg8BB4cOPr"));
//
//        BestSellerAdapter bestSellerAdapter = new BestSellerAdapter(bestSellerList);
//
//        bestSellerRecyclerView.setAdapter(bestSellerAdapter);
//
//
//        // clothing RecyclerView
//
//        clothingRecyclerView = findViewById(R.id.clothingRecyclerview);
//        clothingRecyclerView.setHasFixedSize(true);
//        clothingRecyclerView.setLayoutManager(new LinearLayoutManager(this , LinearLayoutManager.HORIZONTAL , false));
//
//        List<Clothing> clothingList = new ArrayList<>();
//
//        clothingList.add(new Clothing(R.drawable.levis_clothing , "Up to 30% off"));
//        clothingList.add(new Clothing(R.drawable.women_clothing , "Up to 30% off"));
//        clothingList.add(new Clothing(R.drawable.nikeshoes , "Up to 30% off"));
//
//        ClothingAdapter clothingAdapter = new ClothingAdapter(clothingList);
//        clothingRecyclerView.setAdapter(clothingAdapter);
//
//        // best RecyclerView 2
//
//        bestSellerRecyclerView2 = findViewById(R.id.bestSeller2RecyclerView);
//        bestSellerRecyclerView2.setHasFixedSize(true);
//        bestSellerRecyclerView2.setLayoutManager(new LinearLayoutManager(this , LinearLayoutManager.HORIZONTAL , false));
//
//        bestSellerRecyclerView2.setAdapter(bestSellerAdapter);





        bottomNavigationView  = findViewById(R.id.bottom_navigation);
        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragmentHome).commit();

//        BadgeDrawable badgeDrawable = bottomNavigationView.getOrCreateBadge(R.id.notification);
//        badgeDrawable.setVisible(true);
        ;

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
//                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragmentHome).commit();
                        return true;
                    case R.id.store:
//                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,storeFragment).commit();
                        return true;
                    case R.id.notification:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,notificationFragment).commit();
                        return true;

                    case R.id.accont:

                        getSupportFragmentManager().beginTransaction().replace(R.id.container,fragmentAccount).commit();
                        return true;

                }

                return false;
            }
        });



    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater =new MenuInflater(getApplicationContext());
        inflater.inflate(R.menu.menu2,menu);
        return true;
    }


    public boolean onPrepareOptionsMenu(Menu menu) {
        // Get the notifications MenuItem and
        // its LayerDrawable (layer-list)
        MenuItem item = menu.findItem(R.id.cart);
//        NotificationCountSetClass.setAddToCart(MainActivity.this, item,notificationCountCart);
        // force the ActionBar to relayout its MenuItems.
        // onCreateOptionsMenu(Menu) will be called again.
        invalidateOptionsMenu();
        return super.onPrepareOptionsMenu(menu);
    }


    @SuppressLint("NonConstantResourceId")
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search:
                Toast.makeText(getApplicationContext(), "Shows search icon", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(this, PopupActivity.class);
//                intent.putExtra("STRING_KEY", "search");
//                startActivity(intent);
                return true;

            case R.id.Favourite:
                getSupportFragmentManager().beginTransaction().replace(R.id.container,notificationFragment).commit();
//                intent = new Intent(this, PopupActivity.class);
//                intent.putExtra("STRING_KEY", "share");
//                startActivity(intent);
                return true;

            case R.id.Cart:
                getSupportFragmentManager().beginTransaction().replace(R.id.container,cartFragment).commit();
//                intent = new Intent(this, PopupActivity.class);
//                intent.putExtra("STRING_KEY", "delete");
//                startActivity(intent);
//                return true;
                return true;

        }
        return (super.onOptionsItemSelected(item));
    }
}