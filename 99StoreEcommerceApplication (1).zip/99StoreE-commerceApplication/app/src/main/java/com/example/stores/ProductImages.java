package com.example.stores;

public class ProductImages {

    String image, productName, ProductPrice,ProductDesc;

    public ProductImages(String image, String productName, String productPrice, String productDesc) {
        this.image = image;
        this.productName = productName;
        ProductPrice = productPrice;
        ProductDesc = productDesc;



    }


    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(String productPrice) {
        ProductPrice = productPrice;
    }

    public String getProductDesc() {
        return ProductDesc;
    }

    public void setProductDesc(String productDesc) {
        ProductDesc = productDesc;
    }
}