package com.example.stores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class OnlineImagesAdapter extends RecyclerView.Adapter<OnlineImagesAdapter.imageViewHolder> {

    Context context;
    ArrayList<OnlineImages>imagesArrayList;

    public OnlineImagesAdapter(Context context, ArrayList<OnlineImages> productImagesArrayList) {
        this.context = context;
        this.imagesArrayList = productImagesArrayList;
    }

    @NonNull
    @Override
    public imageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_support_layout,parent,false);

        return new imageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull imageViewHolder holder, int position) {
        OnlineImages onlineImages = imagesArrayList.get(position);
        holder.imageTitle.setText(onlineImages.getTitle());

        String imgurl;
        imgurl=onlineImages.getImage();
        Picasso.get().load(imgurl).into(holder.onlineImageView);

    }

    @Override
    public int getItemCount() {
        return imagesArrayList.size();
    }

    public class imageViewHolder extends RecyclerView.ViewHolder{

        ImageView onlineImageView;
        TextView imageTitle;
        public imageViewHolder(@NonNull View itemView) {
            super(itemView);

            onlineImageView= itemView.findViewById(R.id.onlineImage);
            imageTitle=itemView.findViewById(R.id.TitleName);
        }
    }
}
