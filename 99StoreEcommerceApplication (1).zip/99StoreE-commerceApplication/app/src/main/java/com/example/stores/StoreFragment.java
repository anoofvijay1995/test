package com.example.stores;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link StoreFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StoreFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    Context context;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public StoreFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment StoreFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static StoreFragment newInstance(String param1, String param2) {
        StoreFragment fragment = new StoreFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view;
        view = inflater.inflate(R.layout.fragment_store, null);


        //RECYLERVIEW2  products

        RecyclerView recyclerView2,recyclerView;
        ProductsImagesAdapter adapter2;
        ArrayList<ProductImages> productImagesArrayList;
        recyclerView2 = view.findViewById(R.id.recyclerView2);



//        THIS IS FOR CATEGORY PART DECLARATION

        OnlineImagesAdapter adapter;
        ArrayList<OnlineImages> imagesArrayList;
        recyclerView = view.findViewById(R.id.recyclerView);

        // THIS IS MORE CATEGORY PART DECLARATION

        RecyclerView recyclerView3;
        MoreOnlineImagesAdapter adapter3;
        ArrayList<MoreOnlineImages> moreOnlineImagesArrayList;
        recyclerView3 = view.findViewById(R.id.recyclerView3);



        productImagesArrayList = new ArrayList<>();

        String imageurl0 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Electronics+and+gadgets.png/e3.png";
        String imageurl12 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Electronics+and+gadgets.png/e4.png";
        String imageurl13 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/clothing.png/c5.png";
        String imageurl14 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Home+Furnitures/h6.png";
        String imageurl15 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Home+Furnitures/h2.png";
        String imageurl16 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Toys/t2.png";
        String imageurl17 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Toys/t12.jpg";
        String imageurl18 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Footwears/f11.png";
        String imageurl19 = "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Watchs%2CBags%2CWallets%2CLuggage/w1.jpg";


        productImagesArrayList.add(new ProductImages(imageurl0, "I Phone - 13 Pro Max", "57,999", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl12, "Apple AirPods(2nd gen)", "9999", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl13, "Kid Wear", "2000", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl14, "Sofa", "25000", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl15, "IFB Washing Machine", "18000", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl16, "Horse Toy", "699", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl17, "Aeroplane Toy", "990", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl18, "Causal Shoe For Men", "999", "30%off"));
        productImagesArrayList.add(new ProductImages(imageurl19, "Fossil Watch", "3699", "30%off"));


        recyclerView2.setLayoutManager(new GridLayoutManager(context,2));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,true));
        adapter2= new ProductsImagesAdapter(context,productImagesArrayList,new StoreFragment());
        recyclerView2.setAdapter(adapter2);


        imagesArrayList=new ArrayList<>();
        String imageurl1="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/HomePaintingServices/hp4.png";
        String imageurl2="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/carpenter/car8.png";
        String imageurl3="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/PlumbingService/ps9.png";
        String imageurl4="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/ElectricService/es2.png";
        String imageurl5="https://images010.s3.ap-south-1.amazonaws.com/Extra+Images+Cat+B/Carpet-Cleaning-Dublin.jpeg";
        String imageurl6="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/Civil+Work+Service/cws9.png";
        String imageurl7="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/Rents/rent9.png";
        String imageurl8="https://images010.s3.ap-south-1.amazonaws.com/Cat+B/Rents/rent3.png";
//        String imageurl9="https://drive.google.com/uc?export=view&id=1qgtpkO-O114luiJ744WkCWeDz2qt7R-n";
//        String imageurl10="https://drive.google.com/uc?export=view&id=/1fQgU77SgvLQDsm_BH-w3yr2vnVg8SKsK";
//        String imageurl11="https://drive.google.com/file/d/1fQgU77SgvLQDsm_BH-w3yr2vnVg8SKsK/view?usp=share_link";

        imagesArrayList.add(new OnlineImages(imageurl1,"Home Painting Service"));
        imagesArrayList.add(new OnlineImages(imageurl2,"Carpenter Services"));
        imagesArrayList.add(new OnlineImages(imageurl3,"Plumbing Services"));
        imagesArrayList.add(new OnlineImages(imageurl4,"Electric Service"));
        imagesArrayList.add(new OnlineImages(imageurl5,"Cleaning Service"));
        imagesArrayList.add(new OnlineImages(imageurl6,"Civil Work Service"));
        imagesArrayList.add(new OnlineImages(imageurl7,"Land Sales"));
        imagesArrayList.add(new OnlineImages(imageurl8,"Rent"));



        recyclerView.setLayoutManager(new GridLayoutManager(context,4));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,true));
        adapter= new OnlineImagesAdapter(context,imagesArrayList);
        recyclerView.setAdapter(adapter);



//this is to initialize for the more category

        moreOnlineImagesArrayList=new ArrayList<>();
        String imageurl00="https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Birthday/b11_prev_ui.png";
        String imageurl32="https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Home/hd20.png";
        String imageurl33="https://i.pinimg.com/originals/a1/7d/94/a17d94dd3786e5ebdb1b9ac7d1830d2a.jpg";
//        String imageurl34="https://drive.google.com/uc?export=view&id=17bJn-wHLynyN39mZ6ibbCBBpJfbBosRe";
//        String imageurl35="https://drive.google.com/uc?export=view&id=1NBCofirAFkS7hU4aC9gA9uyPEErzH9Gy";
//        String imageurl36="https://drive.google.com/uc?export=view&id=1rBm1F7muM7aStJf8eDdoVvwepzc8uPPH";
//        String imageurl37="https://drive.google.com/uc?export=view&id=1fQgU77SgvLQDsm_BH-w3yr2vnVg8SKsK";
//        String imageurl38="https://drive.google.com/uc?export=view&id=1uxyMisbbuw2d_IQjfyTyzkdceIxGTypX";
//        String imageurl39="https://thumbs.dreamstime.com/b/kids-celebrating-birthday-party-blowing-group-joyful-little-candles-cake-holidays-concept-48869522.jpg";
//        String imageurl40="https://drive.google.com/uc?export=view&id=/1fQgU77SgvLQDsm_BH-w3yr2vnVg8SKsK";
//        String imageurl41="https://drive.google.com/file/d/1fQgU77SgvLQDsm_BH-w3yr2vnVg8SKsK/view?usp=share_link";


        moreOnlineImagesArrayList.add(new MoreOnlineImages(imageurl00,"Birthday Ceremony"));
        moreOnlineImagesArrayList.add(new MoreOnlineImages(imageurl32,"Home Ceremony"));
        moreOnlineImagesArrayList.add(new MoreOnlineImages(imageurl33,"Marriages"));


        recyclerView3.setLayoutManager(new GridLayoutManager(context,4));
//        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,true));
        adapter3= new MoreOnlineImagesAdapter(context,moreOnlineImagesArrayList);
        recyclerView3.setAdapter(adapter3);


        return view;

    }
}