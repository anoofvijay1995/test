package com.example.stores;

import java.util.ArrayList;




public class ImageUrlUtils {
    static ArrayList<String> wishlistImageUri = new ArrayList<>();
    static ArrayList<String> cartListImageUri = new ArrayList<>();

    public static String[] getImageUrls() {
        String[] urls = new String[] {
                "https://static.pexels.com/photos/5854/sea-woman-legs-water-medium.jpg",
                "https://static.pexels.com/photos/6245/kitchen-cooking-interior-decor-medium.jpg",
                "https://static.pexels.com/photos/6770/light-road-lights-night-medium.jpg",
                "https://static.pexels.com/photos/6041/nature-grain-moving-cereal-medium.jpg",
                "https://static.pexels.com/photos/7116/mountains-water-trees-lake-medium.jpg",
                "https://static.pexels.com/photos/6601/food-plate-yellow-white-medium.jpg",
                "https://static.pexels.com/photos/6695/summer-sun-yellow-spring-medium.jpg",
                "https://static.pexels.com/photos/7117/mountains-night-clouds-lake-medium.jpg",
                "https://static.pexels.com/photos/7262/clouds-ocean-seagull-medium.jpg",
                "https://static.pexels.com/photos/5968/wood-nature-dark-forest-medium.jpg"
        };
        return urls;
    }

    public static String[] getImagenames(){
        String[] names = new String[]{
                "name1",
                "name2",
                "name3",
                "name4",
                "name5",
                "name6",
                "name7",
                "name8",
                "name9",
                "name10"

        };
        return names;
    }
    public static String[] getProductdescriptions(){
        String[] desc = new String[]{
                "desc1",
                "desc2",
                "desc3",
                "desc4",
                "desc5",
                "desc6",
                "desc7",
                "desc8",
                "desc9",
                "desc10"

        };
        return desc;
    }

    public static String[] getProductprice(){
        String[] price = new String[]{
                "2000",
                "3300",
                "2000",
                "3300",
                "2000",
                "3300",
                "2000",
                "3300",
                "2000",
                "3300"

        };
        return price;
    }



    //PAINTING SERVICES

    public static String[] getPaintingServicesUrls() {
        String[] urls = new String[] {
                "https://media.istockphoto.com/id/938085736/photo/workamn-painting-wall-indoors.jpg?b=1&s=170667a&w=0&k=20&c=uA5IcGgpfAq8NS2Gn8FFI3rRv9PS0qzxhe5J62e1gdE=",
                "https://www.bergerpaints.com/blog/wp-content/uploads/2021/11/Berger-Express-Painting-service-.png",
//                "https://media.istockphoto.com/id/942126458/photo/young-man-painting-a-wall-blue-with-a-roller.jpg?s=612x612&w=0&k=20&c=d2W87XKCwKzFsCkZ2nTJF8LZSAMKhCRSvu_Gno676Qg=",
//                "https://lirp.cdn-website.com/96d0074c/dms3rep/multi/opt/1198703852-640w.jpg",
//               "https://www.evershineuae.net/drv_images/cities/4b903d7e3d7566dcc6d650decc43a724.jpg",
//               "https://5.imimg.com/data5/SELLER/Default/2020/8/MJ/OE/YC/13522507/wall-paint-services-roorkee-500x500.jpg",

        };
        return urls;
    }

    public static String[] getPaintingServicesnames(){
        String[] names = new String[]{
                "Painting",
                "Painting1",
                //  "Painting2",
//                "Painting",
//                "Painting",
//                "Painting",




        };
        return names;
    }
    public static String[] getPaintingServicesdescriptions(){
        String[] desc = new String[]{
                "30% Off",
                "30% Off",
                //  "30% Off",
//                "30% Off",
//                "30% Off",
//                "30% Off",

        };
        return desc;
    }

    public static String[] getPaintingServicesprice(){
        String[] price = new String[]{
                "15000",
                "3300",
                //     "2000",
//                "3300",
//                "2000",
//                "3300",


        };
        return price;
    }

    //CARPENTER SERVICES


    public static String[] getCarpenterServicesUrls() {
        String[] urls = new String[] {

                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBkTYqqWVwBcfNlyRIby0WeOUqL-Z0yzExbQ&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTCg3t2YSFrZja241DFCZJFaQmLHj02SxQv_mkGW80WyRR0CZfb1XeAiwmNEjGtygDZmRo&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNZABbjsYw64jXQ_ziLKAWMk1zVeFwenV-q1a3oYT7ftPn3dwPpUozNN1UJBqVmI_0Tzc&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTScc8SpMtwPkoaW8yErp0KbZ2KPd3di3vRlw&usqp=CAU" ,
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTiHACNzfKPXumcdMi_EB5SsaD1BckYnaQYig&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTWowsG95BFy_vU8DMjYwMBhlzYB4xfIHgCpw&usqp=CAU",

        };
        return urls;
    }

    public static String[] getCarpenterServicesnames(){
        String[] names = new String[]{
                "Bed Assembly",
                "Chair Installation",
                "Chair Repair",
                "Home Fixing",
                "Home Roof Fixing",
                "Home Walls Fixing",
//

        };
        return names;
    }
    public static String[] getCarpenterServicesdescriptions(){
        String[] desc = new String[]{
                "Upto 20%",
                "Upto 30%",
                "Upto 30%",
                "Upto 10%",
                "Upto 3%",
                "Upto 20%",
//

        };
        return desc;
    }

    public static String[] getCarpenterServicesprice(){
        String[] price = new String[]{
                "1000",
                "500",
                "1100",
                "1500",
                "1000",
                "1500",
//

        };
        return price;
    }


    //PLUMBING SERVICES


    public static String[] getPLumbingServicesUrls() {
        String[] urls = new String[] {
                "https://media.istockphoto.com/id/529770683/photo/young-plumber-with-clip-board.jpg?b=1&s=170667a&w=0&k=20&c=87_rFmS7T0Jz-0KMylEau1mHAMVfY6lH1EPRjzgjC_k=",
                "https://procrewschedule.com/wp-content/uploads/2020/06/plumber-at-work-in-a-bathroom-1024x683-1.jpg",
                "https://www.servicemasterbylovejoy.com/wp-content/uploads/2020/09/Article-2.jpg",
                "https://savvyplumbing.co.za/wp-content/uploads/2020/12/plumbing-services.jpeg",
                "https://media.istockphoto.com/id/1339613829/photo/plumber-at-work-in-a-bathroom-plumbing-repair-service-assemble-and-install-concept.jpg?s=612x612&w=0&k=20&c=lQREIzjwRM3ApTkRzTnbIA_BCRCy_ER-e51tofKsaP0=",
                "https://images.aboutmechanics.com/slideshow-mobile-small/plumber-installing-fixture.jpg",
//

        };
        return urls;
    }

    public static String[] getPlumbingServicesnames(){
        String[] names = new String[]{
                "WashBasin Repair",
                "Geyser",
                "yuagahd",
                "ada",
                "acaa",
                "asavav",

//

        };
        return names;
    }
    public static String[] getPlumbingServicesdescriptions(){
        String[] desc = new String[]{
                "Installation",
                "Fixing",
                "Fixing",
                "Fixing",
                "Fixing",
                "Fixing",
//
//

        };
        return desc;
    }

    public static String[] getPlumbingServicesprice(){
        String[] price = new String[]{
                "1500",
                "1000",
                "1000",
                "1000",
                "1000",
                "1000",


        };
        return price;
    }


    //ELECTRIC SERVICES


    public static String[] getElectricServicesUrls() {
        String[] urls = new String[] {
                "https://media.istockphoto.com/id/1049769264/photo/handsome-cheerful-electrician-repairing-electrical-box-and-using-screwdriver-in-corridor.jpg?s=612x612&w=0&k=20&c=UWetTfmbbhhESFo7vmFgIiQjWmJGZ8mrX5s3hhjJH2I=",
                "https://media.istockphoto.com/id/1212509449/photo/electrician-measurements-with-multimeter-testing-current-electric-in-control-panel.jpg?s=612x612&w=0&k=20&c=j-c-bvUXa3-uGYFT3RicGIbozMg5YrF4enXZ8Rc101M=",
                "https://wilshirerefrigeration.com/wp-content/uploads/2020/05/Service-technician-refrigerator-appliance-repair.jpg",
                "https://media.istockphoto.com/id/1263134450/photo/electrician-man-worker-installing-ceiling-lamp.jpg?s=612x612&w=0&k=20&c=Z2Kn_Q0CDZ73805CFViSedwAiW2QkrKB2LusnEAe2BA=",
                "https://clareservices.com/wp-content/uploads/2020/07/air-conditioning-repair-service-hyderabad.jpg",


        };
        return urls;
    }

    public static String[] getElectricServicesnames(){
        String[] names = new String[]{
                "TV",
                "Fan Repair",
                "Fan Repair1",
                "Fan Repair2",
                "Fan Repair",


        };
        return names;
    }
    public static String[] getElectricServicesdescriptions(){
        String[] desc = new String[]{
                "Display Problem",
                "Repair1",
                "Repair2",
                "Repair3",
                "Repair4",


        };
        return desc;
    }

    public static String[] getElectricServicesprice(){
        String[] price = new String[]{
                "2000",
                "300",
                "300",
                "300",
                "300",


        };
        return price;
    }



    // CLEANING SERVICES



    public static String[] getCleaningServicesUrls() {
        String[] urls = new String[] {
                "https://images010.s3.ap-south-1.amazonaws.com/Extra+Images+Cat+B/ac-repair.jpg",
                "https://shttps://images010.s3.ap-south-1.amazonaws.com/Extra+Images+Cat+B/Carpet-Cleaning-Dublin.jpegtatic.pexels.com/photos/6245/kitchen-cooking-interior-decor-medium.jpg",
//                "https://static.pexels.com/photos/6770/light-road-lights-night-medium.jpg",
//                "https://static.pexels.com/photos/6041/nature-grain-moving-cereal-medium.jpg",
//                "https://static.pexels.com/photos/7116/mountains-water-trees-lake-medium.jpg",
//                "https://static.pexels.com/photos/6601/food-plate-yellow-white-medium.jpg",
//                "https://static.pexels.com/photos/6695/summer-sun-yellow-spring-medium.jpg",
//                "https://static.pexels.com/photos/7117/mountains-night-clouds-lake-medium.jpg",
//                "https://static.pexels.com/photos/7262/clouds-ocean-seagull-medium.jpg",
//                "https://static.pexels.com/photos/5968/wood-nature-dark-forest-medium.jpg"
        };
        return urls;
    }

    public static String[] getCleaningServicesnames(){
        String[] names = new String[]{
                "AC Cleaning",
                "Carpet CLeaning",
//                "name3",
//                "name4",
//                "name5",
//                "name6",
//                "name7",
//                "name8",
//                "name9",
//                "name10"

        };
        return names;
    }
    public static String[] getCleaningServicesdescriptions(){
        String[] desc = new String[]{
                "20% off",
                "40% off",
//                "desc3",
//                "desc4",
//                "desc5",
//                "desc6",
//                "desc7",
//                "desc8",
//                "desc9",
//                "desc10"

        };
        return desc;
    }

    public static String[] getCleaningServicesprice(){
        String[] price = new String[]{
                "1500",
                "300",
//                "2000",
//                "3300",
//                "2000",
//                "3300",
//                "2000",
//                "3300",
//                "2000",
//                "3300"

        };
        return price;
    }




    // CIVILWORK SERVICES



    public static String[] getCivilWorkServicesUrls() {
        String[] urls = new String[] {
                "https://3.imimg.com/data3/OL/JA/MY-2756871/cctv-surveillance-camera-installation-services-250x250.jpg",
                "https://thumbor.forbes.com/thumbor/fit-in/900x510/https://www.forbes.com/home-improvement/wp-content/uploads/2022/07/featured-image-flooring-contractor.jpeg.jpg",
                "https://www.behr.com/binaries/content/gallery/behrbrxm/how-to/web/video-replacement-images/int_repaircrack640x390.jpg/int_repaircrack640x390.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ508wR3jDo7bwpnmr4-rgaLYSeOlORREA01Q&usqp=CAU",
                "https://content.jdmagicbox.com/comp/def_content/glass-door-repair-and-services/blrlkbjsuv-glass-door-repair-and-services-1-vpfvo.jpg",
                "https://www.nobroker.in/blog/wp-content/uploads/2020/02/shutterstock_317198111.jpg"


        };
        return urls;
    }

    public static String[] getCivilWorkServicesnames(){
        String[] names = new String[]{
                "CCTV",
                "FLOORING",
                "WALL CRACK REPAIR",
                "Plastering repairs",
                "Door and window repairs",
                "Leakage repairs",


        };
        return names;
    }
    public static String[] getCivilWorkServicesdescriptions(){
        String[] desc = new String[]{
                "Public CCTV",
                "desc2",
                "desc3",
                "desc4",
                "desc5",
                "desc6",


        };
        return desc;
    }

    public static String[] getCivilWorkServicesprice(){
        String[] price = new String[]{
                "7000",
                "3300",
                "2000",
                "3300",
                "2000",
                "3300",


        };
        return price;
    }



    // LANDSALES



    public static String[] getLandSalesUrls() {
        String[] urls = new String[] {
                "https://mediacdn.99acres.com/media1/20833/18/416678346M-1680862125318.jpg",
                "https://assets.thehansindia.com/h-upload/2021/06/10/1081489-lands-for-sale.jpg",
                "https://is1-3.housingcdn.com/01c16c28/cda7bc632bbe5ad48a19f8e26f43a6c2/v0/fs/residential_plot-for-sale-raipur_7-Gurgaon-plot_view.jpg",
                "https://mediacdn.99acres.com/media1/16528/9/330569942M-1637862883290.jpg",
                "https://5.imimg.com/data5/ANDROID/Default/2022/12/SP/JZ/XF/124950836/product-jpeg-250x250.jpg",
                "https://mediacdn.99acres.com/media1/20833/18/416678188M-1680862124697.jpg"
        };
        return urls;
    }

    public static String[] getLandSalesnames(){
        String[] names = new String[]{
                "Land Sale",
                "name2",
                "name3",
                "name4",
                "name5",
                "name6",


        };
        return names;
    }
    public static String[] getLandSalesdescriptions(){
        String[] desc = new String[]{
                "10% Off",
                "desc2",
                "desc3",
                "desc4",
                "desc5",
                "desc6",


        };
        return desc;
    }

    public static String[] getLandSalesprice(){
        String[] price = new String[]{
                "5000000",
                "3300",
                "2000",
                "3300",
                "2000",
                "3300",
//                "2000",
//                "3300",
//                "2000",
//                "3300"

        };
        return price;
    }


    // RENTS



    public static String[] getRentsUrls() {
        String[] urls = new String[] {
                "https://images.timesproperty.com/blog/1664/Picture1.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSYeM70NPK0zbDdl_NFPNszgWDD_NjW1rgasDY4xLyG5sjSlwOacMhzi4U74JUU67yTzRc&usqp=CAU",
                "https://apollo-singapore.akamaized.net/v1/files/1yj066c30ll32-IN/image;s=272x0",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThSx_dXdfP7oM-cWDv9Ju9SC5YugGgNIbaWQ&usqp=CAU",
                "https://nestaway-houses-assets.nestaway.com/uploads/images/thumb_large_493e8e9f-6648-4dcc-b07b-95a4dd640808.jpg",
                "https://is1-3.housingcdn.com/01c16c28/d82740865f34f277b378c8391604cd83/v0/fs/2_bhk_independent_house-for-rent-krishna_nagar_rewari-Rewari-others.jpg",

        };
        return urls;
    }

    public static String[] getRentsnames(){
        String[] names = new String[]{
                "Rent",
                "name2",
                "name3",
                "name4",
                "name5",
                "name5",


        };
        return names;
    }
    public static String[] getRentsdescriptions(){
        String[] desc = new String[]{
                "3BHK",
                "desc2",
                "desc3",
                "desc4",
                "desc5",
                "desc6",


        };
        return desc;
    }

    public static String[] getRentsprice(){
        String[] price = new String[]{
                "30000",
                "3300",
                "2000",
                "3300",
                "2000",
                "3300",

        };
        return price;
    }


    public static String[] getGroceriesUrls() {
        String[] urls = new String[]{
                "https://m.media-amazon.com/images/I/51TH5xE+2sL.jpg",
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Groceries/g13.jpg",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhUSEhIWFhUXFRYYFRYVEhgVFhUWFRgYFhcXFRUYHSggGB0lGxUYITEtJSkrLi4uFyAzODMsNyktLysBCgoKDg0OGxAQGy4lICUtLS0rLS0tLy0tLS0tKy0tLy03MDAuLS01LTAvLy0rLS0tLS0vLS0vLS8tLS0vLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEBAAMBAQEAAAAAAAAAAAAABQMEBgIBB//EAEUQAAIBAgQCBwYEAwQIBwAAAAECAAMRBBIhMQVBEyIyUWFxkQYUUoGhsRUjQnIzYsE0gpLRByRDY3OisvAWU4PC0+Hx/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAQGAgMFAQf/xAA+EQABAwIDBAUJCAIBBQAAAAABAAIRAyEEMUEFUWFxEhSBkfAGExYyM6GxwdEiQlJyktLh8WKywhUjJEOC/9oADAMBAAIRAxEAPwD9xiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEiIhEny8+z4doRa3v1P4o9+p/F9DIr6GxsD3GfAR/LKMfKbG5ebbP5XfuU7qzOKt+/U/i+hj36n8X3kT0j0mPpPjNWs7nfuXnVmcVb9+p/F949+p/F9DInpPtx4R6T4z8LO537k6s3irXv1P4vvHv1P4voZFuPCLjwj0nxn4G9zv3J1ZvFWvfqfxfQx79T+L6GRbjwi48I9J8Z+Fvc79y96s3irXv1P4voY9+p/F9DIoHlPuXymPpRi/ws7j+5edWZxVr36n8X0Me/U/i+hkXL5Rl8o9KMX+Fncf3J1dnFWffqfxfQx7/T+L6GRsvlPhHlPfSjF/hZ3H9ydXZxXQUqgYXG0yTT4Z/DHzm5Lngqrq2HZUdm5oJjK4nxdRHiHEJERJKxSIiESIiESIiESIiESIiEU/imFFRCbdYDTxHMSNRWdTOfwyasO7/OVbb2F/7tOq3N0g8xEe6R2KZh3nokHRYmSAszVBPMptWoekVJBRMPcXJsOXf5x7qPiP0mxTHVX09NJjxOISmpd2CqN2Y2A+ZnZNOkyGhoOWdyVqDnFY/d17z9J86Bf+zOZ4j7d0EuKSNUPxH8tP7u7H0EiV/b3Et2UooP2kn1ZrfSb24Ou71abRzAH8+5dGns3EvzEczHuz9y740V7j/iM+dGO7/mM/Nz7ZY3/zF8uip2/6Znpe3GJG4pN50z/7GE8fs/GAW6HZHzaFvOya41HefoF+iIB8P1nqw+EegnH8P9uqbG1WkU/mTrDzIYgj5Ezq8LiUqqHpsGU7EG48fnOXiW4uh7UEcYEd4+sqDXwtSj7Rse8d+S0cTjuironKoG07iuXbzzfSUpzvtFpXw5/mb6gf5Tol2Ej1wOix+pF+wkLTqhM2eH4YP1m2B0HfNVtpa4etqa+vrrOz5P4FtbEdOoJDRMcchPvPYtVd5a22q2YiJfyoCREQiREQiREQiREQiREQiREQiSDR/iP+4y9IarZj+6cLbjgBSP8AkfgpGH+8lfeYpkrbzHKDifaO5qW3JZ6Z6o+f3M/LPbbir1cS6E9Sm7Ko5dQ5WJHMk3+VhP1KmeqP3N9zOM9qvZFqrmtQIzHVqbG12tuhtbXmD53liwVelTrA1LWEHTIeJU/ZValSr9Krbcd1/pIla2K9lKOem6EimtziLsMyqqdNmBtcAqGX/szzjPZ7DIXchlQOigtVyJ1qaudclRy1z3W8e6Ljzj6eY1RVXMgRzkyqyLeyXAym1zsec1V47ilJbpnF7Xs2hsLDS9r2576TezC4x7QRWkRFib3k/ag3zAMWFozXYp0MQWg+c6QAixN8jnBvmJ3RC6Sv7OYenmKnpCcjJTeulKyOO3mIGfUEctLT1ieBYVFDAIWNGjUVa2Iy0/zMwNqoKhuyOdtB3zmk4/iBe9U1AwAIrBawOXbSqDtMuG4pjKjsabO7MAGQJnDBeyOiAIAHgI6pjQJdVEC/rP4WMWAsbiHGTLryPRh8TmX5RN3Cct1gLHITz0ucX4VRp4WoaaAXoYWro7VBmqO4bK3cQvlPH+jiu/SVaf6OjL+AdWRR8yCf8I7pioezWNxTFq7FAbA52NyBtamBYAa6HLznXcA4bSw6stMNfNZ2des5XmLfp10HnzvIWJxDKeFfRNTpvcZkSQPV1OeWmd8oUPEV6bMO6kXdNx3SQLAZ65c73Wl7UaVMOf8AeW9Vb/KX6ewkD2u3w5/3y/8ARVnQUNh5TjPE0qY5/FcU59yV9BLmH7C/tX7SHiZbwvYX9stnk77WoP8AFvxKjYj1BzWeIiWxQ0iIhEiIhEiIhEiIhEiIhEiIhEnOcQqlWSxtmqqp21BvcajwnRznMe5DJYkXqqDbmDfQ+E4G3f8A0/mP+q3UdVmqzHMlXeY5Qq/rlTW5LJSPV+bfe8M00Mdj1oC7g5e8KzfIhQT9JKPthhtlLt35aFVredk0krzdasB5tpNhlfIAIAuhvNDG8HoVtHpIT8QGV/8AGtiZMp+1lJjlVaha17dGwNtBqGsRvMp9ou6hVP8A6Y/q82UtmY+elTpuneJB+SyFTzbpDoPNSsP7DqK5LMWogXUZrOxP6WttbvFibjbWdZhsMlJctNFRe5AAPpJH4852w1X/AAL/APJH4xXO2Gf52H+cmV9nbVxMecYTHEDtzz4rOvjTWjzlSY8bs+KuROer8Xxai4wjHXkxJ9FQmYF41jGuBhALfE7KfQ0wZBrbJxdATVZ0RvJEd8wtQc03B+P0Wf2w2o+FZPtUH9Z0GF7I8pyLYTE4mohqqFRTcKLm7bXYnfc9286/DrYAeE11GhoYwEE6whXyvLeF7C/tkWtLWF7C+Q+0snk17aryHxWjE+qFniIlwUNIiIRIiIRIiIRIiIRIiIRIiIRJzfEXIdLEi9ZQbG1wQ2h750k5vHLd18KoPyF5wduD2P5j/qt9HJyz1d5jmSrMcoNf1yprcl4ekHZEYXVqgDDvFmNj4XA89tpwfG8DjVotia1ToEuFpUVHRlrnQCmlgtlBPW10nc4oNYFCQ4YZLWuW1UDrAjnuQbb8pwPtXxUV66UmqO1GkMhcWZnb/a1ACQNToNbAActJ9F8iJNF4DfvSTANoFhx7JgjeVxttFoptJdfICSBJ1MaDjZdf/o8YVcKHrAFlqOiVH1YoQjHrHUjNp/dHdPX/AIqTNWp+7AOn8IFx+daqaTEdXqgEX56Bu6avBuO4KrQfPhlWhhRSKZ1FVvzWZc1raNcC5uTqTebHS4I1R+U/SqlSrTNQ5QUxDMzHMp2/Oc66gE85Yq3RYalSq2AJPAQJ0OUZ5xPBR6Ti5lNrHzkOeY1E5gxvIXvA+1autN2pgBqNaqVUZj+S1QEBiQNqfd6TZf2qQC/QNrhziEuV6yjkbXsdD6SdRo0KYCrRS1IVEAJqtdWDPUDZnOUHOwJOb7CaXGuLWpM9GhTpihW93zMEdzTs+ZMrIQqG/I98j4TE4XGuIw9wIzketJbmNRuW2oKtFgNU3jQbrH3qrj/aV2plaaCmzYIYkPnDFCbEplK2JAvqe7YTRqcXbo8K5ZXesqrVdargU7IpAqKKqpnJLakrt4TDT44cMcRlSl1cYaQJpoopoxcDRcgPY/Uw8TKNXjWO6MmmtFvzQB0ZW/RkMTezuobQbFt9jJLqLSA1zBE6nhyORgi/JYiqQS4OIPDn84j6LPw/PkV3ChmLqRTYshAsytYswDWuDY6872FqVOSuH4qtVUVK9N0qCs9Nc+man0fSHKuRdM6LrblvylanPnPlFSFPaUdECQDbLUfKNV18O7pUWmSeeaxVpawvYXyEi1pawvYXykrya9vV5D4rzEeoFniIlwUNIiIRIiIRIiIRIiIRIiIRIiIRJD/U37jLkh/rb9xlf8oPUpfm+SkUNV8qzHMtWYpQ6/tCpbcl4ZyrI4Utka+UWuQVambZiBs99+UgYb2SwS70atT/AIlZUHy6I3tOinipVVQSzAAC5JIAA7z3DQ+k62ztvYzA0jRoEQTOs6DQj+yd61VcNRrEGo0OjKVPpcEoIlSmmGRVqhRU/wBbrEkKcw7SG2vdMxwK5gwSmGFNaYOaq5CKQVHbXW6jXfTefffbsyim5YdJysvVva7HQZiNPO+0w03rVlN8qKUNitTMxa4sQQLKu/edpvqbf2m+S+rA1s3XnJOXuHBZswlJgkMA8HjzWzToFbdjTuR9bbZlaqwa1ha40sLT4+DTMz5rMbl26LDa8yWJpX8dTMbYWqd65HlSQHcm1zfwHfYd+swPQooHZq5y9bOrVgVIYKCGU+Cj11vNI2jjXQ1lY30YCOGjW8hnlotnmqfAngJ+IW6awtc12110qBL62v1LczPVIhr2qM1t/wA+o3MjUZ+8H0kcrhlAHStqLKQGfMoUhlHVIa9mbvuTNitSp0lv0zUtFYaqCVpggLlcXIsRfnoI/wDPqCQ+r29KPj44C62FgblI7Le6fmqaUVU3Ci9rXygG3dfe0z05CoPUqIDSxFNx1Sq1eq1gR2mBu2q9wvmOu1t/38oxFRGAt1XHWU6c7dk3vpry79IfV6vnR05LuMye+CeyVi+m4WzPv98LarS1hewvlIK1g6hhsb21B2JHKXsL2F8pYfJsRiKoO4fFRMSIaOazxES4KGkREIkREIkREIkREIkREIkREIkhjtnzP9ZckM9tv3H7yveUJinS/MfgpGH1XypNbE1xTUu2w38PEnYDvJ0Ew4viSqdvr9TptNGpxsMLAUjchbM97k7Cwve8rX/RcY98lkDi4fKT7lKDwM1mfHvVB6BTpa7sAVAIBOUqeswBGnfcTMvDlLZ6hztYaHSmLXNwo7ySdbyaeMVSmdAjDKSpVgVNttSOz4jlqJix2MKqzYhlJuCEUnolCm6kqQCxvbVtiCBoCTvOx8QxwbIaL3Ek8sh8gtragPq204me7tyEKtxPHe7rdad9QLBggA8z4ch3SVxbGFSzsG7NqadaxJvlOQaMSLm3LSQE6erUQVgVXr1W6UOgC9W7C2pUnKoHy0AvHGKuKxK0yioBTqOxcP1W1XKWG4UG+/xidbC4CjQJ6AvvJkxOX9AfTYaMPNMuAsbtJJuDy1Fo33W/hON1UPRtTcXOilbnv6ote3hy8BNHiFWk1Mow6MnL1VXJckEm45i5PpPD8NxF+noAuFLALYIrBgQWW5vpt85mWtWphUyI1RhvdWN7m6XO1rk90kAkESfHKclGwr6pLSJbBM3iSLX46817wWPRKeZLjKBoSXDL2QTe5B0BmzgqxxN6ddWcZSy1SOjBIPZVhzsbkeHlaLxU+51FdVAqMDSyrYh1qIwz0wo7d7eYYiZ8mIoFK1QVSALMEQ1CWvpohJW22o5DymuvTZ0TcAuyJsZHx8WUoGn0TWpWvqYcOPHS+szZX8LVp1LpRK3p08iknOuQrlBIHWuDobHW515yvRqsVyoDfQAEXW22o5jT/wDZzuC4fRouCr5XHVa7sAzm11JOlwXAuN83hKldOkQsCxBIyKllYOCQwLWsRe240N5zXdAvAE9E3vkTcayDzyzvmFjV6DnAsJ6PEX8cit3h1ZGLqFyPoXS40uosVtplII2+9wOqwnYWcVUwX5hrocpy78yTe5OncbjzO067grE0KZJucouZ29l4IUqzqzTZzRa9jrnpuuedpMLFEECPFlvRETuKEkREIkREIkREIkREIkREIkREIkiP/Eb9xluQn/iN+4yueUnsqf5j8FJw+q57iRUMyvsb5sxFiDpY/Kc1T4ZUYAjol62ZiGLjNpdtbgm4J12FgCvWv1fGA4c5LX0PWvbbwnPDEuzX1uAblMO5F+toHYgMRl7rXA7xJ2Hq+cpNfvAPePAWThC38PTcIFJF7WJsLW5ACwvYWF7C9r25TS4jTzYin+XenSZDUvoCGYsBdj1tSDpe+ouJuYMOesxfmArBFGut+qT5amZMNg6dNsxLEOL6G6UzTJuWY88zZbXN9dNDI2MqCnDzx5fLxOkkZsEn1QeenHxwUyqnTs6ksgKXRlNlLaEpY3voOXwnuk7DcMS9VaDObGxGcFnupuzZtFHVFwAB1vXrOnV0Li7AKCqlVuQm9jsSSNNBsbWk5sRRpA9HTyPUUOepm1YnKrcxqNhOc3GGCxrOA1y1NgbX5kRbNSnMMh1MlrgIkbuMjt53iVM4Wxw2HBqM9ySLJ1zUdi1kpLexsi5jb+otKoURTJFVnbM6pQyBvzGIJzlDdrDQEDW7WvoZ0OOwmHwxqVr3D5qeRWYBGXtohAvTzEC5zXsNN5i4di6bCpiGQUX26RqT5WBA/h3YalN8pv8AUTLrLnNLxMG3buGfESOlaw0Iza14D3z6xzPv5chC94ejndWfNTZBTVBlOU1rFXaxsX1B+ZG82a1UVmCKz02qZcyMHpOKa36yslrakG22/wAV5haqFqWP+xzhbZiAdgWGpIzEfbWaFRMQcMzHElGIuaiues2oYKSAV1Ga9gP6RjTcSJMTAG6/Y6cg4jOSYm5OIqB126W7QqZqhmDkl0ysqq1yM41XSxytexJB0y6TeSpZEFQoGuoFgWC1CTY630vbU63uZz+LfVr1GTMFeqAM/wCbqCtMC3fr4ltbA2xV+I86puw0VV6py5VCmrvqLHQX31knD4RtQSP67oBPvNjZZBr6j+i1toz/AIt47F0XBuMGvSr5wFZHA05qVFie6+U/SdvwBr4akf5BPxj2dx/9qJ/W6/8AKv8A9z9i9mD/AKpR/wCGJY6DQ09EZAKFi29HLf8AJVYiJKUFIiIRIiIRIiIRIiIRIiIRIiIRJBq9tv3GXpAr/wAR/wBxla8pzFCmf8vkVJw2ZUnjtUIczGwyak/uP+c5nH8XtlamwYdwBAJHjY+E63iWGWpYNe1joKZqX1Wwyj7nSSa3s7hrKXpVVABbRUpZbGzZy72Glje/6hNmyaFSthaVQTEERaDBI56di2ur06ctdn3kdi5fBcSxBxTZmBVmA6MBmUA7ZRYEEA6k8976W6etRpVSBUYkKt3Uvanlv1S1/wBV9rEEekocOwKAKiUPiFunzAEA9o01NhmFiSR9r857ZsaQagNKgKNmAOQgpqLb2BuRrykjaGCqdFu/pDcYsbxuC20sQcQ+KTbgWgRMfNb3F06Ujo36EvZFYahtCwUC42CEkgjQbk6Sfj6xdVoFmeolqwNNRZhT7KAgdZjTu23O05uviFqUwjValM06xqUQoU2Uqq3zlgQxYOx0I62k+1ONKW6Q0E6ULlWp0hKjKS1Nvd8gW4v3nbnOWMNVPG85AX05jeATpE3XQbha5bdnjnmuwfo6lJq2SyMADTakFYupqK5Ya3JLG/7JGxIw9Xow1kyDKqs/VdLGy3IABzW3I23nP4vjlWopUswBIJ/RqN7ZQNC12sb6kzHhcJVr5m0sgYk9xClgCoPVzZSoNrXYDnNlHAGm0lziDNoOVuyfjxXhwOIDgSWtbrOekREj3rosXxtOirNkWnXdOuguLszFRfrEFgEY6HmPCc/S4q6HMbX5i17+Y56zS6J9zexawPLyEsLwNbr1/wBSqwG9ybG2nhzkttJlJpB18RyGimP6vgmRXdOZyOkT6sxcgC4kkDPLHjOMltKYy73va5vyUAWHy3+88VLAmYsu/nMOLrZV+0ltGQCnVGMosIFvHj5Kp7B8RTNURiAxY2vzBsd/kJ+7ez4Aw9IDbLp6mfhfs/wRVs5FzufMz909nP7LR/YJKpOlxCqeMH2RvVKIiSVz0iIhEiIhEiIhEiIhEiIhEiIhEnP1/wCI/wC4zoJCq9t/3GVrynE0Kf5v+JUnDZnksYxi0LVH7NyCdNAQTz8VEiYzF0XqPiVaoRcNpRzoMiplN1J2KX8mYc7yy+U6EofMrBZTuV/xCcjZ+2sTgqApMpEwTe+RMxktlSgyoZcuVwntPh8Kc9GlVY5Ap7IBtlFyjFet1d+7TkLc/wAf4x77VNU0mQ5VXXLra+2Vm7++dlxPgOHqoQgp02uSGXKATzDAbjT5TiMVwiujFeiLW5opcHxBWd+jtM4wHpSDucIP8/LWLT1dm0cLTd0mWI3kaqUVGbXa/L62lJeGUyTYN+gg3BzggkWsOdgJOr3FwQQQbEEWII3BHKbNDiRCgXOawUHla4YX21GX00MzcHaLo45uIe1pw7oORvAEkHpcYgtI/C4n7q2a/DEfrKMtzZbWyMGzdGwNr72BHn8/WDWlkp3VLtZdVGYt1hcg76lPmZQK6Kym1wrAAGmHz2YdljcgUyCtjvfeRlwlVgBdVAzVVsLntWFyORsbeV5s6pXH2SD3zzy8a5KvU6vWKRZUrFrQWgS4h0FtSxm5k9GZAH2XNBsVsmmDTCHrMNbA2uwqspyn++RoJsV6ppa1FNwiN1qbgtq3RsCT3i12mpXphGzVHGcA2ABWzZmzNZd73JF7Zrn5YON4zLSpg1MymnTtdwcqIgAS42s7VAR3rMKmHewtD4vpu7u8Dct9DDUcUCCSQ5znEgEN+1BcG9JtwAIkNEuzu1pbFrVALkmZ+B8ONZukbQDsgj6mfOF8NNa1VuzbMBytuDOz4Fwhq+q9VLWLEfYczNlSoykw1HmAMz48FdHGYrp2C18HSOYKBc3sANyZ+rcFpFKFNTuF1ttIPDOFUsOLILtzdtWPz5eQsJ02C7C+UjbMx7cViHBnqhuuZuO7l37lwsUZaFniIneUJIiIRIiIRIiIRIiIRIiIRIiIRJEUXZz/ADH+s3+I4oUkJ5nsjx75Hw1bKh7zK1t6qxxZSP3Q5x7oA7bqVh2mC7sUcvdgo0LPlBLKFBLFVBU6uTbkRuPnovhA9n6BiGIH9oQMrnXrdW2yk2yg6b2OvnGYdlrLXDEBAQNcuXMWJ1zAdog6g7Da15JGDtR6LOLGrntmBBa3ay59GvroRYm++/ZZXogDfyKxcypKu0qfRKT0TC46RstRGBDDN1FsTc3GtyBe5tcTziK5ak+XQgpp0isQcykhmQWB30sDsN5Lp0Sa1aqKrXqL0VswBC5UphRrqOpcC2hqNrqb0EwZWh0QW/WAAC5gAGzDqgmyjlrpYDQaTGpWpHLOVkxj9Vo0OBJxBGrpUKVOlq03Bsy5qNRqd9LEEhQ3PtSdjPYrEpcqUcfyPcn5MBO14FhBh6WQbmpVqN+6rUaofTNb5Te6WU6vtXE0sQ8UyC0EwCPmIMTlfKF1aOMr02gT3+JX5a5xFAAOjplDDrI4JF7i+2x1BG3Ka6VKzkWFSoQb2UO9ie7u5ifrfSmamKwq1DclxoBo1tiSPqZLHlDVc2HM95I4Wj5rYMSxsltISZntknTWTO8WNoj8+oezeMxDFui6IHUmvdMut+xbNfXuljF+wadCLMatXMpN9Fy6ghEvbmDqSeryl7F4JERmGckC1g9i1ydCbfzneYujpEZfziFfqBXzFhlzK2U21ORrDW1jtMeu4zEEVmmwdcAROt/tazlIBvZajiK5YGtENAAAG4RAvJWvwb2UVFXpSSqjSkCMv962/l9TOmp0j1UQL3AXygAAnkDbs90h1EpE3BqkMcxy1Blt1z1bfzplGw+W9Lg5WmwYXALnVyM2gdbX7r3I1/VymDKFXFYljsXdu7IZZCHTM7pJAkmAodcVGtJIj+1v1sLUVWaynKCSBUN9Be3Y3lTAnqW7r/e843gPB/dGru1YOKiFdG1N9czX579/aMu4HG5XIY9Vjv3d061JmDwOIpmk3ohwc11yfwkZneI7VAomtWpk1BBGljqd28XV+IiWNYJERCJERCJERCJERCJERCJPJawvPU8stxaeHgi52t1zma5P28BPIpr3GWPw5PH1j8PTx9ZRHbA2i4y5wJP+R+in9YYLBR+jXuMdGvcZY/D08fWPw5PH1mPo7j94/UfovOsMUfIvcY6Ne4yx+Hp4+sfh6ePrHo7j94/UfonWGKPkHcYyDuMsfhyePrH4cnj6x6O47e39X8J1hvFR8g7jGQdxlj8OTx9Y/Dk8fWPR3Hb2/q/hOsN4qOaa9xnlqCHdQfNQZa/DU8fWPw5PGejyf2i3JwH/ANn6J1lvFRjQT4Rrv1V18/U+s+imvcZY/Dk8fUx+HJ4z07A2ic3D9RTrLePjtUjIvcfQTwaK9xlr8OTxj8NTx9Z56P7Q3j9X8J1lvFYuDnRl1sLWv432lOa+HwwS9jvb6TYlv2bQqUMKynVMuEzefvGL8oUSo4OcSEiIk5YJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCJERCL/9k=",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEg8SERMQEBIVGRIQFxASEBAVEBAWFxcWFhUSFhUYHygsGBolGxMVITEhJSkrLi4uFx8zODMsNygtLi0BCgoKDg0OGxAQGy0mHyIrLS0tLSstLC0rKystKy0vLy0tLS8tLS0tMC01LS0tLS0tLS0tLTctLSstLy0tLSstLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABQYEBwIDCAH/xABHEAACAgECAwMKAQYMBQUAAAABAgADEQQhBRIxBhNBByIjMlFhcYGRobEUUmKissEVM0Jyc4KSk8LR0uFkg6Oz0xYXJERU/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAMEBQIGAf/EAC8RAAIBAwIDBgYDAQEAAAAAAAABAgMRIQQxEkFRBRMiYXHwMoGRocHxQrHRUiP/2gAMAwEAAhEDEQA/AN4xEQBERAEREAREQBERAEREAqrdqh3tyBQorYpzMfWIJBPUYG3v+UiOMdt7Ksciq2c5JwQMe4f5yJ1bemv/AJzftNITjOfsZlS1FRx3PV0eztMpq8b42d+hNX+U3Upv3VB9xWz9zSzdg+2n8Id8pq7tqghJVuZGDcwGMgEHzTtvNOcQls8iFp/K9Wvgaeb+zYoH7Zk1Cc3JXZX7R09CNGUowSa5o3TERL55wREQBERAEREAREQBERAEREAREQBERAEREAREQBERAERPhGYBqnQljZqep88+385pD9paiWU+b0P8pc/cyV1fYvVflGpSnVVikEcvO9hsXmVWKuoXlJGdvcQT1mLqvJxqrBvqac+3u2H3UDMyu5lw8LPVrtGiqneJq1ts3+eGU3XocH4e6WbyIcw114IPKaH8DjIspxv8zF3kv1eNtVp29zK6/cAy0eTbsNZpHsv1D1taM1oKWYqFb1y5YDmyQuBgYweuZNQpyUkVNdraNSlJJ7++iNkRES+efEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBETH1dnKjsOUFVZgWIC5AzuT0HvgFbOsZXZgvP3lrLmmoMQOc1hnwRkAKvMxJ6Dwxjs119oCmsZzXbYcJzecor5FHxLnb3e4znwujFNYYq+FTzsqwY8ihmBHXJBOfHPjI7jOgD2FgUB9CN0fmBRdSxbKqcnlZSP6MDI83NSd2XacF37u/Dm2MdOq9T4mv1Xo/MJJ5uZRRbgeYjDc45BkuN8npt1xYeB2s1dTOOVnrrdlwRhioLDB6bk7SpafhHJyiyyuxFJBDpa2VHcA5yMZH5PWNxuCTkYOZ/s5SalKHziHZSQrhSR5jNllGSxQscZGWO56n5TbUkTaqFPgvC3yXv3z5FkiIlwzBERAEREAREQBERAEREAREQBERAEREAREQBERAEREASA7a1u+j1FVdZua1TTyAkAhgQeYgg4xt85PzXfle4mKqtLXkrzu7bc+/KoXB5fD0v2nFSfBFyJtPR76qqd0r83hKyv+C00pgY+Jx4gEk4+85zR9eku2dVO+GDAEHfcHbeSPD+0+soOO8LAdVt5rF+Hnbr8iJS75p+KNvfyNl9jVJJujUhO3JP9r6tLzNvWWBQWOwALE+wDczW+q15vsRnR9RezBlo7xq6tMCOZArg4yQCST4Ak48M0dva7KnrspYM6shNbow85SM4bBHX3xoOOKKKyqhGZW5kxjSMx5FHeE+PJQpGMk8zjbqelOMtmec7U0tWk4wqpxTvusO1tns2rq2+7dsXWz6bOZVb2gHqCNxnqOs7ZCdktStmkpKgKqg1qFFnLyoeVMGzcjlC7nrJuXU7q51CXFFS6iIifToREQBERAEREAREQBERAEREAREQBERAEREAREQBNOeVu/vdbTSDnu61+T2Nk/qhJuOaB1Wq/KuJWWjdWtZgf0Ezyfqosral+FR6s0Ozo/wDo5v8Aim/f3LbXXhQPD90q3a6vCc6+awZfOHs3GPqRLdZ0lZ7VLmmz+p+0s6q/Az7p21Vi1vcq3esFU4UkgH82d2g7XPpmb1kLDHMoWwMPYVcbfTxmPYPNX4D8JE8Rr2z7JAoRWUi5qqk68e7reKPR9drpq0k/NST5bXvu3yTdoH1Y1RZiVyjKGUK2d1Ow6DCptNjTRHkQ13d6goTs5dP7Sqy/rV4+c3vLdP4TGqxUZWSsumfy236ttvdiIidkYiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgEP2s13caPVW5wQjKp/TbzE/WYTTHYqjNzN4KrfUkY+wMvvli1/Lp6aAd7HLkfooP9TqflKp2JpxXY/tYL/ZGf8AEZTqPirpdP2a+ljwaSUv+nb8f6T1xkF2hXNNvw/eJNOd5F8dX0Vv81j9pNP4X6EVL416opVvqr8B+EwL0yCJIX9F+A/CYRkUNi7VWTv7Fas1aglfWHLYPijbftT01pbxYiOu6uquPgRkfjPLHDG5dTX7yR9Qf34nobyfa3vNIqnrUzV/L1l+zY+UmpbWMrVRtK5Z4iJKVRERAEREAREQBERAEREAREQBERAEREAREQBERANI+VXX95rmQHalUrx4ZI52P64H9WZ/Zyrl01eepy/1JI+2JUOPanvdTfZnPPY7/IucD6YEueicCqtfYqj6ACZ9F8VWUjfrx4NPCC94O4mR3Gz6K3+a/wCBmcW8ZA8e1fo7B7QR9dv3y1N2iylTV5orepOy/ATDmRY2y/AfhMVpDDYu1fiMXVNytW/5pVvoQf8AObm8mWt5brKs7WJzD+cnTHyZvpNL607S89geJ4t0VmdwyIfn6N/xMlhhsz9UrpM33ERJygIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIB5mK75J38fj4yY0PaTkAD1izGBzByp+mDIfiS8tty/mvYv0Yj90wTMeDlHZnr5RhVj4kXC7tTWRtU3w5lxK7xfixtGAqqvXGeYn2b7fhIt3mO7GSupOSs2QLT0qbukZH5XjbAP4zqs1f6P3/2mIxnQ7ySN0V6ri3c7tTfzbYx85I9luJtVdWgUOHsrABYgqzMq5B3923ukE5kh2Y31miHtv0w/6qSZJlGo08HrqIiWTNEREAREQBERAEREAREQBERAEREAREQBERAEREA0PxTstfbqdUa2pwbLsczWDALtgbIZ8Xyda0jIbS/3tv8A45dkq9Pd/SWfttLJpq84iOkoyV7fdksu1NTDwprHkjUFnk213/Dn/mv/AKJ0WeTXX/8AD/3p/wBMvHFe0mrrGpsCaY1V32aUZS02MQWI2Dfmrudt/CR1Hb3Vv6unobBVdqrzgk4C7P1J2A8TKrnpY4tI2IaXtWpHijwW+Xrn6oqX/tnrz4acf84/uWcT5K+Inx0v96/+iXuztlq1Yo1ekrtBwa2q1IsU4zg+djp78bic6O1epNlCEaVhZZXWeRLuYB2CndjscZ9s77zTdGQT0XaNrtx2vi230fysa41Pkw1q7tZpAPdZcT/244J2Otq1WldrqzyXUOQqvvy2K2Mn4TcvHR5vslEawjUVZzyq6PzYOOj5B+GB9RLdSEIK6X3Zj0qtWq7cXK+yN2RESM6EREAREQBERAEREAREQBERAEREAREQBERAEREApHDqw11x6+ktG4x0dpatNSAJXuFj01+Rj0lv7Z3ljstVEZ2OFUFid9gNzOoytE4nHLNe6Xjmnos1tdrctp1mpsRjU7CklbFW4gDDYY45eu+fCfE49R3SLXbWLFr0BCkPULL6bCzh2cAFcYySfDMn9bxZl8+oKK2rGo3qsZjzuAvqMMHzs9CT0Ew/4UexFa2uhlL0oVsVioD1o5bmOQ29gUYGxK59bIzW2sX+x6OFSM7VO7bvw38a5W5OC36X3e92cP4J09j6xsU6hLnvcWKvO9ZCBz6UP5o5y2FVTn2+yP4tTo6LEcLRp+511KFhYQRTyJY7vzHZQ+N9gPrnJ0PZ3R6pO8On7o5AwrXJ/JVvVJ23Y+G4xKpxnhdFWpdQAhqSy6s3NYyDukD2WYJ3IDA58MHAJJx9im+S633+mOp0tRGMnHjndK1mkl0d2pO+N/DnyNg8Y1NVtfeVPXah5lD1urpkHBHMpIyDtNeaxfTrj3Y6fm2f5iY/AOMv+U11gl69QneEhCo/i+8Vz7xjHU+tMjiJHfn24XqP0bMdB8ZdnPij8zDhQ7qpZO+N/I3lEROiEREQBERAEREAREQBERAEREAREQBERAEREAREQCqcOcC6/Jx6Sz9oyJ8oXadalGkUAvcqszZ2RC2FAA9ZmKsMbfcTp4jqeS+0ZIy9hz4D0jfT7yodtsNdUwYtYAFK7tlMsVYEnA3LDwz7BiZlXU1ON07K2c+8F7s+jSramNOaunfk3y5pZsv2XpbMV6PD8iNp6iSyUsFAfTKHLMu/KNQzb7ZRTjrmG03EzysTRQH7uq1QKF3YimuoKo68h73Yb4A9klOA8aramms2MhqpQPkryMa1CkqSMvzZYgjY8u3jJyiwPzFLlcKcEr3bBTkMckePLkfP2idcPHlP+ixTrxorhlBY57Xz5K3lf+7YidJrWW2tFNYrZ2AUIoLKAgAHtwpzkeweExO2teXpYHLIM8vfcgAznf2A7Zx1xiZHHONrVUEpdbbiQnODWO7GwZ9sDPgAPE+6a81RYnL8xLHqSxLk7ePXfxnNSfDgtaPTKtLvLqKV/V755YS63v6Fy4fpKjR+UZVribKmKsStYB/i1HwCnPU58M4la4mjNa/Lgry46+JVhuM/CdHCbmRrgpIrKZYYyvPkcje445/95wvJOT1PKcHPjv8ACSUqzl4bYsUNVBw1c03d/wBXyb+iIl8zhERAEREAREQBERAEREAREQBERAEREAREQBERANR9qNVjUNgjdrtieVgRa6kq3gdj126dZS+Kcy3mxs52fBDAbDofb0+8tPbC5TewCcwFmpQrkc2RYScb53zn5jpKtxXU4K1g86HzwrD1SMqQT4dPCZdVLib9+/Wxb7JqTh2lwpJpppp7Wsn89ksX3tazuZNGsOV5eYLgd4OZ2ycEkLvgjzsjIySDvM4NYaxXXlsYJ5T4IcMAxOzEhMrscJ0zI+pkZUOUqIJr5SbGZxyn+SxYAHPKW8OfOCRmfEAU2WK/PeOYKh5PNLHAbnY74GDjY58eqmBLJsVY91U4Y0+HlFZallPn921w4urXbOL0v1Kvzb5XkfI6g9VGeo2JION8mSVHDyqWWahmqUYKo25DbYON8BR5o6E+7+V94C/5VfRp7C6HBVmKq2WVWx5vLtkruMHrj3zZNPZSgt6dRqm2PJYEHLsPOAG2dz95YpUXLYm1er7pqNVbpNW6Xds8ldfs1Po+IolblmQs7YCkgPygDlPMOhy/q58fGcq2yhJz6rHLdcZPu90svbXTaNLWT+Jda25KDzq1nJWzKwC7ec7BPOG4O2MSsUAd2cc2OV9jsfWbY5k0aSg8e/fnnzZ53vHU1Up9bv7pe8noZegnKcKvVX4D8Jzl0gEREAREQBERAEREAREQBERAEREAREQBERAEREA8/dtOI51mpSwIortvwFBHMC5PPzb+djGfDbpK5xPVq3KwsViuwwQGI3xn24/fJrtfvrdd/T3ftmQD0D2CZsqivZo1NP2ZwVI6iE3fHTONtv1g41cSXYHH2+8l/wCHya7Ku8qVGYOVyo84Y6Y6DwxIJ6F9gnU+nX2TjhizcjrKsGnJJ+pauAcfSgiwPUCj5U5rLAHk5goPgeUAn5bb5s2u7Rqusrf8sqz56c4trwAcYy2cKMkHfbrnpNTtSPYJjvUvsksIJbNmLWhNzqTf82n6Wabzvm1nt+C89oOK0NZY3f02knJYPWWIIG4cZz8PtIRu0KohRMPs2+T4knoPZzHxlbZPZPor656bywtsu5Rlp33jnGTV+S2Xkj2Jo35q6z7VU/UCd8i+zBY6PRc3rdxRzfHu1z95KSwVxERAEREAREQBERAEREAREQBERAEREAREQBERAND+VLhTUa6ywjFd/pUPgTgCxfiG3+DCU1rJ6W47wWnV1Gm9VdfWBIBKMOjDPjufqZq7i3ko1AYmjuLV99ltb/2dwPrKc9NeTaZq0O0VGCjNbYNaNZOl3lx1Hk64ipP/AMOxh7V1OnIP1sz9piP2B4h/+LU/Kyk/45ytPJHcu0YPk/t/pUbGmPYZdP8A0Drz/wDS1J/r1j/HA8m2vPTQXH46ikfjaJKqbRXnq4vqUUtM/gPDn1eoo0tfr3OK8jcqvV3+CqGb5S7abyScRsxmjTaf33XhiPlXz5+s2j5P/J/VwwNYX7/UuOU28gREXOeStMnA2GSTk4HTpJVEryrXWC5VIFAUbAAKB7ANhOyIkhXEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQD//Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBIWFRURFRUREhgSEhERGBESERERGBESGBgZGRgYGBgcIS4lHB4rHxgYJjgmKy8xNTU1GiU7QDs0Py40NTEBDAwMEA8QGhISGjQhISE0NDQ0NDQ0NDE0NDQ0NDQ0MTQ0NDQ0NDQ0NDQ0MTQxNDE0NDQ0NDExNDE0MTQ0ND8/NP/AABEIALIBHAMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAADBAACBQEGB//EAD4QAAIBAgQCBwYDBgUFAAAAAAECAAMRBBIhMUFRBSJhcYGRoQYTMkKx8CPB0TNScoKy8RRic8LhB0NTktL/xAAYAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/EAB0RAQEBAQEBAAMBAAAAAAAAAAABEQIhMQMSQWH/2gAMAwEAAhEDEQA/APsck7JKjkk7JA5OySQJJJJAkkkkCSSSQJJJJAkkkkCSSSQJJJBvUA74BJIv70wi1JNXBJJ0GS0I5JJIxsLyjjMBvAmtA1Kl9YIvMXpTq1IUGII8OjxKGbTkgM7NaORWrWvoNpbE1baecUZpm1Bc877yLZ5bPM6rUkkknVEkkkgSSSSBJJJIEkknYHJxiBOk21irveTQU1Z1XipadV5nVOqZ20Ajw4Mso5OyGcJtrKgdapYdpibPLVHubwTTFutRYPLo8XvLK0mh6m8ODEUeMo01Kgpi2JfhyjBMz2D7lT5Rb4KsYMmdJnGnPVdVoZGi14VDLKHUaGBiqmEFSbiFaiOSTlMA9xoQR3zVDTrICLEAxmjHJlbxnFYQjrLqOI4iJZpzvg35JJJ3RJJJIEknZIEnIOtXVRdiFvzg6eLRvhN/KTQxJF6mKC7idoYkNm5ruI0drPwi7GXYwbGZoGzTimcackUzTaMo0TpmMBrSwM3gsQCRYC8oKkIryhBgRuCO+DZpqkAix1iGKw+XrDUfSY6lnxSzGRWg3aVDTGqeptGFa0Xw66XMuzTcqGBUhA8SzS6PLOkM1aKtv5jeZddCpsfA85p02kr0gykeR5GXrnYsY94zh1vrELnNk2N7Hs5zTXQW5Tlz7VvixMrmkZoItN6hlHh0eIo8OjzUqHJlYjo0liVtY625TSRpe8WS/RySSSbRJJJ2BycJsL8tZaZXSuMsCi7k5Se3lM2qyulMWHJe/VBKqD2bnvvAYcm19otjT1lAItT11B1b7vG6IsLmZ1UqY51Ns2mnxS3QuKZq7rwy39dBMzH4em79dcxptmW9xrbftjns/piKoI3p02HiWB+kzvsX+PTGDYy7iLvm5E9wvNMoxlbwT1ITCdZuwa/pJocpJYdsjNLMYFjKL55dGi14RGgOo0uR6xdGjAM1Bh45MjW4HUd3KBwwzNbgNTNbpPCmolltmBBBOnfFMF0e6A5spJPym+njacbzf2/xrfDJMo7SNcaG475RjNWoqTLI8GxkUzOh6m0ZDRGmdITPOkqB1MBeqagIAK2t/m5+UK2HbsPpLI8OrR+sXWc4I0OkG01KlMMLGZmIQqbHwPMTPUwUDQyPEy8Ywwvry+skodV5M0GTK5prUPzs5JOqOwVWqF33Ow5wsz+kTls17DKfTWSi1fHAA2BvzuNDMGrVuWP7gOvNj+kBU6UQkdVjfYkgQdaqMoUDLc33vvMW60HQ6xLHnNJLb+ndEsOtu7SPrAy2pnMeAJLXvfUk6TQ6GoZC1Y8RkAOosDcxLH0C7IgsCHU8gRxuR2XPhNXFOtNAByVB2nnMyerWkmOpmwJIPEWJF51sTTFzmAA/SYVLX1gMepIygldL5hvsfWa66shJtafSGKV1UKQb6huZ5eMP0QPwwx+ck+Gwnjq2LdaCcwLG45D0O09phBZEHJFv321mObt06meGHaAZp1zAO02yuWlkaK54zhhmP1kDaGE95BkyjPKplakKGiAeFR5ZQy6AixF5nYmiV7Qdj+RmgjTtRAQQdjJZoxWadoi5gMSSrFDuPUcDGsOLKO3UzlPq54OTK5pRmnLzepR1eGR4kDD02llQ+hg8TRzKRx4HkZym0MDNfR5io9iQdwbW7ZrUFyqB93lcT0YGqCpmyjQlct7kdt9OEbOG5H0nOc2WraAxg7wlWmRuNOYgc0VGtJOTs7IkHXoq6lWFwfSEkgeC6VQI5RcpKHYcuwTgvcX34aRvpwAOWK7EsDa12O+oi1Nx8X34Ti2Zotw8Y4rXidMcbXHdpeN0NbATUQehQF853ta/IcZm4+oXqBV+FL3HMnlNJ6llJ24DuEzKa9a/O8obpqNtvGBx4Atv524w1Lt5xXpBzfq8Bv2yUjE9of2DMPlIY9i3sfrPdUQSBbXQTx7YRqye5b/uA0ybA2UjU/fKeupYpUAQ3IAAB0ubDjJz9pVnovy9REayuN1f/wBTNJekKZ4kd40nK+NQXCkEgbA6zdkGK1SbGFTKo5nU98xKTmpWXlc5v5efpPQGZ5Kq5gWaFaAcxRA0MjxYmERpNU7TaMgxOnDZ5uVCfSXR5qMjAqMps176ruLdu/nL/wCCbmvqI0HhA0n6zdNrLq0nXceO4lBNmI4nDW6y+I/SS858NKQiGBJlqZubTnq4dRpZng5RmnTUGFSFSpEc0ujzUqNEGLPg1Jvt2aTtOpD3jy/RzNJmgC04WnTEHzSpqCAJg3MJoeNpgnNYG+4PGZdXAU+AKXPyDQeE0HeBzC1xwvMdcxZQcMgQWYhg1iMvGKYjpEoeoi3sdCcuvLSL9KdMqjKuW+YgB+AJBPDX+8DieuquLEEhiCdwbg205zF8ah2ti8ygX1IF7W34zibAaHhp66xVBpbQG1u7ujijbs3t3QDJ3c/GLYxuAvG0cWhEpht784s0B6LoZVNRt20F+XH77IOu5aodrL1e/QXjmJqBFJ06o0Um2p2/TxmahqK5BUlWynPcDM5JLXHLaXAywJBO2hv4TNptqNTp5Dsmqi3BFr77cO2ZVYpfKL8dNTcjh6GZpDPs/TPvqr3uMiC3+a5v46T0hM8z7MaVcSvbRYcOqwb8wZ6UmXn4X6G5gXMvUaLM8lpHbw9EEm0ULzRwaWXN+9r4TPPtX4PsLQZadYwTtOlQQPCo8TvCI8ah5GhYmjRlWllGV0jTynMNm9DynMGNM3P6TQxtDOjJxI0PI8JnIwUBeQAnLrnOta3wyzQLGTPKky6ipM6ryjTgjQ7TeMh4hSMaBm5UFIlSsvIZ1QEiUcQzCDIgKVFmZjajKrgaEqcpIuM3bNp1mfi6NwRJYkfOelekGqVUFwop7sLdfXcAeIE9nSdXwyMq2uAD/LcflMfEdBUwSVQC/KavQb5fwH1Qjqg/KeXjM3nxrS9KmGALbAgaHiNRqO4R5LkgaWsb98lToNveB0q5UytemyZjn4MGv36RvCIUOouSSC2YEAc+zgJzxVKaDx5i0cQWAvxM5XxCA3II4k2EFVc2BpvTF7aOMwseWUi00F8Y+Z1UXIpnOxHP5R6k+UmTM1jc2Ol4SlhzqRlObiGvf0l0o23F97gDcxBZFI6p00021Oug++Mw3axsdNRrbblx7JqU8PWUMS4YsxYBkC8LC5B30Gv9plVwxbW6ka9XUcRb85nqrDPQH7Zzqc1OndrWAyM1v6z6z11NlIBXW/Iief6KwoRGJtmqG5PIfKD4G/jFK2KYuxS1kIG5F+dj3X8ZrnyJfr1TKeQ8T/xFKuEzaswAFzZVAvpbUnXfXwmXhsdVUgu3VYZcp3zHY3lxj2bMuoI01B1/WLZnoAAc4p8c2Xw5+U9AdNJhYBC1YOflpsO86AHyJ8ptkznxM1eqq5gXMuxgWM0yqTLq0ETLK0mrhymYyhi1JbamWLzpzENhoE4Smbm2+vEQXvJdKsuSmqPgF4Ejv1EUrUmXceI2M1FeWZQRY6g8JLzDWGTOAw2NoZTfdTseR5GK55y68WG6ZjSHSJYcXPdHbyz0pkicl5y09DKhlGhCJwrAAwgKiRtlg2WBlYjD3mZWoEG40I18Z6KokSr0YHaD5lUnewv3xTFtqF1NgM19rE/FbwPnJT6h7JkdO44oHYED8Mkk26ozbX52v5TnVjGxvtKaZenmBakzp1yXYr8hJ31HEnWZh9tKgB/Dp301UuoPO4v6TzOLxpqOz2tmN/7niYGxMYr2VP2+ZQPwBe//AJTa2t9bXve00cJ/1Ep6B6VVdd1ZKgA562Jnz33Znfdxg+5UcatVEenZ1qKGDDq9Ujc31HK3OdpYM5rkAAnMRYeM8/7ANbDBAbjMb3V+qSWLWJFrabC+t77z1VA6eVr8htJnoW6Vr5EsLZmsAOZmdh8PlXfXUki2/H77YPFVs9YtwTq+N9Pr6xnPZfDaNFq6dTTW2toEVwesRlYC2v34xlz1O8c9hbsmS9Qna/d+esx1VjQ9m8XnqVgfkFP1z/8AzPQsZ4z2VrgYrE09r06DgdmZwfqJ7RELSc/F6+gOYB2jj4c8/SJ1MJU4AN3H9ZqyswIvGcGl+sdh6mZruQcpBB2sRYzcpJlULyHrxk59pUdoF3hHMXczqyheQVYuxlM8K06dWNU6kx6VSOUqksQ/UQMpU7EWnl67FGZW3U27xwM9LTqTL6ZwmZ6TjbNlbuALL9CPGc/yc7NjXNFwyZVF9zqe+WLwb1IA1JJ5ErdnJJJ3RJUiWnDAqRBusJONAAwgaiRhoNhAzsRSnj+mvZ9KjMxLjNuA7ZT4bT3VRJn4mheTB81b2ZVdpVuhbT3NfC9kUfD9kYa8U/RpHCDTo7MyptmZVvyuQL+s9hVw3ZFHwvEaEa6c4xdep6E6DpYZGRC5LMM9Rt3IuBtoBqdI9iquRW7tNCNfu08/VxjstOoGdX+HS2Ustw1xzIym1pGqsVOcliSL7znaruHosbaXuxLH4b3MfemGIHI3BBIiVGnUupUqq3zPdcxZTsA3Mfn56NEDfv4aH/mSC9QArYDa40BXbQzEqrrmvxtfkJuVNRrxve44WmU9Fr2ubXO4IJ++cx0sLdFYd1xqVVByPRejUNtAbh0JPPqOP5p7UYxEsGOUE2Ex+icGUu5Px7DgoGxtz1iWOxWd8qnRdO8fZ+k1zMhfa9SmLpttUU32ANr/AJyzsgNyRe1rlh36ek8vSTVstxpqed+XlM/E1mNh1jlOm+v3rNXrEx6OpVWpXQLY+71bUai1x5G3nNRjPE+zFVmxdQG9log9lyVA8gD5z2jRz806DcwDmFcxZ2mmQnMCTCOYFzCrq8ZpVIheHpNLEa9F5fEm6N2C/lrFKLxlm6pHYZb8SMV8T2wPv5htju2EFQnWeWda6XnH0WSSSephJJJJRUypEJKkQBssGVhiJwiAuywLpGysGVgIthxAPhRymkVlSkDHfAjlE62A7J6FkgKlOB5rGIEpdY5Qaq5WOyvawBPC+g7yJxGva44DSx175utRVlemwurqbjbTY92885h2yZkJDFCUJJ1K8GJ5ka+M49eVqfGojZthp4wtEHXf5SCTfgBYX14esUpPoFy5SBYAAWFtjpoBGKNQklbWANg1/i05cI0NCxNuHhtyh8inU34C19+yARRpa3hG0Uaef34S5oB0niQlMkkAsMoG2ttbeExsEl1Lna/G3pL9LVjVfIrELa4ItpcXvr2c+2FWwQKtgMugG1vu8A9LVe/Xlcd0x8TfPuQBcC1+NvXSbNIC2nLkN7cZj49znvoNbD9Jjq+rIH7MVD/j6wPzYZeFusri/fownuSZ4HopsmLpO29RalItbcFQ4v4oJ7xATN8fE6DeK1Wmm2G8YrWwdM7vlvpbMN9+M0yzXeUJha+EVdFqKx4KRv2XHGKipIq0LTaBvLqZpGhReEr1gqknkYoj2nmvazpzIjKpuSCABqSTsPOLchID7GUEqN/iKpGRGIVCC2dxY3tyH1nvE6Uon4ToNNuM8j0LgilGnS0vTphm1Ny51b1JjCMuthxPOc/x85Gurte4kkknVlJJJJRJwzskCpnDJJA4YJpJIFDKmSSBRoGpJJAW/e/gf6GeVxv7dv4aX0Ekk5d/WuT1Lb+Yf1CaNNRYaD4zw7BJJMqJh/8AdOZjnH+k/wDVJJLEYtD4mjZ3/lb6ySRA3S2Hj+UxsfuPvnJJJSM1GPvaf+tT/rE+j0NpJI4/p0TxVRrPqfhfif3TMM/GO3Lft6kkk6T6yYobnub/AGylb43/AI2+skkX6LpLiSSBXEfCe6eC6S1xNG+v4i76/NJJM9NcvdUfiP8ADEuJ7/yE5JLPiP/Z",
                "https://5.imimg.com/data5/ANDROID/Default/2022/2/ZB/HX/DK/7349419/product-jpeg-500x500.jpg",
        };
        return urls;
    }
    public static String[] getGroceriesnames(){
        String[] names = new String[]{
                "Sunflower oil",
                "Saffola honey",
                "Maggie",
                "Tomato Ketchup",
                "Eggs",
                "Milk",



        };
        return names;
    }
    public static String[] getGroceriesdescriptions(){
        String[] desc = new String[]{
                "10% off",
                "100 % pure",
                "1 Nos",
                "100 % pure",
                "Pack of 12",
                "500 ml",



        };
        return desc;
    }

    public static String[] getGroceriesprice(){
        String[] price = new String[]{
                "120",
                "530",
                "10",
                "139",
                "72",
                "40",


        };
        return price;
    }
    //Fruitsandvegetables

    public static String[] getFruitsandvegetablesUrls() {
        String[] urls = new String[]{
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBQUFBcVFBUXGBcZGRkYGhoZGhcaGh0XGBoZGBkXGBoaICwjGh0pIBcZJDYkKS0vMzMzGiI4PjgwPSwyMy8BCwsLDw4PHhISHjQpIik0MjQyMjIyMjIyMjIyMjIyMjIyLzIyMjIyNDIyMjIyMjI0MjIyMjIyMjIyMjIyMjIyMv/AABEIAKgBLAMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAFAQIDBAYAB//EAD4QAAIBAgQEAwYEBQMEAgMAAAECEQADBBIhMQVBUWEGInETMoGRobFCwdHwFCNS4fFygrIVM2KSB8IWJKL/xAAaAQACAwEBAAAAAAAAAAAAAAABAgADBAUG/8QALhEAAgIBBAEBCAEEAwAAAAAAAAECEQMEEiExQVEFEyJhcYGx0TIUkaHwI0LB/9oADAMBAAIRAxEAPwDyY05aSuWoQdTkFNmnLvUCTqKlQVFNSWmoBLSrUtsVEtSoYqBHOlTW7elJM1LGlQJTa1rXGxpVrLUV4wKiFZSyQa51qZdaUJRARKtcbdWlt1xWoQqqlSBKl9nShaJBLWGZjCKzHeFBJjrpTLlllMMCD0IIP1rZ8BJt22RIDEAs/Qnr6CdOtFLvDbF/KDmKWtyfMztHNtyOcbVnedKVVwbpaGcY2+zzbLXBaJYzhz21W4VhLhbJ6Aka/KqapV6dmJquxAKQpUuSpMlEhVikK1YKU0ioAgy0sVNlpCtQhAVqPLUzLSFahCEimMKmIpjrUIMikIpaQ0CEbCmMtTZaaRUIQRSRTjS5agCnSrSUtQg6nqKjFSrUCSgVKgqOZqRBQCXLdPFQKaOcEwVu4tx7phQUWQYyzMt0PIa9aWUlFWyyEHN7UUEWpzRbG5LguB4S7bZvNye2CdG6sBEHmBHSLGC4Zh7kHNcyXBKMrISsQGW4kTo0idBqNqqjni1bL5aScXQBU1G9rNRDGYQ2rhRiDzDDZlOx7enIg1ESOVXrkyyi06YNKRUoTSnPaMzUiWydFBJ6DWiBJt0hETSkKUTscGuNEkLPqT8hRC14ane6f/X+9Lvj6myOg1DV1X14M0y0Q4TghPtG2B8s9f6vQVfveH8pGa4Y5wv21q7ewS5AtsjQQBz+VJPImqRu0Xs+UZ7sq4XXnkF4/FZRltsD98xp+G4ybahde/c86oYnAOrGVMfn61Re4J1BnWeoqnYmdnIoyVhnjHEku27aJMKANe07fOhSpTcGnl3nXT02qwq1pxx2xo8nq2vetLpcDVSldafFNJqwzkJWmhanY0gWoQjIpjCpnFREVCEZWomFTtUbCgQiIpsVpcDwFWt3M7j2hhEAmEeMxzE6H8K6dTWeZYMEQRoR3FJHJGTaT6LJ45QScl2QlabkqY1xpysrkU0rUjUgFAhGUpsVYIpuSoQE1wpTXCoAWnrTKUGoEnSpkeKrrVlFmoQtIJFFcBejD3VmCXRh/tBB+9CEMVf9gyW/MrLMsJBGkAAweWh1qrIrib/Z0d2ZFl8dmtj+sArtyhQGn0AEdpqrg77W4Mn3pWCRDGJmNIIGvLQdKgRyFgD96/rUuFtzuao2JJnceK7SXYV4hd9oucfhZh2yNBB+c/OhyXKL4HDZsyQcrCPSdjr6VO/hG8Nbbq47yp+Wv3q7HNJUzm+0dHLepQXa5+oPwmFe82VdhqTyArQ4XApbGVBLcz+ZP5Vbw3DmsWwmUhjqzRuegq3Zwum2vT8zSzk5dGrRaeGGG59vyVrds/3q4jlRJ260mJtqoliKqWcYGS5AnKNI6TqTSP4TbOacbfReTI28H9Kkbhdt9RK/6TzoTw3HLcAYqF3nQRBkZh0IO/pRTAYjIxRtp07VITjIpcpVcWys2DZfK/mXk0ajpmHOgPEODqzEwAdda3zhWGh6TQzF8PnbQ9aZxa6BjzKXEuDzy7hDbOQiI27jqKYBWsxOALeV1noRy9KzeNw3s2MGR9R6irsc0+DkazQzg3OPK748EDVE4p+amxNWnNEUU5ROgE+lGOHcGz+a4dP6Rv8AOtTgMCqDRAsbdT3PSqZZkuEdDH7Pk1c+PyYZOGX29225+FMvcMvLvacf7SftXqAzHQt3/cUl7LHmM6af5oe8Y/8AQw9WeSXEK6MCPUEfei/BuHOFN7IS2gtAjSTvcPZRt3+FavH3VPlCKRvLQduk6D4UOuO5YQ2m/Sfh0qvLkbVIvw+zalubsdhbfsrM3U1JzMZDHMd2aNANhWaxmDe/fuNbAyliSx0WSJOvPWdhRzi3EbaoLb5vNqzTogEmD1JIAygE6HtVbh3FxnW3ZTMXIzMRAHMlbaiBPcnflWWF47lHtj58UZ/DLwyo/A7du2bly4x7KMinsCwLN8hWduRJjQcvTlRrxDxNr1wiIRCQBpMiQSSPoOlCGSt2FS23N8s5Odw3VBcL/JWcU2pmWmstXFAi0ldSTQICDSikrhUAOpVFIKeoqBJkFH+AcAu4kyvktje4wMeij8Rpnhvgnt2z3NLQMd3P9I7dT+x6lYtBEAjLAgKBpHIRyqqc64Ru0+kclul1+QNgeD2sMBkUO/O44lp/8Rso9Kh4jw9brF3ZiTHKdulaYKoEnelBUgnkOdZ25dnXwuGJVGJg7nBlYgITH+k/eanscFUHVW+3xraJi0gwRPTSltX0LQdTGp9dtaG6Roepa/6gnh2Dyx5I9aN2kj/FTErprSGBBBnsaeKMmTK5+CZkkQdvpQbHKUOxj1+xq/cxJ6Gq13FKVIIn9/fegwYVKLurRi+LYw5srkgzt26967hGKy3kBHlcMh+OogesVPxzDB0zKPMknuV5j99KB2sVBRtTlYNB5wZI+WlD+cTsygp4Wkgth2Np3TWBdcKdwUPIDr5gdN9d5FGsI7uCpHmQSrCNUgEKYO8HT0gxVFyl8LctwVkEjQ5eRnbXQT6VLh8y3JGYdANiNYMRqdRWdPY/ychb4yCicRVRIJBHLSI7ztVa/wCJJPb961Q4rZIZio97dRv6gcxQpuHu3u23JnSfStW5nTx4MTW6QbXjqkwdII30oXx9lJVhB15a6d6rf9EuhodratAYozgNB0BI6U29wq5MM9tdNCWOUwOwPzNDovjHB2n9vUoKQdqIcLwJc5jooOs6TVTDWiuYNuTGhBAA0kEfejNm4YW2pAXSY210p5ZHKNHNxezseHI5rn0+SDyXIAjbkBEfuKmt3wW2J1Mk/vvyqnbstGkmI3gfIU9hlM5jvz10mq6otcUw7bjefhpUV8yDJ+HOqeGvkjbtpqO81bS2TpI9OVMmZHHY+TO8RuQD23J2jtQEcQYT5oI11mDyEty+FbDifCWuIQdelYbjPDLi6beum3IdalGiOWKXBQ4li/aZZLE6jeR696u+Hma0zMGKn3PKdddT/wAaCFGXTL9Ku8PDFo1PMev7NRx4pAUFM0nG/DmWblmSNympMf1KeY7b1mq9RwjFk0EaDToY2E1i/E3Dgj+1QQrGGH9L9Y6H7jvV2OfhnG1mk23KK48r/wBADpULrVmmXVq05hUNMp7io5okBRrhXUoFAgoqzgrBuXFQbsd+g3J+ABNVwKP+GbUM1zmPKPjqfypZypWXafF7zIo/7RsuHolvKq6JbAAHU827mZ+dGrl/KMzEDpM/E/Ks5LIimOYOvao8ZxRn09Bppp3neslnqVgVJINPxgTpr3/xUT4p7kw2VfrHSs9av5TO4nb4bzU78R06aGdTFRl3ukukF7bmQO8Tr86X+KYNqT+yO1B7OMnntHxnlVnE4pZ57Toeo5UtMksXITTiR66A84M1fw/EiYk/Lp0rKF5GmvM6jl8BRDAXRvOwn8vtFG6FlhjXQcxPENYYekbz86prigR3J6Dl1+dPa6uvUA7z8PhQTGYxVJKmTqP2Z13oNtkxYfFBB7+mu+vfTUVlcRg3a6VRSZ1EdDPPkJBGtHuDYdr5LbIupJOnfUcuXer93xFbw2RLNkXXZC4KtJEEiGABIPaOdGEWnYc2dYuFyyz4U4C9tSX3YyQNuXzOk1pjwdGGiHMOgjXbflWOseL2YguWtiPMECyrdPMNY03j0rQeGfFRdf56lFzFVuMDlfnOp0+UaiJouEZHK1Tzfyar0DFngCkDOF9I6d+frWV8RcTFq+MLhkykKGd5CKAxgQRrqeff1j0O286hgVIkEdOcV5H474Zdt425cQZkvBXU5lEFIVlGY8jrHRxRi6VIzaXLLJk2zlwJjGe09y8yBgzLLq7XGSFg5vaCfNlmdhlAoXxK4HYXLZALQCAR5iNz0H2qG3hMZi1Ps0JUEiQygEjeCza89qs468Sv8OcIiXFAnLbY3BGoIKnUERrrM0JJvlnaxZIY3UabXm+aFR2sEEm1cDzp5WCnmGVhAkEfLtRXgmHVwtwkZTMhYIUyQB1GgFA+H4MXFm5fS2RIIKkkRyfUAajarGH402QnIYWQuUZUBYr72mvlWACfxVOi15N9135fX9jdsPLKiB16jl9qpXHRVJeNBz6/lsDQnEYtVQlLyqJ1UsTDdV6r6dqE4x7ir7R2RgGhkD5iDvqOYjmJpnz0Uxx12/2aCzjp2PSrP8aVgCZI5VksPxMaEafuJ9aInHLCn4/LlSchnjV2bLBYtToTrz/fWqvEsElxp07mJrN4finmJOxoliOJ6CDGnOdatUuKZQ8LUriDcXwJWLFRPx+nYbUzBcHyg8tZ/f1ojhuIFplh6RTL+PHLSd4g6UrZqxykvhLtnElQNdz36VWx6h5mMrKQQPjr1oS2KMdR8RqZgj41McbAltDlII5gCTI9PtSttDvAn9zJ4hCrFTy/c1C71d4l+FtJ1Bj/AMY/Wh01rhLcrPIanF7rLKHoziaipSaZmpigGAUsVwpahDlrRcFfLa03zsfjAA+wrPgToPpR/hdtlt+ZSNSRII001qvJ/E6Hs1pZufQPNjM6AxAGlC7jiTy/LrFcl7Kkdifpofn96pPe1/zWauT1PCJWuiZGkVHeuk85qFm0+NRlyKYVzRYt3yO/bXlV21ipnn+4FCw9SWXg1AJ2GlxWx509MWB8qFvej16VC2IMEf5FDaFyYZuYsZYmR6+u37+9U380AH3j9zQ725q3wo57gHIQfjyH3pWi9Zo1tRtcVct4fCrbJAFwFWnN/wBtdyMpB/p9ZrOYAvbttca2ShJ853ZfwkrIYCNZjnNFP/kHD5Fw2pHkIURo3mh+cyPJp3rM4u/cKDOjR7oLDSTynkY5dqK6OVCSncr8vh+aJMQWLDEOUIZ85QlizLmkloEQdtTMVaxPHnvAhh5C3m/pg/hPw+wqtdt20sjztm1BVlEEHmpBlfjO9WOJ+0uWfaG2FRY5gQLm2VZ6KO+lGrHcl1JL7/hG68EeIGdnQqEtCMjA6AiFJ1OgJIJ5SfWiPj7AtiMK5tH+ZZJcCdWABDrpzjUd1rz28LlvD5UdREKw2kNpmDfi76CK9F4Hfe41vMVLexC3eZY6BLncQtwGY1A3BFBWczV4VimsmN/46PO+GtjbVo3EYIiKCVZkzDQLIU6bnbfWqvCMVirtx7ltxmYgHM4UtGsebeP0rR8d8N4vDm4LNl7tt2zLk80BpJQjfTbbpWfs8HVVzJfC3EnNbuK6+YakDy+X41E2boThNKmn5dLr6lfELdv4i4LzrbuDRs/lkjQCEEH1+tXeGYy/bD4ZERyJUjyshDSc2YkDWRzqjf4bfuWDixBA3Ue8q75m6DnRDhXBrxQ3murbuHRQ40MawSD5Tr0O9NyM5x6b4Xy4KuHwOUMuIuG2U/DlzHUAqdDqpncTzqrhyzjJoNxrsJ0knkKt2sE+JFy89xFYCArEHPlG28KIED8t6ZjMVY9hbS0kOGzFyBnAgggsN5OscoFK0jXjzSurv8L5lHiGDuYdwrkeYZlZTKsp0kH1B3ApiYlmjWAPypMarsguEErmyz3j961StXI/elNEST2ypuzQ4LFa6gDT1Ou1PxOIaRrI5a9Ikeuv0ofhGzAkzMzI/OpLzGeuuXpvUoKfIQsYggSZEjqaf/EQIJAnXX8xQxsTtmA0Hx6D0qJLvOJidoHOdalF1Be5fWAR9+cc/rUb3EcczpqNdBqJB6DT60FZyTv8hSpcI7cpqUPGSJeIvDFQNPe9ORFUwassMza8pH2qHJE1fj/ieT9or/nkQmoqnOtJ7GnswUEsN4Nun/uXETt7xorhfC+EQzce5c+g+lHVBG4BrktBtYI9Krbb8lyivQ7BYPDW9bdtFPWJNR8btKyowIMEjTvr/wDU1OmHI21+FOv4RnQgKOunUa0jiXYp7Zpnn15spI6SPhVct/arnF0K3D3H5RQxnpEeh99uimT56jc1Fnri2tQDyWiYGkL0wGjP/RUtsEvXCLmUMyIoOQEAgOzEQ0HUAGOtAO5tpR7YLL01nrQ4fBYNLZa57RyWGXXLC89ue9BMdhlFxls57igSCV80RJzAdOu1ROyTc48yVFVnon4ab+cPVR85AoI71f8AD7/zPip+R/vTNcFOLLeZL6/g9G8VcQKLkvIXtv8A9sqdUe3zHKTmB/xWd/gfZql+8qXUMLkUkAPExcEayNj/AGrS+KsTbuYNV8uYXLbzOqicub/+46Vh+IsZADPl0DZiCSdJI0Eem9BWuxoRTTVVT5+ZcwN/DZ3e/azLJAth2AUESApJnQ/euwztey2rk27YXMBGrKDK5S2h/wBUHaq97Ci5dBwyQPJKSXG3mZi2wJHumd+1EsaMbiGCG35rCxPkXyOAdSW80wIjapVhbinzx4dvn7EGM9mby27bXXtSAwOQM2ohVIHPuJ0raLhl4d7W4oKtcCLbTW4yWwYa4YmJkkDt6x3gHhCpauX8XaBuLc/lyAxCqgbMp2/EdR0oR4g4ldF9Lltzmulhk0BtwcqrJAgQNz0J0otUuTI5PNkcIt7V230wpgPFy2wFF97jM4WNTAY+/LdzsJ5+tE+K4O3iAP4hGLCQHRsjweRMEMPUVk7/AARrFhMQ1ti8sHIhgjq7MjE8pBTzdiBqRWp8McRbGWS1zL7RCVESM65Qy7/iE5ZnkKRp3yV5oKK95h6XDd82ZzH8EtWk9kjYgIwhpNtvso9aG2Ldq1bdbt64ytopEI47AeaZ/StJ4hxz4dM8GWMKp3zcwekVj7NorcOKvpmUkEQfcaRBg769Nt9aO0fBOeRJt8dDkwtrUW8Qch/CySw6yQV19QKZjeGhUyWgt4zn9oocOwmMoWSIHMCTUXH+K53AtBACS0qomX1ffRhOo6ZjS+Gb5t3GF0RmAInSIJ1j41OFyaqyN7fIXvWxcwj2/Zlco8hiS2UZo+YOvOsMp2r1qxjVu2nB1Ftys9VIDR8C32ryNvKxHQkfLSn4fKFbceJd8l6xfyjTbn+/3vRvhaWboiAl2CQWJKPEnWfdbTfbTasxmMetW+HXytxCOTL99vr9aWd1wGcntdOmTX1YFswggwRzn9iohciRPefh/eiviFAHKx5lgHup1We4mKCXQQYpYyUlY+n1Ky41L/bJsxiY/TSmE7QdftPemFW+PKuVCdx2+NOWPLwWLD7nqx/Sm3283rTr6hAqjlTbxmKviqSPMajJvnJ/MhJqyjGKqO1TI+lFlKZ6OcLcA9zTsaitXGXQgqekUZW8esdqhxGII94AxOpAiPWq7LqKn8WNsw+lKMURpWf4l4hwqtC2xdPMr5VHx5/CheJ8Sif5VvL3di30H60rkhHkSLHizDT/ADANDv2P7+9ZJiaNnxE5UrcRXU9CVj70EZ1J0lfWD+lDjwbcGsio7ZMSlJqNrkb/ANvhS56lG+OWLXDNf/8AHosnFRdWfJmQkSFdGDBm6DT5xRjxDw21auPiGdbntGBW3OpZpJZuZUR7v5aVneBYK4iXLpiHtH2ZVlLFyDAyzPUH151WxOMz25clm5Gefeg6RZhjNyc0+PK+XyLuKuWShLsM4mMiga9DEAr9qi4NxZbXmUHOWBJgHQe6g+M/TpVWzxFFCZbYke8W95j68h6daUved/aIjwogMqk6a65gN+U0tf3NDmvs/DZFxrg162n8QyBEdyuUbqdTBX8I7dqEcPvZWntFaS3jLlxRanPLSV35j3p0AoVjsIEvOGQ2wCSE6TqAOq66HmIqyLtUYtRB4ZrJFp1yekeE7eHxSD2qqWAy+bUD19RP0oJ4owFm3edSqhVAyqshQGBhpB11FAuB8XOHuazkbeNx3HejfFOEi5N9bkpcVRnLABGG5uGNRA07mOkrdKmaE45Je9i+GuvmA7WOOHMW2aGVGmdc2UZtomDIHajnAeBYnEk3MPdi4T5hJkKSfM7TvuYj40N8N4tLBL3rZe24KmUBB7AsI+Heti/iVeHWrdhLRS4Ve5knRPaOzW1uaGWCsDl5aVIpeSvPlmkoxXL66+9mnu8aw+FtrYuOLZVTlZpbkfOwGrHn3JivImUXEuNneFLG3KqZAJAzkH3iANtN6N8Mu4K+9+5iixZgcud2JACasCdfek9pAqnheH2ksXGXFRcVGYAoApPJRmEmRsRrPKi3ZXgxe7tc2+wt4G4jcuG7YbM9k2iGQsdAfLCDrDH6UmAvNaDlc1v2JEo0hjrrmXkdv1pvhHjlu3dt2kSFdgogDOCRHnP41aBI+OkUc8V+HMVdvZrSA273svalSoZGWFZoJHlyqp0nY0jja4GlNRyyjkSSasN+JuCDGYdWQqXXZpPlzL+KOhC715XxTDYi2Vs30uIDDKG1X+kOpGhidh8a9iwJW3YfVyzdPKSVXSOh9dap+IHe7gnOWGCZgGVXDZRqAGEAwDqI7VY48WYNPqJ45OC6bPMrH8K1v2Yg3XyKHKEgEGMwltGJPPQdK0+L8G27paHdiAAreWFC9AN571m8PxHOluymVc7qCqoI1MGJHQmvRvaJatZQIEZQBAJAEQKSLTR1c27HJV5M1iMmCw2WdEzEnQZmM7+pgV5bM6ncmT670Y8Wcd9q5tqZRTqf6mE6TzCyfiT2rPi5NWKLSMeXUxlKk+vyWQ2n2q9gHCfzOakFRyLTIJ7DKTHpQy3LGFUk9gSdeWlHb9rIqWgMzrL3CNs50Cf7Rp6k1Tk4VGbUamoNJ8kd/FsSbjnMzEkk8zH+PlVR7uYmd+VT33ViAw25gxBO4HLkOVQrhk3DntIj6g/lSwaS5F0mpjCCTZMiEwN+XWr14C2FU+8dT2HIUT8M4C3czasSoGsaa7H19RRY+Drbam45J3JYan/1qyDjdstz6lzjUDD4i7mNRXTpW0v+CF/Bcee6g/pQ7E+C74910b1lT+dXrJD1Oc4S9DLZ+tW7biKsYnw5ikmbRIHNSGH0M1W/hnGhtvP+lv0prTFpo9Od3UaAfD+2n0rKeJcM14qUPnHkZQdxuOfr86172lG2lDcXgQdZHrz/ALUjSY0laoxKeHrumYqsmNTSYjgNxNyD8gsf6iaLca4g1slSwdjGh/DtBYDfrvWbxOLe4ZdiT32HoNhVTr0MvxJ8nLgifxIP9wP/ABmormDj8afM/cilRzyB+AqdsM7D3GP+0morCgymBs5PZi2pAHmaWDlo96ToNdhEfeoMH4bsvBuYgpIJyhc0EGN/7VHaAyL7TMG90hR5sojVpiD96XBPbmLjlYMSBBI6kmYPaKROVnrYYtNPHFpNIfjyll8tsygVQu87Qx15kgt/uqpbeyVYOoDktDFmAEiFEDTTfUVZx+JFtg1ly2YFWLAHYg6Hvp6RU2CxlnI1y4q3Lr82MhFGgERM9/SmXzBkd1GK+ngq2uIXHSEtsY8soGyzGmg0+FMTHXSQpLGNBb10A/CFGwgUljiz2yQhhAzFV5ATOlMuY2/DvDKlwjM2UgEAZVXNG0Dam7Kk9rT4/ROuJuWyWcQHYncNJECCQdx361Sx2I9oTA8xjL8JGnao7l5mjQkJqTBIA0AzHpP3pr4tndSdcogdAI/Wgo82TJmSg4uqLAsqRH25GiPAeMvh2Nq5BRtCGEjXnB3U7Gg4cjoabfcONdCNj+WnKrJQs5mn1LxS+XobF7GIYeztqCjnyETCqxncaACs5ji+d7dxmLK7atqTBjNJ6xvUnh/xLcwzBTLJ05juv6Vob2Aw2Mf2yXgjEywy5geoiQVnvVbtcM6yywyvdFL6eQQOFJ7FLpc5mEZfnqOZB0qbAcHe5IfMFAk+YenfnyrVX8BZbKC4KrEcthHarlxrfLLtqeZqlyLpSqNR7fn0AHh22mGufxLIVRJBZumoOWecjkPvVB/F15rL2mLuGnK+ZlYayDKnX02q1xbhdtz5mYCZy5/L6hZgVFZsYdYCqhYbRl5dzzplOujOocuU1ZF4e49irIMZ8kgmFJ2mRFbTD8fuY3yPbdLawQWABZhyy9O5rJXuK27ZVbkDzKWAJJySM0QN4mofEHGQlx0FwZRBAUamRI110136U8XJrgr2YpS3tpV5NY4s2mLIii5zYAD5mNqxnirxPcug2rGZhBDOoJEHQqp6kbt8qzeN4q93yyVSdQCZI5yahw7MDIIZf6ZMdhp0p1FrkyarWJrbi+7/AEQYfhtxzGXL/rlZ7CRrU/8A05rb5HQ5xvm90dxyI76+lF+E2nIuuihSlst7zGDmGzN7sgEf5qtdxudpff8A1M3zZ9fhtSvJK2vByXY5L5Qj2ZMjTNz6HKNl+/eoXznQaD4yfWieENo8ifjFFV4ZbIBVpnlsfrtVHvIJ/E/7iWzI+yaprFrXzUcuYRFaGOVtNDoeXI61Jb4dLgiSB2gzVn8uhoJydBbgV32awCBOs9+k1pMJxF9Zg/agGEsldDmHw/WieHQawZ+An5zR2o3R4VBpMX2mekflTw4OpWPlQ+yxEeUHoSxJ+U/nVqyWYxlI67EfWkcUPYl9hrlBY9IqqXuDTJ9aLNhoGrKNJiCpj561T/6jaXTONOsT8aC+hGRWrYb3WB9DrXX7Bg9dYn6T2qjY4cfwkN1iD8xUvsLg2zD0Yj6bVqozmNu8GIZjfDSdcx90/wC4f2qs2Dt5hliOQGv51uWa4NzPYgT9KqDDISc1u2T6T96KVFLxr1M0mGAOi1cS6q7kD1Ioq/CbDam0OnOPkKgfgVjklsc/dHP1o2BYvmZviCW7lwG3cAdoB3APefSqV7B+zkMCe/L1Fau5wQD3UUeigUPTC4m1KqiXEnRXGg9DyqqcG+UdnR6tQhsn9n6AbB8UFpSq21nmxEse2v4e1VECBQ4b+ZObKQuTQ7fLka1ljGqW/wD2MEFI0DIgYDptJ+YqDieBwlxi5W+rn3lC+Ukc/d3PagrXaNLlCfKaA2M4s9xIaWZiJnVTlII025Cq38dcZWUGA+jawDz1/fKruMuNlyWbD5RpOUrMdcwk/Kg7cKxNxgChknQDrTRTfZVlzwj8MeX6L9kN3HGMmeV5xtS2byR361o8P4PtoqtibkTuFB0HUk6fehuN4TbDsLDF7YgSd/iIpoyi+EZ8+HOo75VQPLTTShP7/WtHh7tm1bVNc0S0ErLb+aN471SxlwX7gKLGVYY6S2pgt1MGJ6AdKimm6BPRSjjU7XPgB3bRFRpiGQyCQeoMGtXgPD6uA1y4tsNMaSTHWI/M6VTxvAgHZbbh1X8QEDl1Hepvi3TE/ps+OO9KkDE49fAjOxHeD96kTxJfH4vov6VcTwzcPQ+mv1WRXN4ZuD+0H9DUagItTn9WVbniS8whjI9BVS9xN266bdvSKK//AI6wGrfCCDT14B3n5flQ+AktRnkqbM9dxLuSWYknckmfid6iCmtYvARzB/8AU/lUzcGtIM5zFRuVEkE7SDG9NviuilY8mSVdszGBsENmI/zRG3h8zALAncnQQNSY56CtNY4ErLmty684HnT/AFruB/5CRTH4UANPtSue7obJgnidSVMoWnKrltyFkFj+Jo2J6ASdB9d6hxWBdZZbdtl3gg6SYAB51es2rinS2XHy+saUVs2Ga2quAvPKCSJ1gmTvB6DeqIxlGVsyxhPeZFcWq6NZjupg/Cr+D4qgIGYgdG0Pz2NaB+DI24/f5VSveFg3u/KmyY4TVNFrx2FcOy3ugaBHc9PT7U7Dvl5fSs+mAxOFYMAWQbr+h5GtLauK4DifOM0dCdx21mqcMJQbi3a8fobHa4Zet3+31+HSnqynYVTZCRGvrTWzLz+Yq/bZduoP4IIdyPQ6feqvGOPW7BKTLDcD8Ohjvrpz51QR2GupEb/5puJtJc0uWw3czP8A7DUUPd32Td6Gc4hx+7eY5nIXXQHaSZE/T51UspInSjV7wzbJzW3ZTyVhmERETofvSW/Dt0CMyfX9KtpLoq5M/a4rdQxbuMg30Yx02mKNYTxPiU81y4HG0MoIgDnsfrXV1RkQUt+LUAm7aB/0GD9TRJeNYRoBYoT/AFKflI0+tdXUBi4Ftt/27ltj6j7VL/CE/gB7rBpa6puZKQ04eDtHY0r2l50tdRIRtbtnTT6VE1leoilrqICtdtjlFUsXgDcHlfLz2ikrqIYycfiQGxvh/EXD5r4I9G/WrGA4IltcheSdz/aurqWMUWT1OTKqkxz+G7D6xr2lf+JAqtisFZw6yqAsCDlaSG9e1dXUJxVFmjyS99GPi0UsRxm7iAuHMBcwOwEHqCBoBO1F+G8GNoa3M06k7D4bR86WuquCN/tKbVRXCCC4cbsAe/8Ac7fOnLhy231J+/mj511dTnJHnDtsMv0b7a/SmtZtyA9tdewn5nKfpXV1FpA8nLw+yfw5T2Yj/lVDi/B7jrCeaNYY89txXV1I4ouxZHCSkuyjwjD4nDsWCuDyKlGHxkiDVz+Dc+ZtDudQDJ9JHwFdXUI9luq1c8sVuoizuuhc6bTG3yq7hcUTtkPXkY9DvXV1Wx6Mb7LVvFW9iQD3BA66sNPrU62cwlFBHZwDPbMa6uoMK7Oay86hhprmyGJ2/FHKo3VUgMUUcpGk+u31rq6qx0iZEETKEdQVI7c4qUYMsNVkHp/Y11dQ3Ow0SLheQWPp96e1mN4naNJ9fSkrqYAv8uNpPOZ/KoyB/R9Wrq6igM//2Q==",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBcVFRgVFhYYGBgZHBwaGhwcGhgaHBwaGhgaHBgYHBgcIS4lHCQrHxkaJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISHzQrJSs2NDQ0NDc0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAMMBAgMBIgACEQEDEQH/xAAcAAABBAMBAAAAAAAAAAAAAAAAAwQFBgECBwj/xAA/EAABAwIDBQYEBQIFAwUAAAABAAIRAyEEMUEFBhJRYSJxgZGh8AcyscETQlLR4XLxFGKCssJDc6IWIyRTkv/EABoBAAMBAQEBAAAAAAAAAAAAAAACAwEEBQb/xAAtEQACAgEEAQIEBQUAAAAAAAAAAQIRAwQSITFBE1EUMmGBBSJxkaEVI7HB4f/aAAwDAQACEQMRAD8A7MhCEACEIQAIQhAAhCEACEIQAIQhAAhCEACEIQAIQhAGEKI3hxb6NE1Gh54bkMbxujo3lOfRabu7bZiWcTSJHzAfUfcaG3eu5XQ211ZNoQhMKCEIQAIQhAAhCEACEIQAIQhAAhCEACEIQAIQhAAhCEACEIQBhNNo49lFodUdwtLg0Hqch6J2qR8WK3DgYmC6o0DwDnH/AGpZOk2jYq2kW3B41tVvEwyJiU6Va3RwTMHgafGQ3s/iVHG3af2jPdIHgEzxe+QMii22jna9zRl4nwUp5o40tz5CVJ8FxQuc4jb1c51HDu7P0hIN2zWabVXz1cT9Vz/HwvhMWzpywqPs/fMt7NZvEP1NgHxGR9Fa9n7Sp128VN4cNRqOhbmF0488J9M0fIQsKwAqhvDsp1B/+NwwhwPFWYMnt/M6BrGfPPMXt8rBStWhoycWNNm45tem2qwy1wnuOoPUGydyqjsppweMdh/+jXBqUuTXD52D3lwqxbQ2lSoDiqva0aSbnuGZ8EJ8cmyhzUeb6HqFV6u/GFGRe7qGED/yhFDfrCOzL2/1Md9pRvj7lPhs1Xtf7FoWCoClvfg3GPxgP6mvb6kQpjDYtlQSx7XDm0gj0Wpp9MnLHOPzJr7DlCELRAQhCABCEIAEIQgAQhCABCFhAGULCwXIA2QsStHvAEkgAZk2HmgDZc9+KLuN+CoRIq1CCL3l1NguLj5yrNit7MGyxxDJ/wAp4v8AbKpe3NtYfE7SwTm1GmlT7TnmWgOBc6CXRHyN81ObTVHRixTTtxdfoT29eEc4MY97nNEEcMNE3AlosYj1VVbhY+V3gRB/ZXjeGqypTbUY9rg0weFwcIdkbHmB5qsuYLnxXk6qDWR0c0rT5Ix4c35mnv080k93JTtKlbXqE1xOzWkTEHp+2X0UVB9mWV3EE6FI4XHVKLg+m8scNQfQjUdDZSOIwTgbdruz8kyfQzsqw4Cy7U9/SaEilNYWdfsgfr5x0GXNVvG7x4qsTNYtH6WHhHd2e0fEqMoNLHAj34cku5gDg5vyuMRnwuv2b6aievKT0+vNqj1fw14ZNxnHnw/cWoY6s10/iVfCo8Hxup2hvXXYI45/7jeL1bBS2zNmNgHiEkck+GwWEyTJ6/wqQ39nZmlp26lH+CA2vtqvW4Hl1KaTg9vAIdyMS4mIgx06KKxlVv4ji95dxGZ4uNzuQJ6DQmyvGH3aZeDmCP3Td+7NMPuTAvHX2E22cnyLjz4IN7ePsU7EY1jhwsa8CMiB4mx7lH8DjpbPwXVaOxKIEcA79Uzxm7tJxkS08xp1W+lQ8fxCC4SZQcHhm2v6lTOEZ+G4OHECNWuIPmEx2m6ph6jmOIc3R3CJg9UnRxJiOdwZvF9MkjXJ1S/uRvwzpeyNs8bRxGRq6wI/qAt4jy1U9K4szafA6zocL5x/dXrdPeVtSKTyA78vI9B+ytjyu9sjyNXoJQW+PRcULCyug8wEIQgAQhCABCEIAwme0cfToMNSo4NaMyfQAZknkE4rVAxpcSAGgkk2AAEkk9y4pvXvI7GVpBik0ltNpkZ24yP1HrlYd6ydIvp8DzSrx5JTb+/leqS2h/7TMhEfiO73ZM7hfqquarnmXvLnHPilzvPVNXv4BA/vGfa0ST65i0CbmDJ5XP26hQlJvs+kwabHCNRX3LDs/alSgZp1XNvcB1vFmR8Qktr7TfXcTUrF4/SXHhHQMFgoNgkkzAzvryFhmpbZmDY90F4aLjiN+8Cdch4pb4oo9Pji977/AEJPZdTAgD8R0GLgMeeuYaQckhVbhqmL7L2to8J4XGWgngGYcM+InyViwG5VJ3ae9zgYyygaCdFJ1dxsO5vC3iYcwQdef8LVFnDk1GHdzJ/6RQdoOp03DgPFEEOEekKT2ZtgPhpMHUSpirupiKeX4eIb/nADs7QY5aSmlXdsF3awz2Rk5rovnaDbzU54d3ZHVRxZ4qmrXn/hYMFTls6WWcQwR5pls01aI4Yc9v6Kg4HD+l47Lu4x3pHH7YYSWEOY/VrxB7xeCOoslcFGPJ4+TDKHgRxIBPNIMohxg3y775X/AHTCtjROf7ZJfAYsEgz/AH9hc7qyI5qbLMSBPSL+WqjnuLJb8pcC3kJI7JPj6Eq+4CmHgeaid4Nh8QLmiHc+ferPFS3IeDcJKS8Fb3a2wW9lxMG8HRXFm0281zDa1OpRqAubHHyGs3EjPmOhHJKUtqkCJyPirQlxwe/KEcyU15OrYfaQmZCWxGKBMgrmWG20QbuUo7bYLM7oc6ZP4O3aLdV2yxg4nPACTobdp1PleJ5G090rl2P2i5xguMC8de70TduOLCAReAb8iJBjujzT7mUjoE19S+7z0g8B1rWk2EE8z1XPv8QWOscveSd43aj+HhkkH6KFc+UjZ6GmxuEakO31yHE2OYnQg2kfZKM2g5jg9pggg+IUe6p0i3n1vqsB8EHPoRryjVHZduNUz0NurtcYrDMqz2iOF3RwsfPPxU1K5F8H9qEVamHJ7Lm8bR/mBv6H0XXV1Rdo+Q1WNY8riuvBlCEJiAIQhAAhCTe8AEkwAJJ6DNAHP/ijt3ga3CtN3jjfH6Qey3xIJPRvVcrbU1mfte58k63k2ocRiKlYkw93ZHJos0eDQFFF9yOIQNb6cuUqMuWe3pIqEPqK1K1zGvsoY64tl/eJ8Eg1xN7kD0n2Upx8lKSPVxy4HdOqJkjIzw8xMxKVpvLXEa3yIOUzcGMuSYuFyAZy565wt2Pc3pIIP+oEQfD6peS6kmdg3erH/DUjMywGfWFYsNiLXXItj7zmhTFOOICY6Xvn1RX3re5xcXOaAOy0DW1idNb3VFOjxsmgnOT9rZ2N1UIa8LnGyt6IaAXl05zpyv1UuN4Q4WMW116J9xxy0k4ui4PAIg5Kp74bOp1KZa+xM8DtWPiQWnMZXSR3kgTIJGk5z79VH7b282rStYyCJ01WSaaHw6eakr6ObVKtWk4tJJyiRmDcFS+ycVxcc2LWgg3HKbSR/ZR2PZJOp+3TzSWDqlhkWtH7JHGLXR1vTYozqlT+htjNrYiY/GqBvJr3NHk2AkW7YrNHZr1R/rePD5ljGU5YXWsVFcSaMVXQZVCEqSVEjUxj3Dtve7XtOLvQ9581q2vfomjXrdq1wSNWRIftxB0tfLl5pUYx0RNrSo5vl6pVjyNJkEeiRxR0QyprgVNTqVjjSWms+mkfdYabrKsqsg7GJdEcRgEnzEH0SbiNOV+9Jhw8Z8I7kF3p06z4pdo+/gV4gANSDcEWi3nr5JFzyb56/uteJJl6pGNEZ5CzfD3E8G0MORq/hPc9rm/deh15x3CbOPw3/cb6X+y9HK8Oj5/Wu8lmUIQmOQEIQgDCgd9sX+Fga7pglhYO95DP+SnlR/i1W4cEGj89VrfANc76tCx9DQVyRxGo+9z7yCSJusuPv34rV0WGmv3Uz2cchRrrkAmPryMLcuzEcr/ZIMz7krSdFwfZzSM64SdCzMpWG1CCY6jQ2Ig5rRsDU5esWWwv9VNo6Yysc4d4aZc0OEWmYnnb3dbOiMu9a4RvE4CbD2YnwT3EU47TRBFxHlkpbqZbcumaUCGgGxuBGt9Yyi0eKf4jEuaBe86EaWsRmo11KCZIM6jwvCVDOIgME6RrkOt0+4yUIt2LNxXyuZZ35iTmZkEcoWlTEnmDcmde4pmKZDjeL6rR7TIJBg2Bvfn3p7F2oWNSdAe8cxCRcyYta+mmd1tUq2bybboLkx9T4oqPsLRlz5ZrbOfMhN8cPDzBGX15qCDlLudPv6KG1I6n6qsejz88qkixbsbsYjGuIosHC0w57jwtaTeC6CSegBKv+E+EhN6uJF9G0/8Ak532Vn+GLWNwFNjY4ml3H/U5xcZ8CB4K4BLH83N8Hn5c01Jx6o5o74SUotiKgOktZHkI+qYYn4U1W3p4hjuQcxzPUE/RdcQmeNMWOpyLycC2lubiqAl9IlurmdseMXHeQq5WoddLZZeC9PphjtkUKzS2pSY4HOWie8HMHql9Nrpl4a6S+ZHmd7SDCwDNl1vbvwrY6XYaoWH9L5c3uDh2h4yue7Z3axGEJ/GpOa2fnEOYeRDhl4ws67O7FqoT6ZCl0m5t52FvskiRe3dfJKFma1a1ah5Sstfwyol20aGvDxuPgx/8L0GuQfBnZ81a1cizWtY09XHid6NHmuvhVj0eNqZXMyhCExAEIQgDCoPxhb/8Jh5Vm+rKivyqXxMwvHs+oRmwtePBwBP/AOSVj6Gh8yOAOMLVwvHvKVmqLhaqZ7EDdthPP391uD2Y95ZLPBYnK9hN7rLBNgJnv77JTqiYLjlCc0XxpkCkWskp9hWcImbpZJUUUqNcMCHzbLJPw+GkzJyHKZTZjMo6yLcxELNd1rExmPAqLjbHU7FHGACeX8X8klxw4QZA77TkZWtJ0CYE5wcu5ajP3mhRof1ODBBPaOQIBNsz7PksYh2gIIkkRl4TzgLeoez0ysmL3QU6RqmmKFxiJsTMd2X1KzUtbl7z1SZqa62iMsoPjl6rDnytSZDK7Nag/voYsSD4JtsqlNUG3ZPFfKxtl1XSt3vhk6tTbUxFR1MOAcGNA4gDkXOdIaYOUFWjBfDDBU//ALnHUueP+LQqc7WkeVlzw9RPwhhudUfQ7XDxNdY8BDwRNjLcs9bro1GoHAEGQVDYfdiiwAM4mRkQ6/mQn7MG5pkOm3KCe+LHyChihkxXxaOXPkjkluXY/QmD8bw/MCPBKUcUHZKq1MG68kdjHUo4gkS+FmSVqzXwZtFVpUYHAggEHMG4PQhYBWeJNvVchRQt5vhvRrAvw0UamfDf8N3SB8veLdFyvauxK2GdwVmOY68atcBq12Th7ML0ime0cBTrs4KrGvbnDuYyIOhQ1XR0Y9RKPD5K98Mdkuw+DDn2dVd+JHJpADB5CfFXJJMcLCw5cvBKqqquDnlJyk2zKEIWighCEACabSwgrUqlJ2T2OYf9TSJ9U7QgDyzjaBY4scIc0lpHIgkEeaQZnJEj3qrx8TdkGjjHOA7FbtjvPzjv4gT/AKgqSKd4yUmezgkpRTNmCQl6LIK3w7ASJHl9k4bTuptnZ4EwxKMPQZJRrbyFvTbySjDZxuIQ6T3pcU5WH2M9/rmgOhvpdY4tI8bpQtE9Em4JqMcjSpUMRomrjzStR6SrPMAaBajN1GvFpA0vyWzHQZFxIPeQJjzskJSlN4utZOUrPTuz8S2rTZUb8rmtc3ucAR9U7C5X8Ot6wxrcPWMN/I45NJ/ITy5HT6dSa5bCSaryeLnxPHKn14NwhYlEp7oia1GAgymjMKADw2nqfsnjgk2ZLnywjKSteBk2lwINeB2XOg6TbydqlQ285fRJ4vCte0tcAQear9XDYmiQaAD2yAW8UDhntdk2mOV5AU7UXTX3HSTXZZKlSBOaKbw4Sm1Ku4jtNA7j9ilmO6d0LHK5Wnx7GVSF+JYJSbnxms8SZZfDMoHBKMfofA/ZaSsFPGdcoxodISNJ82PnzCWXUmmrQhlCELQBCEIAre+ewG4uhH52S5p8O03x+oC4li9nPpPIcCCJBn7L0gud77bJAcXAWN/DkkkvJ16bK4vaczosGnct3tTirTAmMwkKjwIGf7Lm8ntQ5RqbnvuszaySc5KB0DPM39Iv5rGyiibR0M+i0dE8vuUvNhcZEC17/wB0i+0FamNKIi4JvUuek26DmYTp9kyr5lMiTXI2JutK75S7GZ+iRqNvmmT8k5cvgRgixn3kthTMSnGHoz75qbbsdxovf+gA98ESPKT4ITt2SnJRpP3GmyqkfRdG3b3tfRinWl7Mgc3NHL/MFzTAC8e+oVgpNsOSnNO7Q84RmtslaO34XFsqNDmOBB1H0PJLgrkWxtpvonsuj3kRqFbsFviJAqtjq2/mD9lscvhnm5dFOL/Lyv5LgVgtTbB41lVvExwcOhy7xmE5BVU1I5GnF0zW6FvKIS7PZmWacIWv4QGSUhZJRsTXKCxjiqLnDom4e5pgz3lSpKTqMBsubLpk3ui+SkZ+GMmVzMJOvtEMMOnyT11JviFTttVKjXFrgbXaeY5hcrjkx9srjjGbouWBq8bQ8WBmOvX0TxNdm0uGkxuoa2e+L+sp0vYxrbFI5ZVboyhCE5gIQkqj4QBs50KE3hoCrTI/MJI68wlsZioCqG2NsuaYCxjRu7KHj3cD3RrPsqPquEyCpDbFTjJfzz/dQVWpGei55Rpnu6WalEeNcb/x0S7Lidc5nUnNRza08h0708p1QQBPLJQkz0IxN3SD7yK1fYRyPilGVBGYNxeeSUdRkmD9PqsUhnEYvdInM9fRN8Re/opCrTifLL16Js6n0n6SqxkiUoDIPd4D34JRlHiK3/D0Pv8AdKis1sa9Atpy6IZJxguST2Xs3je0D+y6DQ2ewM4AOzEHrIuqju7Wv1PuFe8GLK8IUjxc+Vykcmfg30cQ+k4Xa7PmPyuHeCCpaOzOiuu8OxW1QKjR22iP6m8vD7qj4kFhISSjR34MymvqYbUjVKtrEyJv55Jiaov9Fp+JqouJ2RJnAY59N3Ex5a4cjn+6uGzN9KgtVaHRmRY950+i52ys3qE7pV5i9wpvdF2jJ4MeRfmV/wCTreF3moP/ADFh5OEeokKXpV2vEtcHDmCD9FxWlVOh9U9pY5zXdlxEHPIplna7Rxz/AA2L+SVfqdglC5nhd467bB5IH6jP1T5m9NWJLwPAfsm+Ij5Ryy0GReUX2VhUV29VQxDgPBpnyFki7eirHzk2mQGgj0hK9SvCZi0WT6F9JTDaGGbWcxliWu4j0bqD3/ZUqptes9w7TmzeAbH3KuW7GELKfE75nc84GS3E3klTXAuTC8KtvknAsoQu44wQhCAMFIVgnCTc1AEFjqZKqG2tnl1wuhVaEphiNnzosGTOO47CubmFA4lsaSu0YzYDXTIVbx+5Qd8pIStWXx5HB2jmX4o/db06omxj+R/Kt2J3DqaEHwTJ+5NcZNBU3jTO2OtkiGGIEZ8u5LjaMZftZPXbl4j9Hqtqe42JP/T9Ql9FFf6hLyl+5GOx4mfdk2q46RAlW3DfD3EHNrR3n+FM4T4au/O8dwCZYok5fiEn7HMw97rAeWamNlbvVHkEggLq2z9xqVPSTzKnaOx2MyaqKNHFPPudvkpuxdgCmBa6sTKPCFLHCgaJniGQmIOVjGvVgKkbzsY4l7TDtRoeverHtWqQCudbXxbnOISvktiuLtDMkHIpDjcEg/msNrEdfCVOUPY9PHql1IdjE8Ryju6ap0ytEOiRlE8tLX1UQaw5IBPsqUos645IMn2YqLX9D9Uo6ubGSM+V+4DJQQrOjPP3nC2ZiIHWfYjNT2P2H3R9ywsxHJxPW63e9xgRM5T7soSnizGQvkZ/i63bi+bnfZZtYra9ycplx+2nonmGaCbxPnkoBmN7MRKd4XFvLhwjJNHG32c+TNGK4Z0LYOzGlwe/+T06BXWnUEWVK2DUe5okK3YZhhdkIqK4PGzTc5Wx6CsrACynIAhCEACEIQBghalgW6EAJGkFqaA5JdCAG5wreSx/hW8k4Qg2xAYVvJbCiOSVQgLNRTCzwrZCDDEIhZQgBMsTathJT1CAKvj9jcQNlR9ubovJLmtXXyFo6mDosoeM2jzxidhVWZsPkmL8GRmCvR1XAsdm0eSj8Ru1QfmweSKKeqn2eeX4XotDhO9d4qbkYc/lWn/oShyRQLJXTODnCu5oFB3sLu53DoIG4dBZtQ3ry9zhjKLtQfAJ5Qw3JpXbmbk4caJ1T3Tw4/IjaY819tnFqeEcfylWHYOzH8Qlq6lS2DQbkwJ5TwbG5NA8EbTHm4oidlYThAsptjIWQ0BbLaIt2ZQhC0wEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIA//9k=",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAPEBEPEBAPEBAVEBUYFRYPFQ8VFhUWFREWFxUVFRcYHiggGBolGxYXITEhJiorLi4uFx8zODMtNygtLisBCgoKDg0OGg8QGi0fICUvLzYtLS0tLSstLS0tLS0rLS0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0rLf/AABEIAKMBNAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQUDBAYCBwj/xABCEAACAQICBgYHBQcCBwAAAAAAAQIDEQQhBRIxQVFhBiJxgZGhEzJSscHR8EJicoLhFCNDU5Ki8TNjBxU0c7LC4v/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/EACQRAQEAAgEEAgMAAwAAAAAAAAABAhEDBBIhMUFREzJCInGB/9oADAMBAAIRAxEAPwD7OSQAJBBIAEACQQAJAAEgACQQSAAAAA4Ppx01qYSq8Ph4wc46mvJ5tOWeqlvy1ct9yW6b4+O53Ud6D5loz/iHiIypxxMKcoOcVKSTjKEXKzk7OztwsfTBLtrl4suO6ySCCSuQAAAAAAgASQAAAAAAAAAUAAABNwBjAAAAAAAAAAEgACQAQCSCQABixWIhSi5zkoxW9/DiD29VqsYRlObSjGLlJvckrtn5/wBI4iWJr1a8v4lWU+y7vFdySR2HTLpVUxSeHpXp0G8/aqWe/guRx3q5HHPLb63R9Nlj5vtZ0KfVvvsfQ+iXSmE6cKGIepVglFTfqzS2Nvc7cT5rgsVm03ZGxGtqyur/AFvMzLT2dR035MdV9vi01dNNcUSfJMDp/EUmpRleO9I7PRPSqNSyn8mvgzrM5Xx+XpM8PPt1APFKpGaUotNPej2beUAAAAFAAEAgAAACgAAAAAEkADyQSAAAAAAAAAJAAEgAgEkABOSSbbskrt8j5p0v086smk2qaySOs6YY/wBFR1E85fS+uR8q0jNzZzzvw+j0XD/d/wCK+tiXJu2Qoq6vntPTo9xkSskubOVj7XHZp6oULyj4eJ1UtCN0o1LbeBS4ONs+Di/BneaJ0hTcJ0pLddX8zUjlz8uWM3HGVNHuN9sXn47zVp1p05W37rbzqcbZu6XJ9qWT79hyuMTk3bJ3bXxQ0kvfPLsui+nmt9/ajxXFc/8AB3dOaklJO6auj4Vo7EuM007Pau1bV3o+s9E8eqtK3fbhxXj7zeGXw+V1nT9v+UXwIB0fPSCAAAAAAFAAAAQAJBBIAAAeSCQBBJBIAAAAABIAIBJAAkgC4Hz7pvinKrKPsq3w+ZxzXkdF0jlerN3v17eDldeJzjlY4X2+7wTWEjxq7O1s15382Z5ztY0K1byl8Su0y0sMHi7SSe+LRaYPHtSjJS3W+aONeJtK/Bm3SxqSafEjp4s8utraTbur53KXHYpNu3G/jtK2rjW2uwxOrd5/Vwsknpswn1r8Je8+l9CarVRLil5o+dYCgpXvt1Uz6L0SjepTtwQx9vH1dlwsd0AQd3w0ggASAAIAAAAFAAAAAAuAAIAAAAAAAAAAAkgkgAwYvGU6KvUmo32LbKXKMVnJ9hW/82qT1tWmorW6rk7tqyzaWUXt3vcGpjauGa9fFQh60ox/E0veUFeNSpnOpJq+xOy8Fl5GOOAp+wl31Pghpucf3XNacjFV6yjKLjKSmrNNZu0krdz7ZM5HG4tU2k+aPqUsFTbtaN+Cmm/6Zoq9J9HcNVyqUoX++vRSvynHqnO8b34dRJqWPn0q6cE007cCvxUvWXK50OleglSDf7NUknm/R1sm+UZLKXmcdpCVahN06sJQmtqkvNcUTVjvjnL6qKks2eY1HfuNZV3K2wRnYjp+T7WkauSPVOTk0km3fJLNvsMGjMPUrzVKlFyk/BLjJ7lzPpugOj9LCxjNtSrP+I1d81Sh/wCwmNrOfUTGNHQugKsUqldxpXjZRec33L3F/Rozh/p+nyWVpejXln4o3odV3yjxc7yqS8P1MyjrfYqz/E9VeH6HWYSPBnzZZe1HP9q1spV+6vVNjCabxEP4lZau3X/fRfK7V+OwsZYSP8hLskr9mwwVKcY/Zq0uzrR70vkXtO+WeYsdHdLIt6uIUYL+ZTu4fmW2Hn3HSwkmk0001dNZprimfP8AE4VS60kmvbpZNfijv7DNobSNTCSUfXoy2RWx57YezP7ux8mNacs+KXzi7sGOhWjUipwalFrJoyB5gAAACCiQQCCQAUSCUAPAAAgAACSCQAAAGlpDHeiulnN2UFl62d2+SVm/1N1vjkuZzWApyxFX9rqZppqnGyShG+dub1Y3e+yOXLlcZ4dMMd+a2NHaMilr1LVa0vXqNZy+S4LcWCwUTLTMiZMLVyyac8D39prVMNbcu7Wj5xeRb6x5cb5o6TJJlVHJN5N25VEpRfZLb4nhwfqJar9iecJfhe76yLath075K/DczSnTVtV31L79sHuz4Gm5krpUlZrVcoL1qctsecH9dzOL/wCIlOg6NOFTVqSk26VR5TSTWsm97zXnfNXf0GcZPb/qR2P2o8yl0jQo1FKlVhGVGrF5SS6srZ24PLxiiZTcdcMtXb4pSwMlNKEfSNtqy1ne21rLPwL+h0XbcdeLvKClw1WpNSUs7pq17auxowUpVNHYxPVdaneUbRycoPLq8Jqyy37N523RzF0lTnGEr+lvKlV9ptepK/qzT48TOMdsuSxl0FoiNBONKCjezcs5N8LNq39jOgpUHv1+7JvtlLPwsU+i9G1LuXp3VWSca79WV3rXtFtbdjvyZYzl6KS1lBRurytLJb7al/Oxtxyu6sIRUMl6On/c/wDJ61b/AMSrJ/dWr7kjawqpSinF6y4pmwsNHmu9k2490Vfo471Wvxv/APR4cUtlSpH/ALicl5395bvDLn4sxToc5d9pIu17lLWp6vWa1eE6WcfzLh4mCtQvdNXus4rZJe1DmW1TC2zjZX2uOcX+KJpSp6uXqq97bdV+3B+zxX063Mk9HsfKhV9DN3pzas37TyjLvyi+eq+J2BwmPw6mtnWzyXtJdaK5SWZ1mhMZ6ahCbd5W1ZPjKOTffk+8y58s/pvggBxSCABIIAEkAATcCwAgAFEAAAAAJBBDYGnpuc44bEOn66oVNXt1HYptDzqwpxjJ3dl3N2v72+9llp2p1I0/bmk/wxTlL3W7zUop2Xd53b+BNbdcf1b2Hm75m4pFdSzXu7UbNKqpLnvJpLG2mSjW1XufiYZ4ipD1vV4pXGkk23pmniad03tWx8180Z6ddNXya4o8YioopS2q6WXN2JuwnhXVG7X2uDz5x4+Hmiu0jg9bXS5Tj3PrfXMtqiUZfdat3P5P3mnPLV/NB9mq2v8AxRt1lfOummhHTjUqrOKcJW7ctvO3mb2FwMYq6zpz9ZcWldyX3rWn3tb8rHpnHWoau+dTDR/ucn5GHQ83+z029sadKT/L1JrwVjPy6bum3Si4tXk7xStOO1Rex/ehyezwLaEtbqVEr2y4SXFGnCnZNLOVN5W3wedvrgjYpxWUL9SWdOXB7bJ+a70aYvlgo6NdOTcJSgr5ars1y4NG/SxNWDtPrL2o5eKPWHq/ZmusvNcUZnT4ErFyvy28PiVKzefP5m3rLbbwKWpeOaT+uJuYTEXSa2fWRnTNjblTUs0/Db3reaWLwm9bV9P/AAb8JLclclviiTLRLXM1FbK3Z3PJe9djRZdEpW9NTWxSjJfmTXujEaRwm2Ue8r+jeIaxrpp9WWHnJrnCdNR8pM3vbpfONdgAA84CAUSCABIIBB7UgeQAIZJDKIJIAEggAGY5yPbNWvKwFXpqpdw/DU84o9XtflZmrpWeSfsyT7tj8mzJRq5Rb2W1X8H9cRHafq3Ib0tu1X2fXzPV7vWjlLevgzWi/st5rY+R6ck3n1Zbmt/1wA2oYxLKfVfPZ4mzGonwaK5ynviprlkY+rvpzj2W+DCdsb08Ml1qfVfLY+4wzxTh61ObyzcEmu+N737EzVdS2ydePdKXvTPMsbLfJTX+5TnB/wBSVl4BqY3/AG3KuKp1aTlFppcN3dtXYVzxMZwundppvti833xz7mY406Mpa95Unsbi1KnLipNdW34kip0pXVDEU6UHrzqLJxs4ySeV2slnl3rcI6YYzeo8aVWvXwcL7JSqSX4MPqr+6Ri0faMpQez0tSD7Kn7yPk0ih0ppapSxNOrGDajCUZRlk1GUs/zKWRs4XHKpWai/XinH8UHdeT8jPy1lhZp1FGdtSb/BPxsn4+8zehzdN+q84Nbt+XY8zVozjLb6lRZ33StmvD3Gendr0UnaUfVfuaNObYj+8WrLKrHet/CS+R6pV2nqyyl5S5r5GBz1rJ9SpHY1v581yM8a0Ki1KqSfPY+DT3MJY2o1DyoKL1o5cVuZheEmvUmmtynn57SL1Vtpp84yXxsRJPqt+lV4mzGVypTqfy2vzR+ZnwdR3ltXK8WvIxnNTadranJoqtGQi9JuUfs4WSlZO0XKpDbxb1V4My6YxkaVOUpO2WXF9hm6HYScaU69VJTqtNJL1YRuor4nDjy3lpqzWO3QkAHqecABQAAAmxAA9WB5AEkMkhgQAAAAA8yNHFyN6RW47YRYqMTLaa+CqqN6cneNt/s7n3bH3HuuzUqxvsdnuf1uJt1x+lqpWtGb39WXuz3P3mSU2spR148rX70yijpBJ6jylvhJ5PnB71y9xt0MRujPV+7PNd36Mu3S4VZxnTfq1HB8G7eTPes/5679QwQrT304y7JfNESctvo6S/FK3uRWNPcqqv8A9R3R1G/ceJZ5p15f0xXnYwSxT2ekhHiqUXNr82xd6K+vpGgk3OSlZ2/etzd+UI9XvFsjeOFvqJxU1fWjKpf/AG5U5S7Mot+ZQ47SsaT61Wlh5uSaliMPODlbYnOm+t2tHrH9JXLqUk1zm/dCNo+Nysj0b/abzdSprPfd+4z3bdf0/a6aela8Zwcp1qE6kqrlfDzUoqLjne2zNZJ558irwVV0pKUJXjCV0ntjxWeer7t25Gzi+jtTDN6ri1zjZ+WVzFUpJRilra2rabdrOzy1Va62cXyyMZW2uszx7ft3OBxUJ000+pOzT3xl87+ZvU8RrWhPKS2PZfmj53o/SE8O7bYPbH4o6fAaRjUjt1o8N6+vE6SuPbt1HpVJatS3KX67me/Ry5SXP6zKzCV+ElNcHtLKnOK2Nx/qX6Fc7NMtPL212P8AUzRlLjU72kjH6Ve2+5J/AhzyvnbjN2XgGXqUb7/Nv+5/A18TpOOGTnNpLe3ZGPHaRhSWtJ9nF8ord2lDShUxdVVKiWpF9SH2Y8G+MiZLJ810WCpSxlWnOcVHDpKWrNLWm/sqz9WO/PM7KmkkklZJZWKHRVFqxewM44zH0455WvYANsAAAAAAAAAJIAkhi5FwAAAEAAGaWMpXRunmpG4HJ4iFmzVmX2kMJvRS1abRl0lV+Lw8aitJX4cV2MrZRrUfUnrx4T2l1OJq1qdyO2HJcVfLT9SKt6KKfG8mvBGriOkE5bNSKy+yn5s2cRhb7jRqaOvuJ5dJzSfzGriNNTkrSnOS4bvDYVtbFTlklqrzLpaKb3HtaIfAmi8+V8elFhINO59C6MSTikzm46Na3F/oSm4tGo8+Xlf6R0PCtGzRw+lejdSm3ZXXI+mYOV0Z6mFUtxqxiZafDMRgWtqZghSlB60W4tcD7NjOj1Kptiu4pq/QyDeTdjOnSckcPR03VXrwjPmuq/FFjT6TQVrxrp8tSXvOhfQhcT1HoNHe2PLX5IoV0ph7Ndvmqa+J5enK9V2p09XnJuT7tyOrw/QqktquXGE6P0qeyKRfKXknw4nR+gatSWvVbk+Z1+jtFKKWVkXVLCRjsRmjCw05ZZ2sFDDqJsJEgrAACgQSAIBIAgmwAHrVBGsAPAIAAAAAAAAAGGsioxtNcCASrFZVijXlFEgy3GJwXAmNKPBABWxTox4I2YUY8EAVmonQj7KPNKmk8kAEXeALKIBplJNiABKRKIAEkgAAAAAAAAACAAJAAAAASkAAP//Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUSEhMVFRUXFxUYGRgYFxgXGBoYGBoYFxgYGhgYHSgiGholGxgVITEiJSktLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICYtLS0vLTUtLS0vLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABAUCAwYHAf/EADoQAAIBAgMFBgUCBQQDAQAAAAABAgMRBCExBRJBUWEGInGBkaETscHR8DLhFEJSYpJTcoLxM6LiFv/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAoEQACAgEEAgICAQUAAAAAAAAAAQIRAwQSITETQSJhMlGxBTNCgaH/2gAMAwEAAhEDEQA/APcQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADTicTGCvJ+XF+BDaSthKzcLlRPajl+nL3f2Ikpy1bb8TknrIR65N44JPs6G59OchVzyfoSqOMnHWV+jKw10H2TLTyXRcghU9ox/mVvdEuEk1dO6OuGSM/wAWYyi49mQALlQAAAAAAAAAAAAAAAAAAAVu1Npqn3Y2c/l4lJzjBbpExi5OkWMpJauxXYrbNOLtHvS5LT18npyKF4mU33273yv65eX1JEaV30PPnr7/AAR1LTV+RsqbTnUbSnuLhu6+ba+Rsp1ZZ9+Tt1f0EcOr3N3wsuRzvNkk+WX2wXRh8af9UvVm7DbSadpu6fHivHpoR50+UnZeZArxuslk7O6/PMhajJB3Zbxxkjo9pY+NGm6ks0rWS4t6JHHrGTqS3qj7zztfJLgvAx2o2423n3c7Xy5XtzK3DtzSV3rzI1Ws30kWwYFHlnS4ed7ZG9tt6ZGrDQVl0N1+RglwXfZlDVq3nzPsqXIQdjZCZZRRm2zXJHyljHTaesW819V1FWo7tehDruVm5NWXAmMnB3Fk7dypnVQkmk1mnmjIpuzGIcqTTd912Xg819S5Pexz3xUv2efOO2TQABcqAAAAAAAAAAAAAAAVO3NqfCW7D/ySWX9q5soMJRlLOWbepp2rXbxNS/CVkuiSX54kvByjaz5rXpmjwtVleTJT6R6GKG2JJq2gnk8lyubqE7oSs1w+5i6i4XWSfDiZ1TLdo2q+9e+Vnlbjzv8Ampmkr7z10/EQlis/zM1/xKu3fy4Ky4EeRDYyZiM2uj97P6XImLrbqduHy4+xEq4zd/mvyvqU+09q7udrmOTKjWGNkzFTi1e9r/XL6nPYTGOMnHk2vQsFilKN073z1yPPI9pY/wARPWznOz4fqf0MVilltxXR0RVcM9ZwWObhnk7aakrZ0273ndu2mVrcuhyuxcaqi14p/sdBhoSWkX6EQnKykopWXUatsr3PlWqVkpTjrF+hX1dpapvNGks1dlFjvotcZjdyLd7vpkQdsbQ3qVl/MkrPrkVeKx5Br41vLiUWe3Xov46Om7FbVUFLfWVSbknxSVlG/wDxsd3GSaus0zzDCXSVrc87l/sTatSm92b3ocrac7M9bSa5R+Eujjz6dv5Ls7EGNOakk07pmR7B54AAAAAAAAAAKram1tzuws5ey+76FJzUFbJjFydItJSSzbsaf4unpvx9UchX2hOcrNt9X9tERq1Zx52XE5Ja1Lo6Fpn7N3aOCjXbVu8lJPxyfuiFTxmbjdP6IgY3EJ6yUbaX66WZUVNtwi3fKSyuuX2+55WaW6bddnbjg0qOww+M7qu/zgbJY9cTjsNtaDu4zvd3s7WVuXQyltZZ5s55Ta4NPGdJPE6+NyFiK/BvLMop7UzuuefoV+L2o75cjL5S6NIxLzE4xN82vz88CHiqu/Gzf4yhq4/dV28+PJdWzRhq1Wu1Gley1m9PLmXWCXb6L8I+9pNrqhCUKUu/UVklwve8rfIoOz3Y3GYicO5KjTbzqTVrLpFtOT5fM9O7P9mKcHvNb0+M5Zu/idFgX9jrw6lYo7YL/bMMqbd2Z7B2LSw0FGmr2WcpZzb534eCSReLMgQqK13krZ8PUkU1pFXWj/bwKKbMmrMZUbyd1ndW8Pz5mOMwNOorTinwz1XgzZiIPUxUZO13kV3Ppk/ZxHaLYlainOkpVIcUl349XbVdUvLiUWy5ynK705Hrm6rHM7V2PCM/iU0ld99cP9y5Pn6lMmJbG4o1hl5pmWy6OV9Cznh1bI1YKNo2WvUmU534EY1USsuyT2exjUnSk8nnHo+K8zozjKctypBrhJfM6yti6cP1TivFq/oe5oMl46l6PP1MKna9m8EaGPpPScfVG+Mk9Hc7k0+jnaaMgASQAAAQ9rYr4dNyWui8WctSouSblnq+b/7LjtFLOEeCTf0Kylikot/v0PH1s92Tb6R24I1GzVXopwyUle2SykvR/U0vDt3TWWWfPy9CdSqJ5/meZIqUYyjZ2aazT4r7HGo3ydG6uDksdgXJuz8cufVnFbe2Hq7u/jb6nrVWlHkUG1sJBq9tfF2/PqValF7kzWE/R4fiq9ehL9bt1JNHtNa2+m+q+x0PanZaabtzPP5YaXeW63bWyvbO2fQ9LB49RC5LkrkcodHUvtHD+70FDaVarlTp2Wl5fZEzsx2Nk4qpVybs1G2i69TvNn7GpU7KyV36vU5Ms8MHtgr/AILqUmrZyWz+zkpPexEnK2duHlFHfbI2dCCUVG2V9OHib1Q03IqT9vW2v3LTZ+H7uas/G99OJzNTm/kJSSRhRoKMHJJaN6WvqyHgJqyZc1o5WvZO6ZytCq0oxb3WpZ+CurdCJraUi9x0dKonkToaXKKElnJc87a309i4wlWVo5LO187WVnn629S+OmUkiRGDtm8/z2MacHbN+1vAkuS8TFzRdwRRSZpkne1vz6mUcPlwy4GdSoj5/EJL098iVtTFuiBXoOGiIeI2iovdS7xZY3ERfEo8bC8rq2j+eRWVei8fs2UJb9+9d+2Zs3bcr87fUi0N5WTd/FfXmSqcJ8bK3ncKXHBdqj7Go22mjOEpU3eMmvDJ/wDR8qxaXga6ib14cvUje0RSZ0OyNtqb3Jtb3B6X6NcGXZ51Wjo1qdl2fx7q0k5fqj3X9GerotU8nxl2cWowqPyXRZgA9A5Sj7S0naMl1T+a+pzeIg7cWrebelju8TQU4uL0f5c5DGYaUW4SyafqvseVrsLvejs0+Tiitw+Je5/yks+jtf2JlTHpJN5W9iNina26ru9reLz9rmiFC8u89FpqtfVnmu48HYqfJKqY26yz9yq2lWqNZQl6dP8Aot6kVlbwRujQVrGbV+yU69Hm+1KFaWXwpvLXdZzOydm1linvUqkYtWu4SS1T1a6HuH8KuRrqYRPS1vA0hllji4pdlm1IptnNJW0UVm+lizjRjCN0t7NcuLzfu2ZTwsVZW9jXjMPO2V7fLwM4ukQ1bJDnZNrO2aWnl0PlDE6N5dOXNFFVxHw8per4+fMi08c/5pX10yVvAh5ifGdHi9ocOBRRs5yet2n4cX7/ACIk8dG75s00dpQjUV3q0vPh7/Mo5uTJUKOrwjd7cPz9vUsI4lRXgV+Ca4cczfVitDePCMn2SaVZ2yM/icXwvmRac7GFSsVchRMlNSVnmsn6Zr3M6fIr6dUmU6qQRLIGPrrNPhr8zVRqJ5fnsS8RQi7u2upCwlNt2WTv+3yDtEqmT6VPPobpYfKyuiVRhFNLi/zU3fAV72z5/nmaqDM3MrMRSbjk88tSPGlK1m/H9ixWFtK/R5LTW+nMwqQzKtFkyDNcC07LVbVHHhKL9V+1ytq6k3stG9eX9sfLPL7nRov7iMs/4M64AHvnmgh7SwKqx5SV7P6PoTCHtiq40Kkl/S/fIpNLa7Jjd8HF4RKVR+PllxJdHBqEpz13rP2tbov3NGAnuxXUlYist1nzb/Z6v0QZS75OwmZAlC1ifhJFILktInuC5HxUTbGxmrI32WY7iJWoXzRjCKtZkqrUVuhFms8uNiriky6k2ij25s6M4tNXT/E/U802hj3SnKnLhpfiuDPZMVFbuZwv/wCdhXx6qSV404acHJvu35pd72KKMVKpdG0ZcFBsvZOLrd5R3YPRzunbnbV+difieyzS705SfSyXoehqlbgR8RhN4rOUv8eCVM5fZ20ZQShPVZJvj+5ZUsdLe0y8cvz7DE7BTTvn6lVW2ViYZUpby5Sfya/cyjKV8lqiy/8AjX9uh9+IuP5+fU5+NXExXfpekk/mkQsXtucNaNT/ANfuWUrdV/1FfGdgsQjP46T8fQ82xXbOmp7s6NXeSutLfMl4ftROX6KXhvNZel7nR4pLmSoptvo7fEYvuvNXX5YkbLeV3xz9Tk9nzqVWpVH5L9K8EdHgptGDyXL6LONKjpISyys/E3xn4FVCpkfY4h6G/low2WTqkuJCrz9xKtkQcRWaalfXL89GL3EpCUXw1yvfj6HQ9mKH66nNqPpr9CloU3JpLV/NnYYLDqnCMFwXq+L9T0dFi53HNqJ8UbwAeocYNWKoqcJQf8ya9TaA1YPPsRSlBuLumnY1qo2ddtvZXxFvwXfWq/qX3ONtabTurPPg0+TTPn9Tpnjl9Hp4cqkvsmxhvWZvirZoxhHLLoa6tRp2MGmi6dkujiWZTrsg4a/EkSdiE3QaVmxV+Ziq/FPS5EqS4mp1SNzstSNW1sa+F8k72HZeDcHUes235LKK8OPmU23MTNqUKUJzlZ92EXKT8EkWvZitvYag4/6cM1/tRWMXe9l5NKNF9iG0sld26GGEoyvJy48DdSqqWS5aklcM/E12W7Md1KjGFJcTKWHjyM079DaomigjPdRXVMIrO1mQMVsmMtUX0EuBjVjwKSwpl45Ged7b7NUqkWnHTR8U+hzWD2c6cnTlqn69T1LaMIrxOX2/QScKi1vu+t39GYyUoxcU+DojOxsyklZci7hDPIqcLUsr5FrQqpq6eZEUVkybu5HxoxlUyG+tDZYzOz7OfJX8DTVpOTUUr3eSWpYYLZ06mcVZf1PTy5nQYDZ0KSyzlxk9fLkuh34NI5Lno58mZR6NOx9mfCW9LOb9lyRZgHqwgoqkcUpOTtgAFiAAAAV+09j0q2claXCccpfuvEsARKKkqZKbXKOKq7CxVGTcLVqb4JqM14KTSf8AkQsbQqauE4+MZL3sehA5J6LHLo3jqJLs84wUqu9ZRlL/AGxb+Razw1VrOnP/ABZ2QM1/T4pdlnqW30cO8JVbypVH/wAXb3yJmF7OVJ2dV7keSs5fZe51gLx0ONO3yVepk+iJgNnUqKtTgo83q34t5s4rC4V0alai792rUlHrTqP4kLdEpbnjBnoBXbV2VGraSe7NKyfNf0vp8jTUYFPHtj6K4sm2VsoITtxPixHez0Wj8TDGYSpS/VF256x9Vp5mMJq3A8WcJRdPg7k0+UT3O6unb04eJujXdkmyvpzYcyE2KRYxqvhbqfalYrVVFSq7cBuZG1EXHTu72/OZM7M7PUpuc0pJK1mrq7y0fRyMaGBnWfd04yei+76HVYLCxpxUY+b4t8Wzs0Wnbl5H0ZZ8qUdqKzE9mMNLNQ3H/Y7L/HT2Iq7KKP6arS6xX0aOkB6MtNik7cTlWWa9nPLs7L/VX+P/ANE7CbFpwzfffXTyX3LMEx0+OPKQeWb7Z8SPoBsZgAAAAAAAAAAAAAAAAAAAAAAAHxopNp7AUu9Rapy4xt3JeS/S+q9C8BSeOM1UkWjJx6OMqYKvG6lTb6rvL1WhHkmuDXjc7s+SinqrnHPQRfTN1qX7Rw8L8yRh6DnLdirv8zfJHVSwVN6wj6I2U6UY5RSXgrFY6CnyyXqf0jDCYdQgorh8+LNwB6CSSpHK3YABIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//Z",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFYMmuFqFz7eL6nLfvKWG-NEoR7h0QthkZ-Q&usqp=CAU",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhMVFhUXGB0YGBgYFRcaGBcXGBoXFxcXGBcaHSggGx4lGxcXIjEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0lICYvLS8tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALQBGAMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAwUCBAYBB//EADwQAAIBAgIHBgQEBQMFAAAAAAABAgMRBCEFEjFBUWFxIoGRobHwBhMywUJS0eEzYoKS8RYjQxQVcqLS/8QAGwEAAgMBAQEAAAAAAAAAAAAAAAMCBAUBBgf/xAA2EQABAwEEBwgCAgEFAQAAAAABAAIDEQQhMUEFElFhcYHwEyIykaGxwdEU4UJS8SMzksLSBv/aAAwDAQACEQMRAD8A+4gAEIAAQgABCAAEIAAQgABCAAEIAAQgBrYrGQpq85Jct77jjnBoqTQLoBJoFsg5/EfESX0Qvzbt5L9SuxGnar2St0938zNl0vZY868B90VtlgmdlTiuwMHVjxXijgK2KnJ5ybe3Nt/cqsPpStUqPXo/Lpp2vazytZvNrjl5iG6XL2lzI8MKmlfTrauyWWOMhr3+laeq+qfNjs1lfqiQ+bU6980bOG0lVh9M2uW1eDK8f/0DdakkZHA1+lYOizSrH15fVV9ABzOB+Jd1VJ/zR+6/Q6ChWjNa0XdGzZ7XFaBWM8sxy6CoTQSRGjx9deqmABZSUAAIQAAhAACEAAIQAAhAACEAAIQAAhAACEAAIQAAhDCc0lduyE5JK7ySOU0xpd1HaP0Lz5sp222x2Vms/kNqfZ7O6Z1BhmVvaQ05tVPL+Z/ZHP1a7bvd33ve+pFe4Z4u2aRmtDquNBsW9DZ2RCjQjPGw2RuRQCsAL2rS1trt0yfiQRwKatOdSa5y3dyROzyLHiaQCmsVB0DHGpAXtGlGEVGKslzf3MZPl5CUjBviQLnOvKa1tF6upt4DSE6Urxl13p9UaVz1SHQyujdrNNCEPYHCjrwu+0bpOFVZZSW2O/quK5lgfN8JiXTkpRdmn77nwO80bjo1qamtu9cHwPZaPt4tDaO8XvvXnrZY+xNW+H23LcABpqigABCAAEIAAQgABCAAEIAAQgABCAAEIDGTtmzBVovZJeKBClB4iDF11ThKb3K/XgvEHHVFXXIAqaBUfxLpD/ii+cvVI5tszxVVyk29rbbIrnz632l1pmLzhluC9RZoBFGG+fFZXDZhKRnTV7e78imG1TsBVeM9dN70/wBuJJqLf4LYu/yCw+zd78Nw0RHZ11wO5R1go5R3b/fPaYZWfhbebE6e1OXX1TsR614tpK1veXLMn2dLj111gugrXlyMWzKurWXLP7kNyFE5t4WabFyNs8YUXVKpltoDSDpVM32ZZS4dU+T9WUbkSUam/wBvmXLLM6J4IySJ4g9pacCvqaPSs+H8V8yjF712X3bPKxZnuY3h7Q4YG9eUewscWnJAATUUAAIQAAhAACEAAIQAgr4iMFeTsvXklvOOcGirjQBdAJNApzWxGLhD6pJctrfRLM0KuLnPZ2IcfxNekfMpsRpGEW/lq73yd/8ALMm16UbGO7nma+gxPoN6tw2Rzzf6fJw8qq8npCb+iGXGeXkiGVWq9tRLiopZd+05ivpGpK95eGXoQfMeq7Pbt6L9zEfpd7jfrEcdX0aPQk76rQbo8AZDlX3+leV8ZQv2pyn5+bYhjMP+V9NUoEYooG11JcWN5ivqrgsraU1j5rqcP8qf8JuL6tNEWksXV+W4S7SbXatZ2WdmkUmDr/Lkp7Wt27hmdBRqqtTbtya5l2G0OkjLYjquoe6B3XDhhftx3qnLF2bw43i684jniuYcszG55pLsVGiGNQytWoqtdraiqnT/AFJ4W2vJW87XuuGxGprEqkk7bm9rz2bLefidbcovathvs5rhfPd79SSFTN/Rbdd53Rr6y3peN7PZdfueqdnfVit1r5tbmWGUF9er929K1arKctyd1fbtbey23MwbukknrNO/Gzeb9TyV1slBb8uPjYhnUV5Xd8rZdEs3wyQZqQbsWOJqZu3HhuV0a+sZVGslw5878ciFi8VZa2gUmsNbmRJ94UwohwWWuFL3795EbZ4pEqKBC7L4MxXalTf4lrLqv2fkdgfNvhuvq1qb/mS8bL7n0k9hoqTXgocj+15rSLNWau0fpAAaSoIAAQgABCAAEIAVWkMc0/l0/re17or9RM87IGa78PUnIAZkqbGF5oOt6kxmPUXqRWtPhujzkU+Lxqg7y7dTyj04LkamLx6p9mm7y/FLa78uPUp5zu/ueTtuk5HmmezEN/8ATtpwGAzW1ZbEAKnD1P0N2ea3a+k6k7pvsvduNJnkkZGQ97nmriSd60msawUaKLBIyt5GUIeZ7qe97OLpcsD1oyaSMJS5HFwL1vh5lzoao1Sm927rbP7FIl1b4F9pOsqVJRslZf58yxCSxrpBcQKDi64KvabwIwMT7LktO17zfE1sJiLmviat5N8zTwlS0muDHMhHZ02LWYyjdVdDGW8mpVLZat1wyz8jRo1Pe4l1yuRQpbmZLdUo3y812umX2DbeUsuq8r8TV+bkluPHJvJ3t192OpXZqStO2Tetu2kc5vctXZxTXjnzMJVeFl4eeWZFOXj75HQEwNWcp7Xf31M8NScpWX+Lms55rO50+g8BaKk3myRa43NF5wUZ5BEypU1HQ8HC00slt4d5S6Q0ROGcO3DltRe6Rx0GtSLzvnwdr5eJqU6jjdxduXHuJvdDE7UF+etX4wu81nRPm8ROOR6uXLa56josXo+nXzjaFTykc/OjKEtWStJf4JalwIwPXnuVtsofdgditdBy/wByDvskvDWPqB8u0FFupTXGUV3Nrb4PxPqJ6TQ9ezdxCw9KeNqAA2FloAAQgABCAFfpPHKlHjJ/Svu+SFyysiYZHmgF5Kk1pcQ1uKj0njnHsQ+t/wDquPUosVioU4ygneT2y5vbnvZ7jK3yovO9Spm3vXFlG1c8fbrdJI+puNLh/UH/ALEXk5YBblksrdW/D3P0MhzSSQt7uYpGaXBGRgFpleqLZbYPQt0td2fC+7cV2GglJN58ti6s6DD46nnna3vI0bDHA4ntCN1TzVG1SSNFGeyrcZgFBXutZ7uCNF82b+lMXGcrpd5WyKlqLO1PZ+EYb9/PyTIQ4t7+KwkyNskl0FKMpNRWbeSQkAnBWgblYaFwd382X0x2c3+iKn4k0g5O1y703jVSpqmneyV+bOFxNbWdy+5g1wwYNrXe7PywHPmqyNMjjM7lwULZXuras+70LBFTiv4vgWohUngtMLocLVubkSnwlXmWdGfvh3lSVlChwU79sX6EeubVHCt/VkvMQbsUtxAxUGpKX0pvK7/yatSpysdjo1wcflqNui29eLOb+IcB8tuUfpbz5c8/eY1tLjkcOOwqvDaA55YRTYotFUdeos27Z+/e46vSNX5dOy2yyvw4lF8JQveXvI3tL1bzstiX7/deAOOqXOzwHylWjvzhuQWilc2KVW7t7ZqxJKWTzzKpANya4VW6m/e8mxFKNWOrPJrZLeuvI06dS2T2G5q3V0WrI+pLHct/XW+pI2hB9VL8M6ParxUl9CcuT3Ra8V4HcHD6M0o6cr7tj6cPHwOyw9eM4qUXdM9boySMxUbjisa3tf2gLtimABpKggABCAAEIcy66qVJ1HmllFcI7n37e8u9I1dWlOX8rt1eS82UlKoqdFyt+7ZjaUfrPZGfCKuPIUHyb9gzV2ytOqXDE0A+VzuMxDnJvNt+7EWrxJqtVt3yXRWIms801y3njr3GvqvRNuFKUXkY32LvJUkuZ5r8Ml72nikSJAw80XlSKR5F27zFsx1xVFylV7rZ2PXIim8zZwmDlUygu95JdWMawuNG4ldcQ0VcoYZvft6+RcNRw0NZ2+Y1/at6Ipzp4ZXupVOPDocppLScqkm2y1ENQnU8W3+vDInflxwW2M2g7Ge/691jpPGupJu5XMkkeNDWNDRQLTa0AUCibNSvS3+/dvQ3FBtpRV23ZLi3kl4nQaf+EqlFxVOMqikkk4rNNWylw67Ohchic4FzRcPlItE7Iy1pN5r6dc1y1CVi3wFKc/pWXF7C80f8GxSvWk3K67Mdi/lb338vMlxcYwk4p7MrW2civamuYwOpilC2NedVl59Fr0cLGOe18X9luM3IwlU5nl+ZlmpvKKE3lSwqtNNZWLLSFJVaV7XyzXqin1eaLjRT7Eo3XJX8RsV9W7fcXhInGqA8YhafwtS1E4702iLSLXzJdpPMlVT5c5c033lV8zdtt9xmuHxjiSmsYXSOk20U2rw9SRJo10zODysJITiFPGRa4B9luSdtiezr9ij97S20C+005JJrJb2+SLNhaDO0HP3oadXKraxSMlK+Es+y7p9zRvaD0i6UrS+h8crEsaOvdpx6rMixmFWxXfjl3XN2OzGJ/aRGgxpks10rZG9m9dfCSaTWaeZmcroHGVKT+XVT+X+GXDu4beh1KZtwTCVmtShzByPXmsqaIxupjsK9AA5KQAAhV+moXoztuV+5NN+SKqLVSk1yOjkr5M5fEUvkT1XdwecXy4PmjD0rG9r2zgVbQtduGIPCpNTkr1kdUamdaj59vdUM20990/AiSv8AqdBVoUZ52z5O3iQYjRN/4ezhvv1PMfjnwscHEZD6Ww21MzuVQ3uW25i2by0PVvnFf3IzhoSX4pxj33Zz8eXNpHG73ondtEP5D39lXN5mdChKbtFNvkW8aeHpxafbe+/2Rq4rTyirU4qK5ZHezjF5dXc2/wBTQe6iJXyXRsPE3BZ0tFpK9aSivy7337jXx+mowWpSVktlv1KbGaRlN5t+JW1JDAKigFBsBvPE4kbhQbk9lk1jrSmu7JSYzGSm82ajZ5IxbHtaAKBaIaKLOLPWbGj8BKo77Ib5fZcSzw+jYxk2+1wv9+YuSVrTTNLfK1hpmovhmjavCrOLcIPWX8zX0JX52d+R1FTTNTWc5W6JZW5FZGViKvPaK/OnoGtNADW752+25ZssbZn6zhlTktpaeqSU07JtZNLNciuqVnPOW3jx6mTWV+Bg/feElokkA1iSpsiYw1aKLC542JrwPUhSsAry9zd0fV1Zx6mimbGHnZpg4kXhReKiisNOUMr7yhg7HV6SWtTvyv5HIpZtcGPewNeWjDFLsL9aOhyWxGRkpcCGKJLiiFZIWbM4ZO+/P9EYwPYIjVQK38JinFNp7beWz7ktXGTavf7ehpPpw8HmvU26ULxb4enH3xO9rKO60ngCRvKpvYzxEKOGKm975cjo/h/TCaVOo1f8L3c0zm50rK6MYze1PZn4GlY7a+Eh1Tw2jq/qhTPZmStI6BX0sFDoHS+v/ty2rY9zXAvj10UzZW6zDcvOyRujdquQADVBDVx+DjVg4S7nvT4o2gcIBFCugkGoXzvSFCrQnqy/pe5ogjpWS/yfQ8Tho1IuM0mn7uuD5nF6Z+HZ0m5QvOG2++PVff0PN27Qza68Y/S27LbmSd2UCvoVoS01Nrb5mrX0pN7zWnTI5xMJ0DQauFfVazGMGAXtTEt7Wa7uZNHiiTFBgnArAxcSVmLJAqYKglDxZdaH0bTUr1lrP8t+yuvH0IsHQUVrv6ns5Lj1PXUadyD5HG5pooyPLwWtNFeaUhazilq22JZIr9Y3NH45SWrLNczPFaNstaGa4b+4UW9oSQL8x8jcqDHCPuP81XuZhOR6s9hHJ52FgK1RZqTsY2uunoY3M4S8CSMFhcwSM3GxijoUgvVZ8SWlSd0rbdhHJbkXfw/Tyk33dScUfaODK4pUsnZs1lsY1qMNXhE5JK7bXFo6XSkZzepTjrTadlfa0m7Z9DmdAzvk9+0a5pJc/KtBy+qhLsrtRhOefNbCsup4mZVKbTs9p7BCCrmVUjuJYMjRnTVyJUSpXfx9r1JaVS3p9mQz3WPYvMgUkioW1Sl/g8q0lnwIXI2aMXN2W39BkLy3u0qlOFL1HhajhJNPfkdxovG/Mjnt9UcVLBzu7Qle/D7lrh4unCP5o59+09Bo60PhLgR3efXVFn26JkgBBvXXgiw9TWhGXFJ+KuD0wNVhlSgAEIAAQqjSOgaNW7cdWX5o5eK2M5zF/CFWN/lyjNf2y88vM7oFWWxwymrhftF3XOqsxWyaK4G7Yb/36r5ZitDV4fVRn1Ubrvcborqitk8uv7n2QwlBPak+qM+TQrD4XkcQD9K+zS7h4mjkSPtfGbrc7vgv0NyhobEVPoo1HzcWl4ysj61GCWxJGZyPQjB4nk8AB9rrtMup3WDma/S+aaRwNWnq/Nhqtq6zTXNXXAq6iPquNwUKsXCauvNPinuZwWmtCTovNXg9kl6cnyKdu0Z2fejvHt1tVmxW8S919zvfh9KljJplvo3StsmVFRW7zBmK5l+8LSe1rxQrsYxpVE9ik1a629SixWj5076yuuK2fsaWHx0oF7g9Np5S8GT7QEUkF/8AYD3CqiOSE9y8bFT2EXl797zoVQoVM7avTLy2Eb0NTbym1utkAs5N7SCOOzipfls/kCOX0qWpnFctvTcRo6ahgacItZyvk78DCOj6Ec7X6yZ0WY4awrj1QKItjBdQqswGD+Y+CW1/pzLepONKNluIauOjFWjZLYrbCy0PoVyaqVlltjB+Tmvt48B1lhfK/s7OKnNxwA6wzPtWtEwA15LhkMyp/h7AtXrTVpSXZT2qO2/Jv0RRfFehfl1P+opx7Mvrsvpn+a3B+vU7wwlFNWaunuZ6h2j4jZvxxhtzrt55rKZbHtm7XzGVNnWd64KnThUSvttkzQr4Ocdqfhl3HU4z4dcXrUXle+pJ7OUX9n4ldKrOn/EjKP8A5LLuex9x5G0WOezGkrTT+wvHPoFbMFqDv9s13G4+X+VRum1a6a6nkUdC8XCStJJ9cxTjQ/KV/wDSd4XjnUJwtJA7zCqN/T32MYnROpT1baq6WIY1acXdRgiJEbf5jkCVxtpJr3Sq7D4ScndR8dhaU6aoxd9vHiQYnTCSsrLL3kU2IxU6r1Ypt8Em34IYA03RVJOdLr9gxr1fgolkknjuHWasf++PWa2o3sG6mIerDJb5bl+r5Gtof4UqSalW7EeF+2+7ZHvz5HaYbDwpxUIRUYrcveZ6GxaNmc0ds5wbsrefkBZ9qtMMZpEATtyHwSpKNPViorYkku7I8JQeiWOgABCAAEIAAQgABCAAEIR1aSkmpJNPamrp9xIAQuR0v8Jp3lQf9DeX9Mt3f4nI4rCTpvVnGSa4rP8AfqfXDWxeDp1Vq1IKS5rZ0e4y7VouOW9ndPotOz6Tkjuf3h69dVXyNxMLn0DEfBlFtuEpx5ZSXmrvvZW1fgepurQa5xa8k2ZD9E2luAB4EfNFqM0nZ3Z04g/FQuWhiZLYyaOk5redBT+Bav4q0F0UperRvYb4Gpp/7lWcuUUoL7sW3Q87ze0DiR8VK6/SNlH8q8Afpco9LTLLAaOxVdK0dSH5p5K3K+by4I7LAaAw9FpwpLWX4pXk+qcr27i2NCz6CjaayHkPv/CoTaVGETeZ+vvyVPovQNOjaWc6n55bf6Vsj68y4ANyONkbdVgoNgWS+Rz3azjUoACagh4z0BVC1J6PpS204Pnqq/ia09B4d/8AH4SmvRloBL7PE/xMB4gFMbNI3Bx81Uf6fw/5Jf3z/U9/09h/yN9alT/6LYERY7OMI2/8R9KRtMxxe7zP2q2Gg8Mv+Gn3xv6m9SpRirRikuCSS8iQDmtDfCKJbnOd4jVAASUUAAIQAAhAACEAAIQAAhAACEAAIQAAhAACEAAIQAAhAACEAAIQAAhAACEAAIQAAhAACEAAIX//2Q==",
        };
        return urls;
    }
    public static String[] getFruitsandvegetablesnames(){
        String[] names = new String[]{
                "Pomegranate",
                "Apple",
                "Onion",
                "Potato",
                "Califlower",
                "Orange",



        };
        return names;
    }
    public static String[] getFruitsandvegetablesdescriptions(){
        String[] desc = new String[]{
                "fruit",
                "fruit",
                "Vegetable",
                "Vegetable",
                "Vegetable",
                "Fruit",



        };
        return desc;
    }

    public static String[] getFruitsandvegetablesprice(){
        String[] price = new String[]{
                "100",
                "100",
                "20",
                "25",
                "30",
                "50",


        };
        return price;
    }
    public static String[] getMeatUrls() {
        String[] urls = new String[]{
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRgWFRUZGBgaGBgYHBocGBoaHB0eGBoZGhwcHBocIS4lHB4tHxgaJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHhISHjErJSs0NDQ0NDQxNDQ0NDE0NDQ0NDQ0NDQ0NDE0NDQxNDExNDQ0NDQ0MTQ0NDQ0NDQ0NDQ0NP/AABEIAL0BCgMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQMEBQYCB//EADcQAAEDAgQDBgUDBAIDAAAAAAEAAhEDIQQSMUEFUWEGInGBkaEyscHR8BNC4RQjYvFSgnKSov/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACYRAAMBAAICAgIABwAAAAAAAAABAhEDIRIxQVEEYRMUIjJxgaH/2gAMAwEAAhEDEQA/APZUFBSIAEhMapSmi6UAOoQgpACRCEAASoSFACEoRCQ9EDFQuZO66QAIRCIQAiZOKbOq6qNDgQVV1mFpIJETzus6pr0accqvZbseDoZSqtoYgNF7HwKnUqzXaFOa0VQ1/gdQhISrIAlKE2NU4gAQhAQAqEIQIEqRKmAIXMnZGbmgDtCEIARBKE0XIAHGV0xqGsXaABCEFIBEIQgYIQhACOSABK8iLqL/AFbYuCfJS6S9gk36JO6GhRBjG8inW4pvh5I85+x+LXwSEJGuBuEqYioxWOIc5rRMeyjUXkkucbqDisQW1HFpuT80mHc4S4zHLnO4XO61noRxpSXEAiFHylplpg9E7SqA3SVY1CrpkbjwnYTGZrOs75+CkFUjQ4EHnB+yusO6Wg2Wsv7ObklJ6jtrV0lRCozEQghCAFQkCVAAkclSOCYgASSkn1XQCABgsu0iEAC5axdIQAIQhAAkQm61ZrRLjCljS0cXFWs0amFX4ziPcJpkF20rBVu17hVFOoILnhvhJjcrO+VT0jp4fxb5da+D0Ctj9mjzKjnFuP7lTUuIua05gDeQ42lpAPrMjyT9PGMeMzfdZVTfemq4EvgmV8UdM0nWJ25woPEMM+oyGPynUjYwZF4kXjRUrXvdWa+Tmbma4QRLTMQDtPLog8QqNecxIbYC9mjr1XC+ea6rfeGXlOZg1iOKV6Rc2qYcT8Qgiwbp6fO3Lip2re0PLRmE5A7k4iGmdLEf72TitcFpkg/xcLPU67AMuRphwJkCel46FZ1s1020TyxUpOX0a/s12tzktectRpa1wOjy6btH25rc0sU1zC+YABJ6QLryHAMwzXvrCS5oJLMwIuWm03MQTcxdTcbxmpUaymzPTY97WPcDqHGIJGgJJ8YXZx8+L7IzynX7Lo1MxPKbeHNOOxTsuXaflom6caAWFh5W18k7ToufZola4dypZ2SMNxTLZwHjqrvD41rgJaL9FS4bhwaZf3j/AMdh481YCqBrbwTnUY34v0WNRzSIylyaoUqjTbQ63/LpiniSU9+qY1Wm/Zl4vMJ7KvNPqs/UkaIbXc3/ACb7hNVhLjfRZoSMdIlKtTIIQhCABCEIAAEqQJUxAhCEACEIQAJClSJAMYuplY5w1AMeOyx3GOOuyw1ocREjNBnzW2cRF9Oq877SBjKjsghus63i8dFlyadX42eXaILeM1C5gLQGukHY6HeTddsZRD+8zMXSS5wBsNm5h+QqbAYv+4AQdZEix3Gqv8RV/qO40X57NG5KyPQdpPEsJrsK2tSewPkOlwzCC20ANg8xM8yVT4Z9Sg0NqHvxvMG5gxziPRTOI8Ocxgax5MCJO/WQqvCOe0OFX4wYkmbbXWHLLpYnn7M6TcNJ/P8AseZji15qkuE6t5O5jkDBUCqXPc45rPgmJM66E6RJCsXU8xbD25iC8Ne2WODTGX/KYOmkSqzi+LdlbIGcy2GHMAJ1baZ2XC4SpLdOKeNVyKd0aq0HusAQ0aE6ep+qhPw1wbOvcE7xqeYPzCt8LhKz2gPMkiYAiP8AyndMcR4U9roIDv3NA1FtyLOH54dVRkrEdfM34qJKfEVXh5ayA2o1oy90NLdDp/2ncWVjwXG0aAZnJDnHK25IiQ0wCdJ3hMjB1nZcjAACTFvQEka/kqFj+HVKUPcyzSHTJMQQcpMWv0tzVQm81HL3Otrv/h6ZhXtygFoNh9Zup9CoB0VVhKzHMY9h7rmhw8CJupLKl/ouopst2PG5iUywgk6HxGqjMru5WUhrXGJA05x5p4IdaZ0HkunOI2KHVYAG/MJwVDEKhaIx8mxsnhdNEnTLdOUREWSwe9D/APWBje8LdNvVS8NiGvEtMhV2Mw+dhbpP0v8ARVWFqZbMcS0nUcxY+afm5EuJUtXs1aFTUsS5p18lb03ggEbq5pUY3Dn2dIQhWQASoCECBCEJgCEIKABNYh+VrnDYE+icVXxLGDKWtEuMRyN1NPEVMtsqqz6z5zPytNwAPpZMDh1M/G4uPUwPZWjw0gTqqjE4J4kscH/4k5T5GCD6DxXNTZ3xnr0A4Zh5kMaSLybkc4JRUpZLsbqo73vaQA03t4T7R4K7oYRrmwHEui+kT6JLsdPx7KZmLBMEX0IKzHafHAOLGQJADpB5bbXnXotDxbg1QOzNeAdYLTf0WQZwwVKrQ8nOXQQAZIF7jTSbrn5W9UmfM1i8fkk4apUyNc57XtjvUzIy7BzXRZ0AWtqQrLhvDQDndEnQ8hyHqrR/B2uZlawNtAA2XVHg9eNWf+x+yU8PjXkx8fHM972OMc1gOXfoFWOe41ASCLWVmeFVBdwtGxn3Crw+DkcYLT9fsuhFyl3haCmCwjKJidN1ArMLmFpiw0PTeVNwFcTO1k9jMLHebodR481ekucZksBigwikbCTl5Xvl+avqb5sNfz1VHxjh0i1iLjxC54VxLN3H2ePRw5hKX3jHc6tRpP1HCx91IDxoXRZVlKoN/wA/hPsdY281oZFlTqCNbqYwE3nbYBVtGoCLD1Uukde8Z6IETKZnX+U+XddFDo6/ynC4wZCCWTQ7RZbGYhtCs5nwtd3xsIM/WVfU63+lS9rMBmNKsDdhLXf+L9J8CP8A6SrtGvDivH6ZKZUWh4eZYPErG4DEEEtcZgnXxK1nCD3Lcz5KeJ9i/KnEWCQpUFdJxCBKkSoAEIQmAJjFVsreqfJVfUrBx0mFNPCpWsrq7nkyA4yI6KM8ybtHnYq2NdujjHJMVMVTJ0Dlizpmn9FQ/FlkwM3IRKeZiQfiZru0fgU3FhrmgNAG+3sq/wDSI0dA370D2UM2WUvRGxtVrCCHAtmNYI8RsuqGKA0N/FRsZw+k+f7jZPO566aqvxPCKlJgex5eORadP9KTXxnx9mnOLL25S2Z0PLz5KCeHMZ32gZzq7eOnJO0HZQDPIfnouhVlNmCWHWGEGSVPpPsoDXp1pidkmNlzTgtHNQsRg2v+IAnnFwuqD5Ea/nzXRfG6bfRktVdGdrYA0nTqw78tdVMo47MIcJTHabEEUXFpiL+MbKs4fUMC+ySrvDpcup1k7iFBpEhYLtBhi052nK5tw4Whafi3aCjSaZcHuH7W3M8iRZvmvLO0vF313d45W7MBtHXmVSnyZCpytNVwLtMKkMecr9P8XdQdj0WtpVrC68z4ZwN9RrSNxb82WowLMVTADm52t52d67qkwqUbOhUG4lTGEgch7rPYXiLdHS1xiGuEfwTKtxOUGQearTJpr2W9F7QRckqYHEjlfxVLRrX1GkqXTxNvikzv9kmSPVGieqR72uBpv+Fwj+fFOOZm3B0TZpSQYvdIucZV0+G1M7g1uYA/FIAvcGFq8DRyNDeSgYWtlMajwVrSeCJCqEjPmqn0xwJUiVbHMIkcfVI98LkD1QA43RKgBCYHFQGDCqw2FbFQsZSIlzQTzAUUvkuXnRWYokiI8FXOLRZuo1O6sW4skwZtsVCx2Fjvs+E6jkefgsTon6IX9TludWqo4hxNz4ElsEmPHlCtywQqyrhyXaT1+6hp/B1cPJMvWhzBYq1zm/Oa0FLFh1OHCx0MdVnW8abTOSJ8NvFTcNxFjwSDJGoOyEPlfl8FdRx93Mcbt57jopmGq5rE9AmcVWYT8I9FExEBmZogzqLJE5paiqWa+oVhh8SDvqOizOH4qGkCoRB0dt58lYPeWDMD3TEb+Higly08ZoKNSFR4njQc/Lmi8KHU4i55DZyjS03XGMqUabM7wACYBuHSdI6ozSplJ9rdO8bVc4HOe6Dt9ZWW4thn1HgMe8MAAgExPPqplTtHYsFDMxwIEvDDI2tqfumqHaENhuWHWhudtRpF9HQ0g6WumsN1xWlqRBo9mTHxkTzH2UPE9g6hOZjw68kO3vsdlusBxBj7vYBHImb6QFNe9ryGMIaL5os4jSJWktL0cvIq3KRC7NYMGm2GkajbUGCtTRwAtYLjA4EMEAAAaBWjBCEY3WsrMTwdrwZDfqFGqcGebA5RvlP00C0WVI5liPkmR5MydehVaTAaWjW0E+aZp48tMPaWcifh9dvNatzBoeXJQq/D2um32QWq+yHhsTIBmb7FSc7TtJ8bLLcZovw9VrmPLQ5p7o+EkHcabqdw3iwPxtIvrqFDNEutRcMq7af9j8lY4TEcjBVLVqteRlImdD9Cu8NWewgOZEn8KE8HU+SNXRqz4pwuVJhMUCS11jP5cKypvk8+q2mtOO4csdAToEIaISqzMEIQmAi5JSlNVSUhkHieHY4To7n91R/qPZMmQrbFPKz/ABCTKyqTaH8AcSw2zDw+yjUWPqEtY9oYDE6kz02H2VDxBpMq57MYV1OmX5pFSDA0brBtuVLXR0TmjdXs+abiQ5rnG8R+QotTA4hpktZ4Axb0utMzDEiY809SeGmHAfMWUezR1hhsS6qHkGk8gfuAn1ClUaNV7Ia03t3u6fR0Lcu/SBFhJ0ss1xXFNLzB0A89b9UOUip5HXWGfxOHLe48fyqjiDHgMbnJa2S1smGnmBsVpcXUe9gt0E6qvx3CHgB13CAY05c9UnPRrFJNaUb6dSxzvE3nM6fmpNLFVMpa85xH7u94WKs8PSc9gbk66gnQfwqzirzT7uW5Bt4JtLNNIp1eIinFsc0tgMeZcdwSBbXQ638BNlY8LwQID3hxA+EE2cQTLnDXcdbKjwGAzvE6ctdSfay1FesA0NGwgKUdHPXjOL2zqriSbCwHIQFbdnngd8gyZHl4LOYqrkatN2aqBzADqBcfVV8nnX6NbgH5hJhTmlpPxBZ57yNEMqk7weR0V6cznTSFh2XMlQuHYuZa6xGx/LqzAQmZNYMZAuXDb3T7m2TT27JgZ3tPhQ9gdu0geTrEfJQcFlgCLLRcVpA0njfKfa49wslScQlhXl1hL4ngsjc7Jy7jdp5jopmDxTywd0nbmo1LF2g3BEEbEFTcHiQGZfKfulSLm3mM7qVMpBOoncAnorfAV5F/fZUeJY4tJYCT5Km4VjcS95y08oDiJcDmNzs6ItG6S6Nlxect6uj0mm5OKr4fnPxCLaK0C3lto8+1jwEJUKyTkrlzV2kISYyBXwsqqxOBWiITT6YKlopUYbH8JnoovCHvoF7RcOEwdLbjkbnxlbLF4ZZzH4Y3y6i6ho1iiuxHGXMJz+ot6hFDtMxt3lrhtcFRqvDi+7ifBR6PZZpuW90n1WL07Z8M7LWr2ka8EUmA8yPa+ypGPxD3klgDZAbOpHkVpKfC2U2Na1oDdTA1PWEow5kOgAHkPsjv5J85n+1FSyrlBB81ZYR4IEnblPVd4nBggxoRBUHD03NkAyJgAi59PmnpOKkLjsGWy5olszbaeY5Kq4hSFYNDruH7tbRF1eUKxPMH3R/TNzE5dTt1Qypty9+UUjOH/pMsyJ3VdiKZJAaCb728h6La1cOY+G0SYVdUps/dpMwEYV/FpvX2Y/Hv7kk+AO/TporLhOJcxrH5pJY3a2mhU2vhKbxcNysBAEfESqUUnskZDkB7tjI6HpyRhSxo22Hxge2fUKZTpF2g0WQ4fXcBIPdO8xCvcDxF7bucGtsJPXRCMqnPRcU3xrqNDuPurfBYwE5Tr+XCqRSzNztE352tyTQLwQ4WhGtMhpUjUkrhwUHA4vO0E+ikveq8jDxaeDWJu0joR6qidgOi0BaCdE83DhUuyW8MdXwJGihfrPpmfbYrePwbTsoOK4Ix40TaHNL5K2lL25o1EDz3UjC0QwQGiTFhoLaldYfhlSmMoOYbcwOSnUMI4apKX8lu+uiwwR7vVSlHoshPhaT6Oeu2KhCFZIIQhACFcuC7XD3R16JDGqjJVNjaAaZOhsr6FEx2GztI06qaQ5fZmGUhmMKfUEMYNFVYgPpP77bf8tR58lJq8QpOj+4zSIzCfQrBnXL0kvYHHaOUp52HnaNdlWtqcinRj8jS47KdNPFv0PvoQOqp8RZ2mnorhlfPBvBUhuEYdWhGgv6fZkMVV74I5X8lKZiRA35JO13A2taa9FzmubGZuYlrmzBsdCJm3JQOHvkAPF+fOdEk36NMml5F9h8US2APdU9fgtSo8kVAxp/bf0ClgAc1IZVOzj5wfRPGSn4vURMJ2eZTu97nO+LWB5DROYzDAtzAgz3XWGlualV8QGtLnkRBuSq3AcYp12OLbAGNImPyU08B+VdmS4rhX0nk0jpeNQRG4+qsc730M7mFgsYLgZkiRbpKe4k+A82+Ej89FV0MZmpZIF2xE3990Jo3mHWfo9H7G1s1CHGSCB9FOr0O84bSVluxJe1jp/5gejRPv81rf1MzuYgX6q33Jycs+PI8KlhfTfLfhOv3VtQr5tFEx+Ja0GQjhlWWAgKCaerS1Go8R/pTGBQqFyFPaFrPo5r9igJYSoC0wgMqMqVCMAISwhCYgQhCYAhCRxQAOdCbKRONbCAFhIQukiQETF4RrxBCyHEuzZkwJC3SQtCmo00m3Po85weHfRzNcHR+0aga6KFxCu5wgNi4MzyO69NqYZrtQFX4ngrHAw0LKuP6OiPyMespsLiw9gc0RI05KdTeRcqGyh+mcuU2PLr/ACpuEoPcZIge6hSyq5JwR1JtUOa9stNiLrJ8e4CaH9xlVzWDUEgAbC8eHovQqNADRcY7h7atNzHCzhBkfRX4dGU83jX6PNaYrR3Xlw8inQx5Hed9PktRT7KuYMlOoMmwc246SDonqXZhur3l3QWCnxZu+eTD4nBOfZsu8SSB1VZw7Avw+djgTmOdvUwR9l63S4QxohrYSYrgdN4hw80/Bkz+Vj79Hlb2VarQ0Nl8QY08zsnOE8DcatPOO+JztiQck38xl816hh+DsYIaFX47hr2kvpmJEGAJ9whQX/N9tpdFDVrNp1GsJAkGwsBJtI63Vzhq0CAqLFdny52e4dqTrP5zU3h2GqMdDmkiB120k7JtGbuWt3sexj8358+V0vC6+Qlhm5tbRWGH4c95lwDZ8Z991ZUeFsbeLoUszrkWYO4RggRopgC5pshdrWViMG9ABKhCoQBKULlyBCE9YRcdUuiQFMDsFCAEIACmvmnkmQIA5a1dIQgAQhCAESoQkAIQEIA5LAdQuMsaCydQgDhrV3CEIAEkJUIAREJUIGIQm3tsnUJYBF/RHJdsogaBOwlRgacBq6ASpUYAiEqEwESoQgQIIQhMDiTougEqEAKhAQgD/9k=",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhYZGRgaHB8fGhwcHR8kJR0fHB8hHh8kHBweIS4lHCMrHx0aJzgnKy8xNTU1HCU7QDs0Py40NTEBDAwMEA8QHxISHzQrJSw2NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAABgQFAQMHAgj/xAA9EAACAQIEBAMGBAUEAQUBAAABAhEAAwQSITEFQVFhBnGBEyIykaGxQsHR8BRSYuHxBxUjcpIzU4KisiT/xAAZAQADAQEBAAAAAAAAAAAAAAAAAgMBBAX/xAAlEQACAgICAgICAwEAAAAAAAAAAQIRAyESMUFRImEEExRxkSP/2gAMAwEAAhEDEQA/AOzUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUVigDEVV8W4n7NCylT01/StvF8YLdp2JAIX76CuR8R8SFmPMUrfg6MOHl8n0hvw/il5OpJBgjcVa4fxQNM4+W/1rmnCrzH4WkkyeW+vOrlw6/EYPStVlnjg/B1DB45LglCD1HMeYqVXJ8FibqsGViCOddC4LjmdffIzHUdwN6LOfJhcVa6LeiiitIhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRXkmKAM1HvYpV336Vi7iYEgT2kTS9i+O4cE5lbMDtrP10rG0ikMcpeC5TiYPLTmZ2rP8AuqTlhp8q5ljvELPLS6JmKhwpUSN8s6E79dqt+E8RxNxFZSuUjV3B1H9I5jvtWJ7Oh/jpK7HBOKMT8EDuf0FbxxBYJMdtf3FLz4y5oM6Ec8oPyn+9b8bbzpKypj3YjfcSOla+if642rI/iHxQbahUAzMYJ190dZ61WYLiWIcZ5Y29QSW9DpMnzArYvBQ4HtnZ2YbIIGvmCftVuLFu2ipICARBgnYzJGnep03tnX/zjFRjHfsT/FXEmKMiiebGeY+8aUo2eF3GAciVO2XUepFdC/2O27l2ukpB90aHkPi1nnULD8MfCuTmV7To5XkRAGjKdvi3k01bDlS4oqOFcMCEM0ZzqJOwFWly4pJOZdzuRp2pXxOLZjPIamqtsQWYk1vL0PwS2x5uY23bQsCrudlBkDuT+VXPAMcS5bNrpA7R05azXPOH8mPOTV94cxIOIZp93RVHXaPzNYwlFOLR1jAY0XBIqZSovEPZMg5ncf001KaZHm5I8Xo9UUUVpMKKKKACiiigAooooAKKKKACiiigDFKfjPjQshRPcgc6arh0PlXJONu+JulfdUmdW1+nLlSyejp/FgnK30jQOOXyC6KSAQJ8zAG+tS3dsSQlwBLgZYZCVJQ/HJggwIPr5VTWLbWkKsxbXUci3aPKmDhzkIzBSGJAk8hGgj0qfR3t8vossY9sKiBRlQQo3AHIZeZ7nnWv28jae5/TlUzhHBnck3QFEaA/PzFS7mBFsqCEAJ5TM9pHSrRaRySaT4plHawl66wZTkQfiO3oPxGml7YRVUTBMSTqYEVV4C4+4DEFyAOymAfXerfiuyHoT9v1rZO1YtvkolTx7G+zUBDE/ERy3AJ+Rqjw3FFgk6nWJ2Omh7nfSvfGGLFlB1Om/Pn96iW7KqIy7GP351F32dkIxSol4bigJAdV1/EoE66we3epWKwiXcod20UqMpjRiCdCN/dFVKWkPvBACNq3YZyyQkhgfhPcxoeQ50qezckV2tUVXHPChCFrLMxGoQge8OgYGJ+VQ+DeD3eXvtkXkqwzk9Oi+eu9MV3HwsM3vDl/fnWmxxODtI5090YlKS2XmDwWFVAnsFK88ygsestvNU3EuBC2fb4cnIhl7bbqOoP4h56+dZxmMulFe3EgwZB1HeOY/WveB4sFcwsloDCNz2FYmLwato2Yf/muu4cqog6g+UdhoafsNxBGAgx5/rS5iMJbGVEyo5P4TqD/AFDmJiotvGPb927lzkkZddhzmIIPaqxVnNkipJD0DWaW8HxAj+YA/hYSPnutXeHxitoN+n6daOjmlBolUUUUCBRRRQAUUUUAFFFFAHmaiYniKJIJ1HIVr4rdYKFUwzSAekCZrmI42Sxzkk65h3B18taxujpwYOats6G3HrZldQSDBO3zFc+x+Eaw5c3kb3TK65gTsQD9zU21acwQWVNxmiW7gctedasaqMrJpLdCN+s/rSvZ0QgoNpeStwOEDuqliFHMfvzpqweHCFVVRnYjKOS9Cx5nzpW8O4VxfW2x90nNA3gakHzgD509rhIJfYn6ADl++dao2E5Uy1w5ChVnYGSeZjf714xmJRVOaOwPM9uvpWP4YMozHlJHprXhcDbX34E8ppmjlXezfwu6pWIAI3Gkj09aj8Qt6l94G3StC4VPae3T4yoXt7siSOuv0FecfeLKRPyo7QyVSFVlDElj70mFkDWe/aob4tVaCPUH7itl7DHITnznMwGYQRB2zcx86qMbiltqDdDIp0BIMHyMdKk76O+LXZb+1WQV1U6yPtXrDYhQ6gbQfXkNv3pSYnHMN70XLiEnTQxHpU7D8VtBQUuKYP4tPr+dK00MpRl5HHFeGgy5kchujag+o26c/wA60WeG+yIziCdiDNQsB4uQ+5oxIMBSDp3q0wIe8dVGWSAJ1B5H99apyXhEXGSW2TMaw9nCakcuuhBHnrSx4IOe/ccwci+6P6mkT6AH1NXnEVKKQdIEEUl8AxeRnKkySJjTXU/Xeh+2Lj2nFeToNllV5PxAggnmPX1rdxu8XyNbUOVYneCsrE/46VRC4XWR8QHXTXaSasMNhHXVGBaI3P3otvoHjS7YPbufHnBXmIII7FTrU/B32A3IO4nl0+1e71l3sOTlV1DajqBOo5iqDgvEXuIVBkplJ6gGZ9JH1rOmMvnGvR0nCXMyqTuRr51vqm8PYsOpXmp+9XNOjzZx4yaM0UUVooUUUUAFFFarl1V+IgeZoApPE18oFYDXKwX/ALEqPtNI9yz7K2190zYh2kKYIVQ06Aj4mAnqJA703cf4khiNck6nYkxoPkNaV8PdLszN70zA03/WpSez0/xlUFa8/wCldiOLtdYlj7rKIE6gzrNarDjN0qzxeBR01Up1OxnqDz7iqC7wp01HvDqs/VeX1oSorJpv0Xfh67//AEs8DVdJGxBAkees+QppOKzPIOg1A7kwPPakzAJkAdjAJy6ncnUATU+9iSNVOsqR6T+cUylWicsfLaGbE4wrcCCYUAE9e/0r3isTKEKZMaelKY4m5YM4Dd9j6cqlN4hsqVzsEk5fId+8UWT/AFuPgm8Mxz5ZfQSRr0Gn/wCtPSplwH4dp2PWqq7buX2bI4VR2mQZIj60WHdPcObszEnMe529BWRkUyY72mrN7YcLIMaGRI5kz86g4hc4KuouIRBRtQde/P61ahA/OCOXI+VFrDagfWqOmrIcnF0InF/9OkuL7TCNlbWbTnQnojHUeTfOkPEYB7TslxGRxoVYQR6Hl3r6JtWkWGZecCec84OlRPFvh+3jcOVVQLqa227jdZ6MNPODSJmOST6OJ8HQqwcaFT+/pXT8DxhUZVyzABMcj2pIw+HWSoH4oE/n0qfhsanvNm90Hf7UtnXwTWxl8RceRWDEQrKDG5JHIgVzvhOIGe8BMZgyzyBJjfzFW/EWzkvucsAcgB08yT6CqHh65btwfzK3zUq35Gmr42TilGaSHvA3ZQRp19Nq22brDmaqOGYiFAnz9etW4gxHTfr3+4qa7OmWi3vX2/g3UP7zI/PUEDTy0FJngjGucxUiSsGenpV9duZUJGuhnuIj7mtP+l2Dt2715GX/AJPitknQ29pUbSCd+/KKZbJSlwV0Nnh6+y3QsGGEGfy8qdqrLiCM0arJB+/0qetwEAzodqeKo87NLnK6NtFa1uqdiK2UxEKKKKAKzEY/IWLaqPpSZ4h4t7ZyqsMq7nkB1Pary9fD+7vmU/auX8ddGd7bAkZoVhObQ/WpuR6GHHFO/KGDH3wUQAnKVDDlowkE9NCNK0Ye9lZRGnKNfUGr/AcGa7hrZZWV1UKQwgnIMoPaQAa0fwOTRl+Hb99Zpa9l1NNUjbinTKNQCR/mRWP9sYrICgRoWMfLcmtNvCqGW7fgKuqpp728ZtdPKNag8Q4+zOZcBRsBpQm12LL0il8T4e6mTNqAwggyN+XT+1Ww4Y5tC4jnkCDG/Wah4jiyXB7MkPnkR0MfSmbh2GdMMEyMVZgVMddzG9bFJvYSyOKVCliMPiFJUyCNoj7xUfE8HxDxKKW1BltumpUDr8qdr+VWllh+Wm0Vh3B17fOnUEK8zqqKPhGOuW1Fq8i5GUKzoTKlZyEAgTvB+dTeG8QZj7Nn9pbMgSdVbkN/SjHKCrENECapPDgLpfTLmZGRweuYFWg+ap5TWNVoI1Vl890o0JIjUE/by5Ux4A+0UOBErEdGJE/KPrSWeJKCA58mOhB5hu45zTj4db3GG3vGB1kDb1pV6YZkuNo949tY9TVQOKOtwMPg10J1Mbnt/ard0K2zMZjJ7Tv8qV8djbYyG46W5GhZgPkCe9a9koV5IHim1Y9ot604Bcy6A7MRMwNucjuOtUGE4fYF++9wTDAKAYEMqzt5k1FxuMtvfuOk5Np/mygLmHnGgqILjFiZIOaY7QBP0rKo6ElSQ14nA5LRdDnQCCfxLPMg8ojWkrHsbd5X5TPmNiPlIp54ViGt6jWRJB5g9jWeIcAwuIX4mssTPugMskfynUCeQNapGyjSdC9w3FLGnWQaY0eRHIUo8NtsjG06w6GG7gH3WHUd6ZGBDhDEkA9tRM+UUjWyvJSimTbdyVIO1VOK4scN7O+ghkvEa7MjqxYDnArbicaoCqusGWadCeg7d6ofHJOTDjYNnfzPuqPkB9a2PZHK6idd4X4uw123PtVBI2O4PpUbF8adkyW3XPMq0EAQdgDvpXEeEYhkk+zdmJ0kkCOekanvT9wrFOUnI2cAkIY17AmBrTSvwSxwg1yLvEcZdGW0XzO0GQZAAkRpHNvpTXg+LAZSWI6jl3pFs4QtcS6VyFxqp1ZWXcE7akjboas1uFSBFYmx5whJIev96tdT8qKSfbntRTcmQ/jxJFzFKHQofdIMeR/v96X7nBH/AIlbuXMgdWgcxIJB9K94O8Xd1MqV0A7ROnpVv/FFVy667Rz+lTi00dGSLhKkXfEOPokwKU+K+I3YwvzOwqRcwF4s2ZRG41XTqKVeP4a4pACkyYjzrXbMxxijRxTjDfz5m+3pSq2Ld2gZiTyEk/KnDAeEXZs1wwNPdXfnz5f2pnwfCLGGWcqrpsBqfXf1pooycqdIT+AcJvqVuOoBBByt/LzGmxIrqGJ4qr2VyGOUHQjqIpTPGFD/ANPQD86sOM8SR0XJIVSJJGp0+nOhySM/XJtWiU+OzogOrI4JPPL2rTfdQPaI0idVIjXp2qrR1YwjhjEyvITGoqHfxLoSoAZdJB15/Q0cqKLGm6L3iCK2HdlO67R61VeBsdmzIFmc09xpUoXgbcrJzxoOZ1mY5/pVd4Cts2IvsQPZ2mGo5lswC99RPpQ3bsVx4pxZs8VcFtG4BluZts67rzjTcTpz5Vc+EuIsp9m5ZxBKuF1AEe68aTOxAHTvUrF2WunIvcjp0mfpUEX2w1t0lS86DN8IaSDt369Kz+waTjS7PHG/EzFGtWVDPJBLSANY06n6VzzE4W9fbNcYEroABtrrp+9q6J4e4SjQ/wARYamfhkToNv8ANSMXw+1ZYBVJR/iJOuYHcHp/emS3QrqIgPwf/hlM2dCC6n8SjXQdede7QUZGYLLfkCZPYCK6Hh8Lhki4WJOaQATACdQdTBFc/GD9qyYgGLbFxln4WBMg9ZGoocSkci9FiMYJAjXqRBI8uQqVhHLwEV37gGP/ACOn1qP4gdS1q4u4WGB5wZUnrFRU4m5nU/P7VnE3k2tDdY4GrFWvWyzLOQlsuUHeWUyesbbVBx+Aw4YmbjSIMN5DSR2qJbxrwFzEyOtYxJMff9/velkEItu2yl4pw5gwbDkupIlWMFZMakbie2la0x7OFt30Q+zJA01Bn+Y1aKIbnvtUI4QOxcso1JjmQDyj5URNyRSon3uI2bdhnRAHJVZJJiWAnXoJqZhXb3DmEiCSe+o09D86Xnw6ujodBBbsIBP03qB4f4w5BVlDwBl1g6TAJG4A9a2mL8U+I+3cUQ9vM3xZnmdAAMokd259jWxrse8YPlyrPCcEt+1DpkvIZGbciNiefIjlWWw4TRp6Geh+1FeRU10YznpRWr+FPb50Vlm0WNvgDs6sTl194zrAMiPt61JuYooMvwgaVa8PclAzRJAmK24zhiXAZ0PWtUVWibzfL5Cw2KMiDMnYdKj8ROZ0OTPBED7+VbcbwzI8FxprAB/xWlSc4G6ydf189p71lUVi1LYxcB4QyKXxLhncyBmMKusDSJJB15bV54/wnDMJZihPMNofRpFaU4mLkowQSvuA7SBoDPoKTMZxT3tERYO0ZteehMDblWt6JYsTcrbozjOEracsXz2zqGA1kcj3+9aE4iHyqigJqNeY78qvsFhxibDI6wGkSvWZBHQj970mXrbWHZG3tmPlsRPURSrZdunTfR6wbsuJVQSBcJTTv8P1y/WpuI4VfBLqQZP7mq+88G3cXdGVh5gg10W2qkBiPdIBAPPNqBTxRLJJrYl3kv2Uuu4WIXIUnVtdY5aRVl4W4XeR3bQhgucLMNm1UKd53IPY0y/7ajjVNvvVtw1RZ9kg55pnqRp8oit40K83JfZ7sottPeXLlEx0HKTSNxPNeLuFPy5d+8U+8evhbLk8xEdS2gj50p8Lf3wrTDaeu4/zWP0GF0nIuPCHCWt2szghm2U8hyPY/pUfxBafK+fULqsDYenSvN3i16wzIxzQfxcwdjO+orXc48rrkKROkkz9NOdDZqjJy5PdlMQ5AbRoAhgP3B1NU/GQ1tCqgIpfOQObMIJ7bDbqaucRjlztlWFnQbctdB3msIExAKOoI69PUbedYpFnB1YkG4WzEsNIgHv0qRhxUTG4VrV17bbqxE9RyPqCKlYa8oTMQWBMAeXeqkl2W2FcwARodj0/tU9VnQ1Ht3rbBcvIbHvoal4aGXf3hE89KlItDoicSUotxug3B5nQfeqzAiVOvvH4Rzj8q9eLseUthVMFiJjkAZ+enyrHhhwipdeWdpMGNVGgJnYAc+9bFWLOXyoPEFu5bw7qEgkKbkH4VZgoHcmdu5PKl3gbG1dSQfiBjb0M074rF+3xAdWhSFDDl7u8TuKkcX4Bhrl8tDqxUMxVt2+HQGRoFB21rWyfB8rZepxC2yK5ZUfuwH0515xuLW8M6bAQT1aND6ikbH+H7ts5xc9ohMEmQwBMAnUgjyjypu4PdQ28iagDU9T1oBQ47IXtT/M379KKZ/8AasN/7n0NFZxN/ai9t2sq5YiDEeWn5VItmfStnEVyguBI/FH3qJg8Ur6rO/1FN9HFbkrKPjbg3IM6fpP6VH/2zNGWddYnr2I3r1xtx7Vu0fYTWcDjAgk7LtRS8l05KK4lRfsMl1gjEFEzNsTm0JA003XXuelJOJxpd2bYmWP30p64ziHIdgmRXkZwsEgqR7x3iYie1ctxGOKnIVErIM9RS0i8JNdjx4V41kORj7rfQ8q9+NcIt5Pap/6qDQD8ag6qRzIkkfKkjAtcfVSAJ3PXtVzieI37KhnXMP5lP686yqCdN8kU9viK5MsHN9q6Z4TuO+GR3aQfhEbQSN/SuSYjiTXGeFCqdSCASSTzPU11fwtxa1/D2lZwGVFUg8zHLzmnilZzyk5R0N2GJIqFxZ2UowaCpnfvOter2PCnQ5QOXMn9aqL+M9qXABB36z5Vs1qzMMfkrJvHeIq6IFEqxme4B0Pkd+8VSK2UyCARselecNe9mxzgMkyyn7r0Iqwx3DssMqyje8D9ftUTqSjH4lfxS9mZX6qB6g/4+dQWYzNSb0ZY6HSo6qcpHL9xWtjRVKiLiiQx131Hr+zU7hTlNYmah30+DvP0qXZaEjQT8wOelYUvQq+I7pfEkfyjL5Hf8694QfCI0BB9a845mbEOB8JPzMDf1qxwuDdjAQk9unnVktEG1ezGSB3JIgdAP81vwGZW+IzGg/v5GpqcFvxISdORH2mo1iyVeCsEbzuPQ0suhoyV6FfxSc+JVAZA/PefrVkqsHURoUWJ21/Kqh8SpxFx2+FT6nsPM1dYTDXnC4hh7rEKBtoNso5jl5+dC0hY7m2TL6ZzFtcq21ALaDMTuWMxq0x2ipdvFsb2bkInyAFVPFRkyAuwZnLZI0KrKyW6gjbvUq1d99zEzAHyn9+VJLotifya9WX1kh1Kbghhr0P7+lM3g/w0Ai3bo1OqryA5E9TpMbUscEHvrMkaTXS+Cv7rJ/K0DyOo+9PFI5PypNWkTvYr/KPkKK20U559s8soIg7Uo4m0+GuEkTac/EPwnlPQ8u9OFa7tsMCCAQRBB5g1jVjRlx/o53xV81wkCfeggc+VaLTqhZhqwAE8hy0HXvVxxbgnsWzKSVbQTqV7Tz02qmazlUqPMnrU3Z6GNxcbRGxOMJYmZzcj9QQaVeNcEt329pb9x599fwt3WfhbTbY9ubLfse7nGgHxeu1VNwanLoQTFMirUZLZpPDVtqJIGmxgb154lh3bDSuqq+pGvIwewn7ipqY5iAvw6Ry1767GtaZ1JhlImYOn23reWqF4NO7EHGWYzECD+IfnTv4Fw5YKwzHSTp/KdPSftVZj8LnLEqFYklR26eVX3gniDq5swS1wiCdlABnvGlZYrjxbYw8Uzh4RfiAEyNyOfTaJPWomEsOLgzgqRuTsRGuux0NaOOcYViUy5sp0cCIYfiykmYo4H4pe6SHNtQo94/CfOCdaZydUZxaVoziWk9ep61dcJxIfDvZY6rqk9N49DPoaUeK4speYhhkeD7p0BgSR0BM6etYsY46FXEjYg1FOi8o8oot7qakHRjsP0PPnXh7RGle0xSuA4PmBuDzjp/etyoGTMGlgdjoYNBl12VmPOUoOmvzI/St2GCBHuakrpl3lvw/Pp2NbcTZUqXc6LAgbzy8qqmxabCdDtHSi6HS5LQs8LxUvFzNMyx3nXXyrqHh+2jJ7jhwd9hHKD++dcix+IAuG6mnvSB16/PennwZxMX8xWEuAAsQAJ6FhseetV5OqOSaT8nQrNvII60s+Nby2bJuEagEA+YNMuGulviHkaQv9U7+a3aQHVnYx/Sq6n5lfnWd6Jq4uznfD7echWMKWzueg/c09cExL4i4mgFu0BlHZeZ70l4dd7aneCx6xr+/IU4cBfICF00++lPVlsekQPGWBb2sg/Dqnk7FvTUkelT/Dzm4iz8YMGDEctuhU1ZcUwwuoDBzLH21Hfr86ieHbYV0uMCpzKCTsynTXyMa9DU8kaLQdbLrhaxdAO06x5/rXR+E2gFZh+IzPXvSf4Q4JnZrj/ArEW16xsT6Rp3p/AimitHF+TkUpUj1RWKKY5DNFFFAFXx2zmt+RB/L86T8TYOwroLoCIO1UHEuHFdQJX7ef60so2Xw5OOhVNjKhB1BkHypYxvDihJTVft50+28LmYhtBI1r3xDgKsM1snbVSd/WlprZ1xyxTpnNblhigO86nTasYS2WYK0wPnHnTTiuHlCAQVGpA5abjvUB0gkgQRHLfajkWW+it43pcGkKFULH6nfnW/w/ai8l4GYhW8yDH51Jx+BNxNIzcvOtfCRkKJBBLksP+oEfc1iZk1ogY7Dw9zpnaPmap0w8Ezz/ACpgxuKW45JUEgmY5Afeq/8AilTUorDWMw+9MYnogtZJjTQ9NgeflXsWFtn3QGPUjQT251KxHFfaCAqoQIEDT9B61VX8S/vSQDHT0pJIaMj3YxF1LyspJVpDAKIMazlEbdaY/bZNWOUt8vnUDwyjXXRzblRKwOYJiY6aHenHglhHdlb8Le75AEEHtB/+tbQrklbQuYjFrkY5tDpp1Gp+Va+FhCSzGTEg+XbnpW7xTwe37VjaEGfeE6Zt5A9eVQcDhmXQ6R061iSspybjXQu8ZwqIqhCCrZp6iGMEruun2o8F8R9hiFJ+FvdbyOxjnB+5poxeFtlixGuU5tBqOZ7chSBibeX3hprp26U5zTjTs76uLgSkGZ25R+/pXJPEvHFvXJXUKMieh1b/AOTa+QWqbhnEcV7yWrtwBpDAMYMjKZnsal2uHG3IdDm2E7D9aKoWPyXWg4VaOrncn/NOuBwSqiMQWZgG7RyEc6p+GcJZsoiBIBLGNWOwnVtxt1p2xiBDlBlVAAPkIH5Vjk0dMUuioJcZmnNrJ0jnGg9RQcMFYox2Oo6SJj0/Kt93FZZK6zoAeo1J8hH2rd4f4U2IugalQczt2nWO52/xWtuSFclHvSR0Lw1l/h0CiBBHnqdfWretdq2FAUCABAA5AVspzypO22ZooooMCiiigArFZooArcZw3MJRsp6fhPpy9KgKHt6Mhj+mWE+Y1HrTBRQMpNC9fS3eUpInpzB8jtS7d4M6TInTcdux12p4xnDrV340Vu5GvodxVfb4O1s/8dxmT+S4cwH/AFaMw8iSKVxstDM4iSbRXQASdh+9qrMZKvm5hH19DFdBxmEQ6OpRuu4/8hp84pQ41ZOZkXWFIzdZ3jrppU64uzqjlU1QnLbgjtWLq7yJBFWF+yVnSqzHvGoB0Gg+tUspZWISso3eD51Ext2VnnGtSb9/NyA0qreWOVQSzaChmdKzoPgdwti42xW2sHoWkfPWrXgOKCXVLbNufmKk+FuGex4YwdZdixIHQaLy/pqksqSYHLasEg1Kxp8QcPQZX0Akz35gab0uYtDpED986kYLiTmyLLjMVModzpuv3itmRSszMnQeXM1j0VgpdMo8RaJf3wIK5dNY32POk3iFn3SNoYfeKeMXaUHRtthrS/xGzCu+5IYnz3msTVjuFxaZE4LhoIC8tzTrw5nmWykLqZAnSk3hGJAWPtVwlx2WBKruSxgf3q1o5IwZa8d4mGdGVRKmZB10M+W9Wd3El0RisFgDApbw+JtoQYzvyZvhHkg1b1imXh7vdtKWBnMdxqdZEdBrUpUy0XxaRow3Dnv3VsoIA+Juk6n6V07hHC0w9sInqeZPeo/AuGC0pJAzNvp+9f7VcRTJUcObI5y+jNFFFMQCiiigAooooAKKKKACiiigAooooAwRUS/w60/xW0Pmo+9S6KAsVOM+C7N6WQtbeNxqp81J+xFcw4x4exdi4UZHYfhZVLKy9QQNO4OorvU1isorHPKP2fO48NYxxK4a7lPRGE+ppo8KeE1sOLuJXK42DAx6SN+tdgitGKwq3FKuoZTuD+XQ96ziP/Ib00IXEfECNKIJBEH1+9LeGYiTyAqTx3hhw+IZZhfwydwdj6ajzFV9zHqZQQCdo2jek2uztgouKaJPDlggncNI+elYa/IIbT3iBHPWa38MEqXGuUSSdgdh6zyqM2UA5iQeZPeley0dM0owfloomfLlVVi8LnfKJCiCfXYdzpVzYQvok5eZOmmv6VY+GuGtexCAAZEIZp6A/UmiKNnkUbl6FjCeDuJW7kC00HVTuI5bbGIpuwH+nN9hmu3grerR17Cup1mrUeU88vAp8J8DYa17zg3X/mfYeSjSKv04baERbUQZEDaptFaSc5N22FZoooFCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAEn/UPhmdEuAarKkjodR9QfnXL2w8HbyP72rvmMwi3EKMJVt6Tb/gwq8j31PcKV7nkaRx3Z2YM0VHjIoOF3AlkIPeDLGXvmOunOc09j2qJdtpJLE5hvp+5q6xfB8rFQjIATAXfXf8A7VjCcIac+yjckDXrA5UlM7FkhVoj4fAqqZi2QNAg7webHkSaavBnDQguXtf+Qws/yrpPq0kdorPDuHm8PfXKgO3No+w60zIoAgCAKpFeThz5m04/6bKKKKY5QooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvJrNFAHg8qgD4z50UVhSJYrWaKK0mzNFFFABRRRQAUUUUAFFFFABRRRQB//Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhUWGRgZGhwaHBoZHBgZGBoaHBgZGhoYGBgcIS4lHB4rHxoYJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHhISHzQsJSw2NDQ0ND80NDQ0NjQ0NDQ0NjQ0NDQ0NDQ0NjQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAAIDBQYBB//EAD0QAAEDAgQDBQYEBgEEAwAAAAEAAhEDIQQSMUEFUWEGInGBkRMyobHB0RRCUvAVYnKS4fEzFoKy0iNTc//EABoBAAIDAQEAAAAAAAAAAAAAAAIDAQQFAAb/xAAmEQADAAICAQQDAQADAAAAAAAAAQIDERIhMQQTIkEyUWEUI2Kh/9oADAMBAAIRAxEAPwDTklINhOLIXU8UdyCCTPqmNZoSpcq46yg4c5ic3RINK6WwuOE0LrRKTSnFtlxwsqeBayiapWrjjsLsJpBT2riRNCkpqXD4N7tBA5mw/wAoxuFYz3jmPLQIW0SkBAToJ8FMzCPP5Y8bKc4sNs1oahqmMcdyhdBKWT/gP1OaPC6Rw9IaucfP7IF1c81Ea3VQ6DUFoDRGjPmV32tP9A9FUOrdU32pQ8ieBc+0pfo+aX/wn8p9T91UCqU5tY81PI7gWpo0j+YhMdw4H3XjzCAbVKkbVUqgXJM7h7xtPgfoh3tjUEIiniyPzeqJbiw4Q9oIUqgXIA0pORxwrHXY6Dy1CGqYZ7dRbmLhFtAtECSfCSnZ2ima6brsJMans3RAjwu7pjHJrwZgKDiYuSJUIYeanYxcccY2yeSkU7KuOGNUnkmgXgK1w2AA71T+3/2+yhvRKWwPDYVz9BbmbBHsoMZr3nddPILlfGbNsOiCe8lA6GKQytjCd/RBuqlRJINhqRFyaSnOUZcobDSGuKjITiUQMG+QI8+SDyHoEhMc4qzfgw0SSqx9Zl7oKpT5GRHLwNFZObXCjcWfrB8IQz6g8kPuJDPYbLFtYKRtRVQlTNqEI1exdY9FkHpzXoFlVSsemKhTkOZWRuHxxFjcKqa5Oa5SqFuS5/Ft/QPQJKo9oeaSLkRxKt8mNh8VKxMDSpA1OK50BJ7jK7Cc0LjjoCe50qOU5q44kaFIykXEACSuU2FxAGquGNbTb/MdT9B0QthJbG0qDaQk3dz5dAg8RiC4rlaqSVASgbGzIi5cLlwlMLkDYxIfKRco8yje9RslSPe9QPqJriVE8wl1Q6ZLHhjMzsx0b8+SNfXcTYEfI9UHw2uMgaASXE7W1i/orN5AAEgTa2q5Pa6ZFLVdoBr4UmYJlQswALYcbjpCs673NEgZh8UDiMRIzC0JVTKfYyKprSAxwlhMi0fNdfwwG1/MyCkziDQYkSUUMSCQAZJ+Che1robTypgTcDBIzS0baweh2Q2KpFngd/oVoBhwLhVfFT3SNp5XBGn1HmmOVMi5rm9FW2qpWYhBlQ1Kobq4DxIQc9DHi2XTMQCpmVFnBjWfrHqisPi50cD4EFFOVC69O0XvtElWfiUkfuIV7TCMycwIek3qiaYjVXTOJfJdCaXJzSuOHhi6ynJgXJ0XQrXA4fIM7veOnQfcqG9BJbH0aYpN/mOp+g6IKtUJKkxFWShnFLbGyjhKY8qM4lskZhI1E3CifWlLdIaoY970wvUD6iaXIXQakIL0mNlDe0TnY0tsB8YCXWSZ8jZxVXgL/COPIKHE8NdEhwI8E2lxZo9+x6XHgpmcRDtD5FD7mNh+1kl+AjADK0AN73Ic+ZKtcPSIEugn4DoFV4bFsaJ9VYUcW12hTI4/sVlVfSCKrARB/fiqPtHgJouLDlyAugaEAGQrkVQm1g1zS12hBBHQ2RZImpaF4rqKTR5SMaZ0t8VpeCYwPJJPugAAa36KHtLwahQpAtJDswAl0k7mRyAn4KTslgCWmoR71m+G581lzjqcin7Nm8s3idGhGMcIzCB4JnEMrqZOm5PQXROOxAa3LG3wVTiOJhzS1w7sEddI2VyrU7mmUccVWqlaKPD4Y1Gg5nGRo2w+GvmjcLwQ/lb9PigcNxEh5bndEgAmwI5RorSnXcbAk+F1Xly/JdvlPjoTuDTbu+ZB+Wib/D2NMau/lg/HVNqPg3seq6zGHO023HkYn5Ik5TFvm15JvwnT4pI38WOi4m/H9id2DsZAUqQC5mWoYZIE9qjYVMBMAariQzh2HzOk+634nYIzF1ZspGsDGBo8+p3QTylthyiJxQmOeQx8GDBjxhFOVfxB9oS7ekPxr5IxWAxOUzoYud42PVX+GxmbukQeY90jn081m8RQdTfzbPdPT9J8FZ4DvaQ12saA+HI623VBZNdG5kxRknf/AKXYsuFKm05ZOxhw/Ty8lHWfsE9Umtmc4cvTIMVXizSPNC+1c65NlICJ7wlRvAvCrZNt7LmNKVocagLgFJVeAJB7wVM+q5rgLm60GGoDKJ6fuUqVvaHW0tMe3FNiSnMxrZsUDi6BguEdRv4wsxxzEBrXknaOV9EW6T0AolrZun8RA1cocRxxrIzEnMCRFxbeV5xw/ElxAk960ztGi0ZY0DK1nwko+VEe1B19Q1qpLpgDut5aT6ndb7AUy2m0NGg06Cyx+E4NWAFSGtaDmdLu8QNgAtk/ibMkMMwImIi2pBU40pbdC87bSmOwHH14vMztyhZ7G1YDnHYI+vVLjJ3VFxR5ccjb8/sq1vky3hngibspgTWqjNORolwBgfyjrefRej0MMxghjA3wCz3Y3h5p03EzLzM9Ij7rSytL02NTKbXbMr1mV1kaT6Rlu2GHdLKg090/Nv1WUdj8hBLgJtfxXo3GqJfRexoBJFp5yCsBiuzVR9nHJBjTNmnkZgKv6nHq9r7LPpMqcar6CfxZ5hJSf9NN/U/+4JJHt0Wfcg0ATsiTGqVq3jy5G8QrHg9IEl5/Lp4n/HzQMc1eYenkYG+Z8T+4Q0wpRHiXyUM8qV5UJQDERPKpuIvVtWcN1nuJHM4Qe6LmN1XzVpFz02PlQBUfIsJG4Oh+vonYVjSbCD+90/EUmC7TrsdvNVxqljpBWbe0+zYlLXRo6OOAIDwcxtaO8N5nXZEVMDmd3Blm0Hn5TZU9DiMjqP3ZGYfiLheSjjLryIyYW+0FDs4/dw9P8qQ9nDaXdOSfT4u7nK6eMO3IhO54vvYjjm/gLW7PsaC4kS0gjXmlUwWQSwk85XXYpzyZcMuul/XyTm1ouSAOpGihcG+kF80u3sAxtLuyTAAusRx7hNWo8CzRcnMTN9DC2fE+INeMrP7vsFm69R4cc0B2swL9ZS7tTW0WsMclqgfhfA2MDS9xcRBgd0SPNaOniCASA0TqdT6lVFKo51p/f1R1KlzBPWJ9El3b8D+MT0FMxTjAEwLxOp5KLF4oxcwDEx0UVV5aLNI8bKpxdR/NDxtkbhMtjxB0Q2DI15KDBVmsrNzXE3nmeaqRiXjl6Ludz7lGlxIbVbR6UONMAEAn+mPqVMOJsInN5Gx9FgMBjcsNf5H7q3pYoHS5Tl6mtlOvSQjUvxlrFPpvaGDNBP1WfY82k2RdAl5gOgDcj6JiytveuxVYUl/Cz/Es5FcQ34I//Z8B90kfO/0Bxj9nSLp8phC61aZjBOEp53tG0yfAXVxiHILhNP3neX1P0RdS6Cg0DOUbgp3NQHFcT7Ok9+4FurjZo9SEFPS2xsS6aSM7xvHl7zTZ7rfeP6nfp8B80PTBIIPT9hCYYaT4k8zuUaTCyayOqbZ6CcSiFKBcWzIReQqx9YEnW3RX2CwJr1IdORol2onk0EIrFdnGZwW2Zu2+o5GZEqVhqlyXgB55muL8mWznYIihxAss5sjpr8Va1eHNuIiDboOU7qmxOFIcAJiYlJqGh01NBzeLU98w8j9ENX4xSd7rp8ASocTgcoBVTgMFLna6+olTprySlP0X2G4w2IGbpIU9B1Su8NB9bNAGpKDfw7vMDRBc4M6XgAlbXCcPZRGVtyRLnnWOQ5DVOiNr+FfLah9eWdwXA6DGjOA925cTE9BOiZicJh59xrzcREgcxyUowszcx+/VLCNDC5sdfX/RT0vC0kio2+3ttlHW4SAZa3LOjdVKeG1GtzCD03CuMcA4ADXbp1UTcO9hBD3EWs68oPbSroastOVt9mZqU+fxQNfD2JK2HEcI2s0vaMr2jvD6rLYl4A5rrnQWO+RUOp7IzD4buW3uoMMwvcQBabnYLQ4HBCI15ehP0SNos+FsoK2Gc6zWk+AR2AY8d1w+Nx4/bVXQzBsEACYDG2mDeXDX5JlOq8e6xoHNzg0Dy1KGVO9s502uguhw3MO8XCYiAC7xN7eaa94ptdlMhg7zifUuOnp8FW4rHhsh9UuA/IyzT0y6+phJtHEYhoDKZayLBxa0GREgEjn1TuS8SuxTlpbt9D/46P1s9f8AKSE/6OxH6G/3N+66o/5f0dvB+0alwK6x8pF6bmW0ecNBgGRTHWSnEJ9JsMaOg+S4QlsNEBCzva+oRTYNi8T4AE/OFpi1UnaPDFzGgNLnZxAFzdKzJuGkWfStLKm/2ZPDMJMAEk6ACT6KxPCq5bIpO+APoStLw3hzKDQABmN3ONyTyHQckQMaRrlPhI+aoz6eZXyZo5PWVT+C6BsBgcjAN9/HdOxhytmCrCnWDhIXH1G6Ei/PRXOuOkyhyrnukZeowvMNEnfb4qB2BLi0PhrWHNFpMaSeSveIUwzvNaB+oAfGyyXE+Otghpn5KpaU+S/iqqW58AHaHEBtm6mY8OaH4UyQSd1U4muXOl15V7wodwFV6ey7C4ov+CsGbMRJbEec6dbFWeLBdERM6TtuqPh2KhxbaNdY0tbnr8Fc0Kl53Kfj054lTMmr5CZiS0kHVAYzibWuF73CJ4kXZXOYQHNaTJ0sNyvMW4iviK4ZTMOfYbnqTyA1lc+S+KZ2NS/kz1Phby/v81ZVaRc2JA8UPwrhwpMazM5xAEuJuTuUXUpSIlWJmlOmVLuXXRFh2gCQR/N1C874zhXCu5jXe8SWj+XMZ9FvSzK43kj421+azmJAdiHmPc7o53Ac6/8Aak5X8eyz6dfJ/oXDeHhrQI/fMqxrUYAaLRuEXhGBrQeaOw72AWvKVGNV5YWTM0+kZ/A8Dq1Lk+zZNiQS50bhps3xPorxvZ+g1sPDnk2lzjJ8A2B8FYsqJtWpoN5VmcMSvBTvPkutb0v4Yqv2Waytna5zmSC1p/I6dz+YcpWkwjAwQ3MeZ/yrCrSz+HTc9fBVmKrBlp0+SHiobob7lZEpfkK/En9n/CSrfxreaSj3l+yfYf6OlqaLkLjyn0G95v8AUPmFqGMarZRuCkKaQljBiExWJDBmIJvENifidETVflBKz2Jc55L3aCcrRoBzPU2VfPkcz15LHp8SqtvwEYriJ/K31KqxiCRfVMFTNuoMU7LefJZd3V9tmtjxzPSQXQqOLpa4gDXrZHMxJJg35rNYTi7JcM7cxIETJnl8UecWJA3PqpmuM+Sbx7fg0eDqkywyYEh3McvELOdteCtLDXY0B7bviwcy8mNMwMX1jyVpw7FWPMLvF6jXsyEBzX6jnvHwVyWrx6ZTSqMu0eUZgSZWi4VUHs2jnI66ovivZylUaTSIY8DS+V3Qg6eIUdKkGbXHwVaoc+TSjIqXR0CHN8Y+H3hWAxTmxlbmJMa28SqvH13DKWi9z9kyhjg6CfFD48HUuXbNWymHMIcc2YQeUHaFS9majcHUqUXtble/Mx8d6NAxxNyBz+6Iw/EZ3QfaGnnYHjVpmRr+/sne5rTX0Vvab3L8M21GqHKclYHD9rXZRmy5hrtPWAuVe2DtsvoT9VYXqJ0Vn6S2zVcTzSHNO0Ec9x9fVUPDaZqj2htmk38Y+ip8T2yhhkS82AAIF9zKP7JYo1KQJ2cWnbYEeoIPmkVq639FmZeOWn5L+m8wAZAFlC7FMYbuAvuQrljAREBYjthw65e2RlGwsb6TzhTllzKYGKlkprwbWji2kap1StIt5LJ9m6Tm0mB5Im4BmYOgMrSSALFROWqXYF4ZmuiwoVAGi6z/AGuYWszNtcA+cq1w93eA8pQXaSmX0nNbqS34OBTa+WNoDF8cqZgr8ykj/wCFv5N/ub90lR9p/o1feRqnDdPou7zf6m/MKIvSzwQeUL0B5NGxKY4p40UdTRKGAGLrwFn8RiyQdAPUq3xzbFZd7jmylpN/hqqfqm+kjR9Gk0xzaWYR/tRYjCktI6an93Vi10jQIHEYuxtCq+1KXZeWRt9GQxXDyx0tFyZtz2I6rScPMAOfZ5aJ+ygpOD3zrlIPSUXVaCNktofvfQSzEQbWRGGfmqNGwk/DbzVTRMWLrbE/JXfDGNDcw1Fp+aPCm6QrNqZbJsYwAZgII1VF7z3RpP8AtaJ9QFpFljK2KLHvBO5H7CsZ+tCfTbe0PxvedA5KufT9m/8Ald8D/lPwmMmqJ3lF8VaOWuyrNbWy3vT0R0a0KybUzNIlUDKuWxPgfoeqMw+IuCL/AFS09BOdlViMC9rnwxzmyYI5cvJCveRq0jxBELSnDvcSAx0Ov3rAHzUFXDVmWyP8WhxB/wC5qNL+EdfsxeJmbOzXtFzfovQuwVQmiRABa8iII2B08Fn8UWus8AnfMJcPMiUuB8R/DVc4JNN8B7dYjRwm8iT5J00vAnJjbT0eme0OlwjGOaQA4AwgafEqT2tIIgiQ4Hu+q6HGfqmqkn+yk5eu+htVoBLdpkdJUbWkkAaTCl/CufJJ+1vqo2U3C1hzP2SKT34GprXksmAAWKAq4xudrSbuO232Sx/EWMYQXCY0362VTw2HVPaO1iGzsnutalARj2nTL/8AAs/W/wDvf90k32x5hJMF6YE16a8XXCxcDeq0DJNnhHZmNPNo+S5iaga0ucYAEkofgj5pN6SPQ2+EIjG4cPY5h0cCPDkUmtrehsa2t+DI4vj7S5zQA5o0IkH0KqKuNdJLWC/M/YKTGcKfTcWuE8nASD1hVtWg/wDKP34XWNky5t/JHocOLBrcsnfj3/oNr2IcI5mJIHiFSVcbUe+SLGwF411HNHS9sf7jqihiiWnQjUk6jwtKhZOXTGPGp7Q1gyMA33UZr7qKtXkdEHWrdb7Dcpb7Y6Z0iTEYo85OgC0nBarmN6Rqee6znDcA57sx0vJ2aOU81cl5YMrtNR53TsSafIRmapcSwfiQ0QsHxLGF9R7hYEmOsWn4I/imOMZWm516DkqmnSlHd8ugIjj2ScPafaNJvdaGoC4AlVGFp5TmE2MrSUaAflaDcmB57qEutBN67ZDgeBurHk3cxPkButHwfs3TZcj4y4xzO3gFaYHDtpMaxug1J1J1lPLokttzj5qxMRPbXZQyZrttJ6RKaDBYMZ/aEmNaHAZWwZuAAoKLy7U3Sq2c0B3eJ06blHz+0I4/TZJxDhlGq2KlNj+rmyR4HVeddsuyraQD8OHZfzNmQ3+cSZGtxfY816V7Q6IHiWFFRjmuJg6xYx0Pz6SpyJNeAsN1L89HkPDK76MkOIk3bMtMcwttwvtS1wGcFp3A7w8Zss/2i4V7J+Zg7jusgO5X2IuPNVuEYTeNDZU26lmlxm0ehVu0zNGtJ+A/yqjH8Ye/3Rl6zc+mipqZ6ItjQbFS8jpdkThmX0jN9pcS9rYB943O5EE6+S03ZnOKLA8kuIB5wDcN8gQFT4zgJqP77iGi/UjXytutRhKeVoA0iBClP4pLyc18myw9v0cuqDMefy+ySndAaQWx0pxQzHW0hdzLYPOmj7NVffZyh3rb6BXkLHcIxGSsw7O7p89PjC2YQV5CQBxDCB40WK4rw0hxBc8A8jZehEKt4jhA4aJOTGqXZZw5qx10ebnCAG5J8Sfum+ybe2vUrQY/h5GgsqerTIVGsKT8Gtj9Q6Xkq8SwBs3mf2UEwkHNHmbq0xNOQgxQMSqty0+i9iuXPYVgeIvaMuVpB2uPqrF9Zjz32OB8Tp0VMynMRBJtG87ALV8N7M1i0F5a0fpu4x8l0LJXU9g5qxR3TSAKfAsO+TmcDv3voUJW7OhpMPteARfodVr2dlgAYqHNzi3pKifwGoJhzXT4jZOeLKl4Kk+oxN9UYk0CyQ4X0n8p81Z9maDnvJJ7jIjnm2H76I/F8KqhpzUyRvaQVa8I4P7FgbmkTm6yevIC3kuibb1onLkx8dphbXE2LrKRtQCU80RshMU3KCY9FYc1PZSVTXRBicaKdydVHhOIMe/NnBMQLhY3i9dznQC7XfkdlXhhBkvIPQx8lU9x72aC9PPH+nqhxQXGVcxiCRvyI5LFcI4xGVj3TeATqSTYE+eq2dFxyqzjuqZTy4lHRBx/BsrUnMIEkWO4OxHgV5jw2r3iw63PmLEL1PEvlpn92Xl3EOGOZUc9s++5wI2lxPyK7NpvYz021LRaewjRFULXi/VCYCsHjWCNR9uiPFImwSNfZa3+yTNJndTUHkkNsQd+SF9iW63U1EwQdANSuTeyGloP/Cnmkof4kz9YSTfiJ1QQGpNYucintctc88cdOq23DcRnY13MX8d/isg53NW3ZvEwTT/7h9UNLolGhITXtlSBIhAGVWKws7KixnDxey1z2KuxOHQ1KpDItyzC4vCRKq2tN27zp9Ftcdg5CD4Lwhpqmq4e5GUbZibOjpHxVPJhbekaeL1CU7ZJwDgIpxUqgF5u1p0b1PN3yWoDgq3F1gCHdITaOLGkqZuYfFCMk3l+TLKnWkkQRHPQ+CkJVa/FQR4Jz8Xa1zy+6asq12xTwvfSJWYgFzhMwmOkSdkL+HIl03OsWA8I+qDxj3tMtdPQ780p5XK20NWJU9Jlm6oCNUPXYSDAWbxvGDReHwXMcDLbaiLtnoV2n27w8d5r2+Qg+HVSss10wngue0tmX43ictV4IiDHlAuq+jmqZsg93UkwJ2Cuu0mTFva+m0sJ1O7mxaW8+vwT8DwwMAG2kc7alVHK312aU2+K30ZvDufnbmaZDmwDuZ06r05lZ7W6SBrGoWbGCBrsy7GTysNfFaSliA0EHfzTIXH70IyvlrS2MxOLlkM1PkFV0miS1xDgLEjn48k7G1iXSN+mnlyQGBvnM6EmNze9l3PddhTj1IPxHhZa7Mz3TuLQlwjAY5+YtFNwBOUvJaSJ/lGg0kj1WhwwzMvcG0H4LT8Mw4YwNtIA/wBJs4lT2IyZnC19mNr4fEgXosc7+V+YePea1U2LdWJio1zQNogf5Xowc0OIcIM+qkpNZnMbtg+R/wAlLeLb1sJep0ttHlmTwSXrnsGfpb6NSU/5f6D/AL/+pkhHmuuMaJjmGeq65h3WsYYnulOw9dzHteD7pn7hRubZRviVxx6JhqwewOaZBEhTLI9k+JQfZONjdnju36+q1wKW1pho4Qo3slSpEKDirr0EDVZl00Jv5aBXlVtlUcQY60ERBkHeYi/l8UrL+LLGGvkkCPcHabKtxT8hnRPfVdmyjXXouVKcnvwW7ws6vn4RpyuPkpavEX5pBtsFoOFlzmBxBv8Auylw/Z+jOaHOGsOMj4BW7aLQIAAHRMxempPbYGb1UNKZRXguykZY8TdRikHNk68uSOqULWKrsSS1pO418k1zx/IVFcvxMp2jpRkH9X0WGxHCX1MQ1rbNcMzjygw7zNo8VquI4t1R5cfd/KOnPxKJ4RQ96TcRr1uqyvVbRoOdwk2T0cOGRb1RQM+KbiXzlFrckmOART0wK20MaC10kXO/ip31CFFWqAiZ0N+iZVqA6KLfZMLaEHx81V4GsA6c3vSfqpsfVyMcdyIHibKnwlhCU2OlGm4PjHGu1hMMcCYgatE2/ey2lOuI1Xlv4rI9j/0u+BBBW2wWJBAvYiVYw5GloqeqwptMs8a+WoRuKyFpPK6gr8QbLmgglsSBqJ0Q3tcw+iXmv5bXk7Fj+On4Lv8AiTElQ35pIPfsL/PBM73v3ySekkt488Qu3Q9TXzSSXHD8D/zM/wD0b/5BelM0XUkuvISEkkkoJIqirMdokkl5PxY3D+aKql7z/L6JuN9xJJUl+JqP8ix4V/xM8EWkkrkfijPv8jjtFTcU91/gfkkklZfA70/k88f7qs8PofBvyXUlQnya1eAhn1KZU1SSTGLHv/4vMf8AmEMzQ+J+ZXUkN+Q48FbxjRnj9ChKe6SSWxqIqurf6h8itM78n9KSSKAMv0U/Cvfqfv8AMtJh/dCSSGvJH0EJJJISD//Z",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ12pvI-jykyyr5Pw3CfbQ6c9dLLdcgp0twmzWsqEfHVcv1bbLOW5Lknx1l9wVV_LbVGC8&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLMttzhPXA9jCrr5lwLmqimThRmMiEF138yA&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkQtWWcR3Hqr6u9y22m9SaonK342c0g4l5nbNlWHiFgwxX4WYSvhFcmF_WRHHY2gTiIs8&usqp=CAU",
        };
        return urls;

    }
    public static String[] getMeatnames(){
        String[] names = new String[]{
                "Chicken",
                "Mutton",
                "Prawns",
                "Fish",
                "Pork",
                "Rabbit",



        };
        return names;
    }
    public static String[] getMeatdescriptions(){
        String[] desc = new String[]{
                "20% off",
                "40% off",
                "24% off",
                "24% off",
                "20% off",
                "40% off",



        };
        return desc;
    }

    public static String[] getMeatprice(){
        String[] price = new String[]{
                "250",
                "800",
                "400",
                "250",
                "200",
                "350",

        };
        return price;



    }



    public static String[] getWatchesUrls() {
        String[] urls = new String[]{
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Electronics+and+gadgets.png/e14.png",
                "https://assets.mspimages.in/c/tr:w-375,h-300,c-at_max/603468-94-1.jpg",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBIVFRgSFRUZFRUVGhgYGhoaGBIYGBoYGBgZHBoYGBgeIS4lHCErHxkYJzomKy8xNTU1HSQ7QDszPy40NTEBDAwMEA8QHhISHzssJCs+PzU/Pzs2Oj84NDExND06Pz80PTE/P0A0ND04PTQ+PzY2PzY/MTE2NDE9NTo/NjQ9Pf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABAIDBQYHCAH/xABHEAACAQIDBAYGBwUGBQUAAAABAgADEQQSIQUGMUEiUWFxgaEHEzJSkbEUQmJygpLBI6Ky0fAVM0NTk+FUc4PC8RdEY8PS/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAECAwQF/8QAKREBAQACAQEGBQUAAAAAAAAAAAECEQMSBBMhMVGBIjJB4fBhcaHB0f/aAAwDAQACEQMRAD8A7NERAREQEREBESkm2p0AgVRNJ3j39o0LpSs7Dix9gd3veQ75zXbG/FasTmd2Hu5iqfkWwPiDA7nidqYen/eVqdP77ovzMx7b3bNGhxlD/Vp/znARtimeNJfAAS4jUKvs9BuowO8jfDZp/wDeUP8AVT+cvpvLgDwxdA/9Wl/OedsRhCpljJA9NU9qYdvZr027qlM/IyUjg8CD3EGeW/VjqlaXX2SV7iR8oHqSJ5qw22sYnsYmuvYKtW35b2mdwHpD2nT41VrDqqIh/eTKfOB3iJzjY/pTovZcTSaiffS7p3lbZh4BpvuBx1KsgqUnWoh4MpBHdpwPZAlREQEREBERAREQEREBERAREQEREC3UcKCxIAAJJOgAHEkzkm/W/JfNSosVpDQkaFz19i9n9Cf6S967ZsJTbor/AHhH1m9wdg59vdOPYiuXa5gVYnFs5uTI94iAvKg0piBmcBjw/wCzfjyb9DPuJw5UzDC/K99LW1N+QA65uWM2ViKASniUyO6B1F79E6WPUw5jlcQNdV5dXWfcVh7SNTc3tAlZIyTJYTDU8uerVCKOJ/3POUvtHZ6+z66p3BVHnYwMfkk7ZO08Rhn9ZQqMjc7eyw6nU6MO+P7WwnLDv4uB8p9GPwx/wXHc4Pzgdb3T38pYnLSrAUa50GvQc/YJ4H7J8CZus84g4dv8xO8K38M6HuZvc62oV39dTFgtTX1idQqA6le3iO0cA6XEpBvrKoCIiAiIgIiICIiAiIgJr++G3BhMOXB/aP0E+8Rq3cBr8JsE4Z6UNveuxDU1PRpXReq4PTbxOncIGk7TxZdyb31PieZMhWn2IHyJ9iB8tFpVM1unsJsbikwwuFJzVGH1aa2zm/InRR2sIG8eiTdAMRtKuugJ9QpGhI0NY9xuF8T1Gbv6QNj/AEjCl0F6uHvUTrIA6aeKjh1qJsuHoKiLTRQqoAqqNAFAsAPCXoHnrD4A1k9Zeycveb+Q7ePzmAxaZHI5Cb5s/BlcVW2eCFKGsylgWBRGGVbXGpRr37DNQ3golXYEWZSQRx1Hb1cD4wNb2jiS7Zb9FNAO3mfjFI6SzjEyu4+0T4HUeRleHOkCahkqmZEQyTTMCdSMyOEcqwYGxHAzGUjJ1AwO7brY/wBdhqb/AFgMrdhX/a0zM0L0aYu6vSJ6nHhofmvwm+wEREBERAREQEREBERAxO8u0vo+Gq1r2KqQv326K+ZHwnmfH4jO5JN52L0ybUy0qeHB9ss7dy9FfMt8JxF1PE89R3dcAakp9YZWiAdsvq5ECMHPUZUGPUfhJQrt1y4uKfrgRUa87h6Hth+qwrYph08Sej1ikhIX4nM3aCs429fOLMAe2wBHcZ6X3frU3w1B6Qy02pUyi+6uUWXw4eEDJREQOUb5r9H2xhsTwWtkDHvvSa/4Spmub/4PJXf7QDeINj81m6emTAlsNSrr7VKplv1CoOP5kX4zBb5EV8Ph8WOFSmjH8aDT81oHJ9ppqrdagHvXo/w5fjJeAogKLqjXF7lyD8LaSjaKdD7r+TCx81Er2bTBUHNRUgkdMdLvOusi3S2GFyuonpRX3E/O38pO2Rs9Khq5lb9nkICOg9twpSxUlrqWOYezl4G4BirTT38N/XjIldRnNijDTVPZ4DhEsq2XFnjN5Nrw+xKLGogqkFKr0wxakRlDoqLkuCzuHcgggXQg24iNisMKbhFJYFEa5Cg3ZASLAngxI8JhKUnUTJZt13FxmTELc6Mcp/Fp+s69OCbLqlXVgbWIndMJWDotQfWUH4i9oF+IiAiIgIiICIiAiJZxNdURqjGwRWYnsUXPygcN9J+LFfaDU73SmAp7kXMw/MSJodZ8zE9ZmTxmPNWriMQeLk/F3Lf9sxKwPon2J9gJ9gCfQIH0T0puTQKYDCo2jCjTJHUSoa3nPOeAwhq1EojjUdE/OwX9Z6lpoFAUaBQAO4CwgXIiIGB31wPr8DiKdrnIWX7ydIeazm2yG9fskpxeg7p550/iA8J2R1BBB1BFj3Gce3Mperr4/AN9UllH/LdkY/Bkgc8x1O5ZR9ZWt3jpjzUfGWt3sSFzKaq0xowzUzUueGluHKZHa1LI/D2GI8FbTytMXsOqaWJCio1MEshKoHa31QFIOa5C8pTknwVtwZ9PJK2VMQP+JXwwr/zkans9sTi0oJUUtUt02Q0wLAk2Q6k2GgHGZ1K7/wCfjD3YQD/65r+8DutZamasWCqQ1VBTcFWJGUBRoDre3GcfFllbqeF16faOvtOW8ff1+7eN6d2cLhsDmppd0ZAahJLtmaxJ5a34ASvd7+yRRoo6h6tYhGzKWcOSAb29hbkWI43v1yNh6r1diVGdiz52ZmJuSfpIcknxlj0e7HzucU+lOgejfgXAvfuUa99plN91l15Xct93Jfmmp5xb25s0YbENTUkoQHS+pCtfQnnYgjwnT9zcVnwyjmhK/r+vlOW7w7QNfENVysqaLTzKVJROevWST4zdPRxi/bp9YDD8Jt/3eU9Di30Tfnpllrfg36IiaIIiICIiAiIgJoHpd279HwfqFNqmJOTtFMaufkPEzf55v9JW2Tisc5BulL9mnVZTqfE3MDW6T/sj9p/ko/mZ8USzTbohftH5CSFEABPoEqCyoLAoAlQErCyoLA2H0eYbPtHCryDs/wCRHceaieiZ5k2NizRrJVVsjoboeWccAew6g989EbC2ouJorXXTNoy81YaMp7j8RY84GTiIgJyfbCfR9vI/BMSoB/GhT+NFM6xOY+mGiUOFxi8aTkeIIdPNGgaVvvhMldxbjZviLH+EfGaTiqhSolRSQwCMCNCGQ2uD13W86r6RaAZkqr7LqbdzAOPITlm0U6Kn3WK+DC481b4xrY6RRLMAQNqsCAQb0FBB4EWImu720mV6ZZcSuZWA+ksrMbEexZjYa6jtEzG7NFquGputDGVrDKSuLCJdTayqagIGg0tIG+GCZPVM2Hq0LswvVxArlvZNgMzZbeF/CeZwZdPP0+Hp9P8Af6dXJd4bS9l7VqpgamB+i1WNQuQ+VwFzZbdHLrYrfjMpunvTVpUVw1PDGqUzksHK+27NqMptxtx5SRtTFYlLGjSFRbEtdtR1WW9258Ji9z8RdK1NCFqkl1uNNVsNOYDfOejl2Tivw2ed37vPnaMrN+iRvJtypiWRXo+paln0LEk58vWB7vnMjuTi8mITXRjl/Np+sg7z2y0c9vW2Oa3VYX8M17eMg7LrFXVgbWIkzjnHOmeUaY53OdVd4iWMNWDorjg6hviLy/JWIiICIiAiIgR8aSKblfaCNbvym08qYg9Nr+8b/Ges5599JO6r4XENVRf2NQlkI4DmU7x8rdtg1DaFCmlRVQ5g1OkxN79N6YLjss1xbslSLLSoG15iXg5H1TAuBZ9Cyhan2T8DK1c+63wgVhZUFnxS/uHylxadQ8gO8wIuNp3W/u6+YH6zpXoi2w61Po7Ho1g1r++i5gfFAwP3VmgLs/Mbu17chNy9H2FL46iqDo0Q9Rz1DIyDXrLOvnA7dERATUvSbgvW7Pq2FzTKVB+FgG/dLTbZF2lhRVpVKR4VEdD+JSP1gclxL+v2Vh6vE01CMef7Fih+Kr5zm20Kejr1DN4qQflmnR9ygXwWKwr+1SqE26g6WI/MjfGaHjafTAP1ui3iMrfMwMnuJSFWnUp/RWxDIytpinw6qrCwBUEA6gm9uclb44DJTpt9Fp4a75cy4hq7G6sbMCvRGl735TVt1gprhXopXzKVC1HKKCLNmzWOoCkW7ZsG8mHQUQRQwtGzrrSqF6hFmGUjKOjrr3CcvcXvuv6fn66/hN5J8rNbFO0RWVa2tIAgn9nY2HRKlekTe3nJuygi18UiZQ5Kst+1L/AOde+adh958WqhA40FgSilrd8j4fFVA/rA7B7k5rnNc8dZ6HXJrTl7nK73qfs3na1JzhUesAKyEai2t2ty01Fjp1TCYZ9ZDq7Qq1bZ3Z7cAbW77DS8v0GmeWUt8G2GNxmq7Xujis+GTrW6n5jyImcmj+jjFXR6fVZh8j81m8Sq5ERAREQEREBMftbZlLE0mo1VurfFTyZTyI/rSZCIHmjezdypg8Q9O4bLZrjgVb2Wty7uRB48ZiaNS/fN+9NBanjaVVfrUgCORAdgQZoGIVbConsty5qeYMC+JcWWqLXF5fUQKkl9JQgl1VgfS9gSeU7H6Ntg/R8MKri1bE2d78VT/DTwU3I62M5VsnBCtiKFE+zUqordq5gWH5QZ6GAgfYiICIiByTZFP1G18bheC1ldx33Woo/K7zR958NkqOvU7efS/Uzf99h6jbGDxPBauRG72ZqTX7lqL8JrnpBwmWux95b/AJTY/wAQ+EDnrMFrhioYZlfK3skNZiG7NZsm26QWi3QwakFdKTXqnpDQaDTr7LzWdor7DdalfFSf0ZZIp7Wb1XqPV0rEWzhAKlgQR0hbXTjbWWlkllUyxtssbPs/dmmxX9o7qfo7Zkp6FK6DUA3bouQDpw10vpf2RsrDPTfOzCrSNQP0gMuUmzW6rDrIvfsmp08TUsBnewtYZmsLCwsL8gT8Zfotbhpy8OqUs234s8cbvKbifRaT6LTGUjJ9FpLNvXo/xWTEKt9HBU+I08ws6tOF7CxWSqlT3WB+BvO5Kbi45wKoiICIiAiIgIiIHIfTrhtMNV/5iH90j5mckwtSxKH2X08eRnefTLg8+AzjjSqK3gQVPmVnAGPSHhAn4J9bTJoJi6S2qEdsy6iBWgl1RKUQ90uimew+UCVsut6utRq/5dWm5+6HGbyvPQs85rY/L/adb3B3hFekMPUb9vSWwvxdBoG7SNAfA84G4xEQEREDnPplwpOHo119qlUtfqzLcfvIswm/ZWqtKquuemKn4XCkX7zf8p6pvu/2F9ZgK4tfIoqf6bBj5AznZpq2GXKLDKANSeAsBr1DS0DmuKollZR7SnMO33gO8WP4Zi1Mz+JQo/AjXqIlT7FFbpIQrniD7JPXp7J8oGMpmSqZkld28YP8Et2qyEebAy8mwMZ/w7/mp/8A6gUUmkyk0rp7BxXOmF+89MfImX02Yy+3VpJ3MXPw0gX8NUsb9U7rsSqXw9JjxyKD3qLHzE4OmJw1I5s7VWGo0AUHrA/nedj3CxL1MFTqsuXOXKjicgYqpJ7bX8YGyxEQEREBERAREQMJvhgfX4LEUrXLU2I716Q8xPMOGo5qir1G57l1PkDPW5F9DPNW8OyjhMRiVItZylP7rHMW/Lk+JgYrCDM5btMyiiRMBTstzLzYpF53gT6ZvL4mFbaSDlLZ2uOQEDNDiT1n9AJIw2Iem61EYo6HMrDiD/VwRzBImtnbLf0BKf7Zfr8hA9B7p7z08WmRrLXQdNOTD30617OIPgTs08ybN3iZHVwSjoQVddCp67cx1jmLid73R3hTGUc+gqJYVAOFyNGX7LWNu4jlA2CIiBHxtEPTdG9l0ZT3MpB+c85ZyUW5J0HMz0m3AzzUx6I7hAxmLOsjpUYcCZcxLXMtKIEtMdVHB2HcTLh2hWPF2+JkQSoQLrYhzxYnxlJYniZSJ9ECpEZiFUXZiFUdbE2A+JE9ObJwS0KFKgvClTRB+FQP0nCfR1sz1+Pogi60iazdyez++afnPQcBERAREQEREBERATz16Ucb6zH1ByQhPygA+YnoWebfSJRZNoYi/N2bwY5h5EQMJi65ACDqkEqTzknFU2yiqASnRVjbRWIOUE8r5Wt3SvDoGgRlQdUv0sObGyEk87Gw8pNTDCUYmlU+rdh36jwgRGwRXiLd5E+fQr8pV9DrOdVIHbYfrMps/Cui2e176DjYdV4ELG0s6KRTC1E0Zk6IdbaF04Zx7wtmHEX1O1eizbLUcUiE9FyKbDsc2X4Pk+J65jxTEq2VhbYmiUGr1aI06/WprA9HREQIu0awSlUqHgiO35VJ/Seb8SbKB2Cd634xXq8DXPvJ6sf9QhD5MZ5+2i/KBjmNzKlEpUS4BACfYn2AlQlMk4HCVK1RKKC71GVF72NrnsHE9gMDrHob2Tlo1MWw1rNkT7lMm5HexI/BOlyDsnZ6YejTw6ezSVVHWbDUntJuT3ydAREQEREBERAREQE5H6YdgEsmLUaMAj9jqOiT3rp+HtnXJEx+CStTalUGZHFiPkQeRBsQeyB5f2ftNqOYFRUR1KVKbXyuhtdTbVSCAysNVZQew2KDgWZb5SSNbXHfbS9rTb999xcRhmaoqGpR4h1BNh9sD2D28O3kNNwZFypPRfS/UeRgZuk1xLqzG4ZypKNxEnq8C1iNoKhy5SxHHkJH/tZybBB8SZfr4dX1Oh6xbznyhg1UnUkkW5eWkCTg8UHBNrEaEf7yUtQghlJVlIII0IINwQesGQ6NJEBCjLfjc6n4y76yB3Lc/eBcZQDGwrJZaqj3uTge63EeI5TYZ5+3f24+ErrXXUey6XsHQ8V7+YPIjvndNmbQp4iklek2ZHFwfmCORBuCOREDSvSvtDLTpYcHV2NRvuoLC/eW/dnFsU+ZjNv3+2yK+IqVAbqOgn3EuLjvYs3jNLED6olU+CfYH2J8i8D7Oo+h/d4lm2g46IzU6N+Z4PUHd7A73mi7rbBqY7ELh0uq+1Ue392l9T1ZjwA6+wGejMFg6dGmtGmoVEUKoHIAWECTERAREQEREBERAREQEREBMTi93cDVOaphaDt7zUqTN8St5logcM9Jm6X0aqMRRS1F+AA0RhxS3Icx2XHKabRr3E9MbSwFPEU2o1BmRxY9Y6iDyIOoM8/72bs1cHWKEXU3KMB0XX3h1HrHI9liQxnrJHxLOeDHL1A2/wDMtesg1IFr1DE68Ock4YFL69HkJQte3IE9t/lPjYp+Vh3BRAmeumb3f2/iaCVadNrU6qkODfoki2dPda2l/wCQtrOGoVHa2uvMg2Ak3GVlRfVp+IwI2Nr5204DQSwJTeLwKrxeUZoLQK7ybsfZdfFVVoUEzu3gqrzd2+qo6/AXJAmW3W3KxeNIZVNKhzquCFI/+NeLnu07Z3DdrdvDYGl6qiupsXdrF3brY/IDQcoFO6e7dHA0BSTpO1jUe1i7249gHADl3kk56IgIiICIiAiIgIiICIiAiIgIiICYzbWx6OKpmlVW44qw0ZW5Mp5H585k4gcE3q3Lq4ZiWGanfo1VBy9gcfUPfp1EzU6mzKg9npDsnqRkBBBFwdCDrcTVtqbg4GsSyq1BjzpEKv5CCo8AIHn8bPq+4flJWG2WwOZ2y26jr8eAnWa3ouuehjCB9qirH4hx8pR/6So395jarfcSmnzzQOW4nHKoyJqebf7zFM153PDeibZq+2a1T71QL/AqzNYTcPZdO2XCU2I5uGqH98mB5zpgs2VQWb3VBZvBRrM/s7cnadexTCuqn61QCkPg5B+AnovDYSnTGWmiovUqqo+AEkQOMbL9D+IaxxGIp0xzWmrO3dmbKB8DN32L6O9m4Yh/VGu4t0qxFTUcwtgoPaBebhECkdUqiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiB//2Q==",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWEhUVFhUYEhgYGBoYFRwYGBgYEhkaGRgZGRoWGBgcIS4lHB8rIRwYJjgmKy8xNTo1GiQ7QDs0Py40NjEBDAwMEA8QHhISHjQrJCs0NDQ0NDQ0NDQ0NDE0NDQ0NDQ0NDQ0NDQ0NDQ0NDE0NDQ0NDQ0NDQ0MTQ0NDU0MTQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcBAgj/xABEEAACAQIDBAYGBQoGAwEAAAABAgADEQQSIQUxQVEGEyJhcZEHMnKBobFCUnOzwSQzNGKCkqKy0fAUI2N0wuEVo/Hi/8QAGAEBAQEBAQAAAAAAAAAAAAAAAAIBAwX/xAAkEQEBAAICAgIBBQEAAAAAAAAAAQIRITEDEkFRcRMiYbHwBP/aAAwDAQACEQMRAD8A7NERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERA8iJXdsdJ0pEpTHXVOIB7C+034D4TLdNkt6WEmRmK29h00aqpPJe0f4ZR8XjK1c3q1Dl+qnZQe7jMaUEG5R+PnJuTpPH9rcemOG5sf2f+5modKMO+gYjxsPxlQAHKY3oId6j3aGPaq/TjotLH023OPfp85tAzlyF6eqMWH1W/CTGzdrZh2WKNxF7fDjNmSL49LzPZW6O3HHrAN8D5jT4SRo7ZptvuviLjzE3cTcbEnEx0qqsLqQw7jeZJqSIiAiIgIiICIiAiIgIiICIiAiIgeRI/bO1qWGotWrNlVfMngAOJnNMd0wr4oG3+RTcdhAe2UP03biW4AaW11uLZbpWONqwdIuk5dmo0Gso0eoN55qh5d/9mCooFFh/fjNKgQAJnR5zt27ySTUbgMyKZrI8yo0NZhPoCfCmbOGoM7AKCSdwH97oYxZZF7eqnD0/8QFa2YKCAQpc7hm3cD5ToWz9gqtmezty+gPd9L3+UgfSxgqlTAItPQLXplxcAZMrqL9wYofdLmKL5PpTtm9NEcA1itPWxsjjLfcd7Bhv17O46S008SCLhgw7jeVTolsDBIesxLrVJOVUP5sld7OPpAXsAdDrcS+bZ6WYXCUlvlII7CJYKBuF7eqOAABJsbA2NlkZMrJy1qWJKm6kqeYNjJnBbd3CpqPrDePEcfdOW4n0kUXc/kzIOauCfIqJs4Xplh33Pl7nXKfMXEzmN3jk7NTqBgCCCDuI3T7nPNj9KVU3BzKfWAIZfEEbj7pecBjqdZA9Ng6928HkRwMqXbnZptxETUkREBERAREQEREBERA8nhNtTpPitVCKzMbBQSTyAFyZy/b/AEhxNWjXSm+QuGCg2AKNcFMx9U23N7ja95lulY42q10v26cfjWFycNQvYA2DAG3m7WHs35TzDtcljvOp5eA5CVzBt1YCMCrXzVAdGDEdlSOFl+LGTC4oAWkV1x6SwqzKlWRKYkTOlaYtLpUmdKkiErTaw75jaBOYCg1R1VRcndy7ye6X3ZmzlorYasfWbiT+A7pqdHNl9TTDMO2wu3NRwX+vf4SalyOGeW+I9nH/AEx7Wdq9LCoSEVOse3F3JVQfZVSf252CcE9INTPtPEnkyKPBaaD53lIQTkplUnXIp/eAb8ZAbVxReobk2WwA4btTLB0i0rkfqU/u0MqeIa7t7R+cmLyvGnmefQeYxPZSGzRxTIbqxU9xtJjA9J69NgwckjcblX/fXWV6LzNNlsdY2J6VaqkCpaovEPo3uqKNPFgZ1Po90ho4ynnpNqLZlNs633XtoQeBFxv4ggflUPLD0M25Uw2MpPTa12CMpPYdW0KN46a8CAeEG9v1HEw4euHRWG5gCL79eB75mmsIiICIiAiIgIiIFZ6bY7JhwgOtQ2/ZWxPxyj3mcx2nXyoe+XLpu7nEC6sEVQFJByEnUkHdxt7pznbVa7hRIy5rvhNYtcUw4GbUjcb6juHKY3wX1XI8dZnpiwmUGY3SPNCou6zeGkDFOu9SPdJJZlURs0jae0++dD9HuA66p1jC6JZu4ufVX3an3DnKc2CRt6Ay/ejWg6Goqt/leswbU5zYLY8NAZs1tmW5jXQ4iJbgT899LGzY/Fn/AFnHkxX8J+hJ+eOkRvjMUf8AXq/eNAjulB/KL86VE+dJJU63rt7TfMy2dKfz6fYUPuklSq+s3tH5mTFZN/AY8IhRqa1ULBrEkWYCw4EW93vmfaD0DQp5KbJUzHMfoFe0cvrG5F01IufhI7CVArgsLqdGHGx3kd43jwm9TogO1JyAG9Vvoht6v7JuL/qtfhFulY47iMIn1TQsQqgsSQFAFySTYADnMtSmVJVgQVJBB4EGxHneeUXKMrqbMrBlI1IYEFdDpvF5u03FjrUmQ5WUobA2YEGxFwbHuInyGIIINiNR4jUSzPth0q0jWVKxpkllAykZ0yEX1UNrnNhYN3kyP6SY2hXxTVMPR/w1NglkAUBWCgMQF0sTczdsssuq/SPQ/FZ8Kh7gfcwB+d5PSlejKtmwdPvpUz5Lr8xLrDCIiAiIgIiICIiBUPSdjzS2ZWIJVnKU1IJBGZgTYjcbAzia4p7JmtUYpmYsO0cxJW7CxPZy8Z0n04YojD4akN7u729hQB8WnNKwAqOBuU5B4IAn/GTXTHputVta6+R/A/1n0ldedvEH8LzFW4TFM06bSSa7iG8CD8pmQSItMi4l13MffqPI6TNG09QSdc6L4HqsMgtZmGdvFtw9wsJR+hGw1xKM1XMMuSxWy3JuSDpbcBw4zp4ErGfKPJl8PqIiU5E/O+3P0vE/b1fvHn6In5323+lYn7er940CP6U/nqffhsOf/WsqVX1m9o/My3dKfztL/a4f7sSo1fWb2j8zMiq28JgHdc62IBsbkjW19+6SdHBu9JlZCHprdTvzIDqLjTs3PipP1dd/oczCm+UA9o37RViMhuB2SLaanQjs6i8sdDEIlRHZDb1iQEseybAOl7gnLvvcObkixmZRXjurz0p9fBGrR65FJen2ayjUlRotS3G3qtbkDxvLBgatelsjEJUPZptQeghQK6FqzXcm1ySx0vf1bjSSS4JqWPL0gclQC2lz2lGW4O/kQeNpq0wa1HaLVGyK3+HcFrAkJVZiVB36EWHeOciZfD0M/wDn4953x+PyV9n4QYj/AMcaCrUFqKYku/WPiioJzLe3VFzky8Lgg3nOHBBIYWIJBB3gg6idFxuCrYja+FxFNWajWqUcRTYDsImZXrZ2GgZHV8wJvoOYlD2rXV8RXdPVerUdfZZ2I+BnSPOzsvX+rvnosP5LQ+wHwyS/znnonP5LR+xPzSdDmoIiICIiAiIgIiIHIPS62faGBp8lDHwaoM38KGc/3ljzZj5ky9+kFs22qY+pQB+FT8WEpZTf7TfzGRe3bGcPUa4tynyTPBPq14a+C8+sMudwOG8wKF+M3MKgXQQOy9AKGXBhvruze4WX/jLPIbokLYGh3pfzJP4yZlTpxvdexETWE/PG2/0rE/b1fvGn6Hn5427+l4n7er940CP6VfnaX+1w/wB2JUa3rt7R+Zlu6VfnaX+1w/3YlRr+u/tN8zJiqkdlbWeiMq3sWzGzEa2tcjcbS1bG28KnWq7FEYIat0UlsjmooTKNGLFtbbie6UfDUszBd1954AcWPcBJGtWXKtNAQovc7mYk+s361tANbRa6eKTu9f3VzwW3HqY3NTbsLYjLe2iiyAb8o3ec2quFxFXCYlmXsHRXzIGdlcZRlBzdpjY6AXI4XlYTazYRctPIKpHbNr9XrYIBz0u2/wBa3OS9DHh8HjsSoyOaeHzqulmXF0iHXua596tOcl7ejl55MPXfPG/x9RWWrY2hQKXxFGhWAYgiotCorgENr2WDAi/MGxkHOlbdfFtQavhcYtXDthaS16FOrmNNRh6aVb0CLKBxy9oXubTms6x5WU1Xf/RGfyWj9m38y/0nR5zT0Qn8lo+w3806XNSREQEREBERAREQOQdPa7rtKqtF8heii1rqGBWxAQ34W1/a7pSglsw32dgDzsbX8L3lg2xjc+JxuJ39twneKYyJ55B5ykvi6iW7ZPiAfnI7dpxOUmyzG7MNwU9xfK3u0I+MsfRjZKYnZuMxTsRVw/WFUXKEZUpCoC4Nz2iWFwR6vGRmydo0yiq9EnOQbhhcZrC2q7v+4u42WVpYeqWBupQg2INjwB3juIm3S3zXXFUmdznVCzbrMFAACKLkC9lVdeJudJJ4fC5hmQhwN5UggX3XPCZSOy9DKmbAYc/qW/dJX8JOTnPo0xtVqlSlmzUaaHTeFqFweyeVi1xzBnRpcu45ZTVexETUk/PXSRbYzFD/AF6v87T9Cz8/dLB+XYr7ap8WJgRnSwf51McsNhx/6llPxHrv7TfMy59LF/zk/wBvh/uUlMxXrt7RkxWTxGtN6jWCLmBGc3y8Sotq/ceXfc8BI4T2bZsxys5jMXubk3PfqffeTGxNpJSpYxGBbr6aIulwCtdHYnW4IVWI7wJA3nuaNEy5ldH2XQw2HqPiExdPqOqcth3c/wCLLvRZBTVQAHVi9w40ytuE5wVtod40MznEXQA710B/V35fcb28TyEwExG5WXp3n0QH8mo+y38xnTZzD0QH8mo+y3zadPmoIiICIiAiIgeSN6QY7qMLXq8Upsy+1Y5R52klKd6UqxXZrgG2apSU+AqByP4ZlbHJtonJhkTi5F+ZA1J8wP3pA4qnoD3SS2m4fqnDA+umX6S2yanua+nsGfDU7oJM4dryhqGLqU84R3ph1KOEdlDoQQUcA9oanQ85M7NXtUh+tTHxE8wmy0qtkLJTZmWzuSqgAPmW40FyU1I+jwkltelicJ1XW06RV79Q6kNmCZLsuW2gzLvG+Ld1kx1N1WalPjJfZm0+qwmIo2/P9Vc33Cm7Pu7yR5TWenpPpMGXCcs4V+4X1PlFJNV2X0U7P6vBlyLF2Hkov8GZx7peZHbAwnVYWilrEIC3tN2m+JMkZU6csru7exETWE4J01TLtHEj9e/7yqfxne5xP0r4U0sf1luzWRWB4FkARl8QAh/bECE6QUS7UW35sLQPkgH4Sj7SpEVWHeP5QZ0LA1RVo0zxRerPdlJyjyI85XelezyrrUA7LDK3cw5+I+UmXnTpZ+3aqiezM9KYyhlOb5i8ETyB7eIiB3j0P/o1H2W+bTqE5p6JKdsPR+zLeZ//AFOlwEREBERAREQPJWPSFs419n1VXVkK1B4IwLfw5pZ58kXFjrzhsun5mfCspa4IsAfJrH+YGbFEdkzsnSPofRfD1jTTI+RioGq3AvYA7t3Ccdww4cxI1Z27Sy9Ma0yTYC5ny6Zd4t8pnK2M1cTRqMCM+YEWsSfPXd7jA+mSTPRTD56qUzuepTB8C4B+EiaFIhQCbkCS/R6t1ddH+qyt+6wb8INO/T2fCsCARqDqJ9y3AiIgJVfSHs2jWwFZqot1SmpTYWzBwLAC/Br5SO/nYi1SleleqV2cQNz1aat4Alx/EqwOedFqFFWKs4VKgsG4JU+izD6vA+PdJTaOzipelVTxHAjgyniORnOsTiSjLbvvvHLl75OYPpPiURVYLXpgdlat2dAeCVFsyjdpu7pOUdMb8MGP6KsCTTYEcjofjIXEbIrJ61NvEC4lspdJaZ9enUpnuy1F8+yfgZuU9r0G3VkHt3Q/xgCZ7WNuMrnTU7bwR4i0+DTE6f1SOL2SoOYyuPMXmnW2LQbfTA8NDHsy+Nzk0RPaWFLMqjexAHvNpen6M0Tuzr4Nf5yW6NdBkesrZ3OU3Gi/0t53m+0T6VfegWDyJYCwRFTuu1jbxAVT+0Jc5p7PwS0qYRRYbzxJJ3knie+bkpJERAREQEREBERA8M4P0i2b1GMrU7WAfMnst2h853iUL0l7JzImIUap2X9k7j7j8xJvS8LzpzWpT1kvs7orXr0RWpAMt2Ui65gV4EXuP+xNMU7ibuy9pVsOxNFzTzesLBla266sCL9++S63+EGVK1XpOuV039826CWYHkZu47HdfVNV8mc2BIUKTYW3c4SlDY630XxfWYWmb3KjI3iug+Fj75MShdAsdlZqLHRhdfaX+o/ll9lzpwymq9iImpeSn+kmpfB9SLXqMN4volmuORvl1luY2FzpznMdv4//ABOKLLrTTspyNt7e8/C0nK6isMd1RcP0adyBVpoATq61WzBeQTLb5b5Yn2ZTtYLYDQSS6uOrkW2u8xmPSDqbFQzUq9HlO6WY04NONq1FNqdGje4GvMb/ADkXjMPXo1KYFWpZswCh31tYWAvrqROjBJbOj/R6kerr1aKmoutJmzEqN4bKTYG+42voJWPNc85JGbYPRelTw1JKyLVq5AarN2iXOrAHkCbDuEnsPhUQWRFQclAA+EzxL047r2IiGEREBERAREQEREBMGKw61KbI4urAqw7jM8QONbR2W2HrNSbhqh4Mp3ETB1E6j0i2IuIp20Drqjf8T3f3zvz16DIxp1FKsDbX8Jzs074Zbj3F4bCVaDKabUauXRls1MnnqQVufG3fI7AYNkpqrNnI467uA1kjUwuZSOfESOr7OxCC9KpnIPqtuI5a6QrSTwhZXVlNipBB7wbidN2bjFq0w68d45EbxOcYZGyqXGVrdoA3APjJvYuPNFuJRvWH/Id4/vhNxukZ47i8RNPEbRpJT6xnCqRcEnf3Abye4Sm7W27UxN6dIGnSOjMdHccv1R3f/JVunOY2snSjb5qk4egbpuquNx/UU8uZ4+G+Jw2Fyi028NgggsBM2SReXaSSajU6ueFJtmnPk05ittQpPk05uFJvbK2SarXOiA6nn3Dv+UaZbp70e2PnbOw7CnQH6RHDwHHy5y6T4p0woCgWAFgBuAn3OkmnDLLdexETUkREBERAREQEREBERAREQPJHbV2TTrrZ11HqkesP6jukjENl0oGM6N4ikSaZ61eHE/u7/K8i3L2KvSJ5/wB2nU5hq4dG9ZQ3iAZNxdJ5PtyRsIbgp19O3AOCvgQ6mSVNK7AADL3m2b+nwnQG2TSP0beBMxHYicGce8H8JnrW/qRTKOydczsXPedJvpTAFgJOvsPk/mt/kZgbYlT6yH3sPwMap7S/KKKzzLJT/wAPU5L+9PRsaofqj3n8BGqe0ROWAl9ALnhbfJ+jsIfSa/cot8T/AEklh8GieqoB57z5mb6sucQmA2IWs1Tsj6vE+PL5+EsFNAoAAAA0AG4T7ibJpzuVr2IiawiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgf/9k=",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMIfjVWBWm5JauF-OnojKTCMmtJySEUCrJqQ&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBJDGC76yEqoQxOtj3JstxaaxFyj0fNL2HMQ&usqp=CAU",
        };
        return urls;
    }
    public static String[] getWatchesnames(){
        String[] names = new String[]{
                "APPLE Watch SE GPS ",
                "Noice Smart Watch",
                "Fit Bit Smart Wath",
                "Boat Smart Wtch",
                "Samsung Smart Watch",
                "Fire Bolt Smart Watch",
        };
        return names;
    }
    public static String[] getWatchesdescriptions(){
        String[] desc = new String[]{
                "Fitness with call function",
                "10%off",
                "30%off",
                "20%off",
                "30%off",
                "20%off",
                "20%off",

        };
        return desc;
    }

    public static String[] getWatchesprice(){
        String[] price = new String[]{
                "30000",
                "3700",
                "2500",
                "4000",
                "9000",
                "2000",

        };
        return price;
    }

    public static String[] getMobileUrls() {
        String[] urls = new String[]{
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Electronics+and+gadgets.png/e3.png",
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Electronics+and+gadgets.png/e1.png",
                "https://cdn1.smartprix.com/rx-iHGs2RETC-w420-h420/oneplus-7-pro-5g.jpg",
                "https://static.digit.in/default/galaxy-s23-ultra-eda4f23a23.png?tr=w-1200",
                "https://cdn.webshopapp.com/shops/256009/files/426253210/xiaomi-xiaomi-poco-x5-pro-5g-6gb-128gb.jpg",
                "https://2.wlimg.com/product_images/bc-full/2021/9/9218847/oppo-mobile-phone-1630654077-5972376.jpeg",

        };
        return urls;
    }
    public static String[] getMobilenames(){
        String[] names = new String[]{
                "I Phone - 13 Pro Max",
                "Xiaomi 12 Pro",
                "One Plus 7 Pro",
                "Samsung S 23 Ultra",
                "POCO X5",
                "OPPO A9"
        };
        return names;
    }
    public static String[] getMobiledescriptions(){
        String[] desc = new String[]{
                "Blue, 128 GB",
                "Black,8GB RAM,128 ROM",
                "Matt Black,12GB RAM,256 GB ROM",
                "Green, 128 GB",
                "Black,8GB RAM,128 ROM",
                "Violet,4 GB,64 ROM"

        };
        return desc;
    }

    public static String[] getMobileprice(){
        String[] price = new String[]{
                "96000",
                "49000",
                "29000",
                "96000",
                "22000",
                "15000",

        };
        return price;
    }
    public static String[] getAirpodesUrls() {
        String[] urls = new String[]{
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFRUZGBgYFRQYGBgcFRocFRgYGBkcGhgZGBgcIy4mHB4tIRgZJjomKy8xNTU1GiQ7QDszPy40NTEBDAwMDw8QGhIRGj0rJCs1Pz8/PzNAMz47PTU0MTU0OzFAND1APTQ/NDc/MTo4NjEzQD80NzQ3NDcxOj8/NTQxPP/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABAIDBQYHAQj/xABGEAACAQICBgYHBAYJBQEAAAABAgADEQQhBRIxQVFhBgcicYGREzJCUqGx0RRTksEjYnKTsvAVFkRUgqLC0uEzQ5Sj8SX/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAgH/xAAXEQEBAQEAAAAAAAAAAAAAAAAAAREh/9oADAMBAAIRAxEAPwDs0REBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERARE0PrT6SnDYf0dNrVKwIuNqpsJHfs8DAi9Mes6nhi1HDKK1VbhmJ/RIeGWbHkLDnND6Q9IdKAoauLZBUXWVaRCKAQDYFQCRmMyTNMTM3MmgXtvsAByA3DlJsuzK3jL4PpnpGkbri6jcnIcf5wZ0Xor1mirZcSgU73QGw5smZtzW/cJycLPVUoQ6ZFc+/iJTH09Rqq6hkYMrAEEG4IO8ES7OadBNNWCEH9FUNmX3HPtDgL7fPdn0uAiIgIiICIiAiIgIiICIiAiJrXSzpjh8Cv6RtaoRdaantHmeAgbLE4NpHrcxbsfQ6lNb5WQMfHWvnJWiOt7EqQMRSp1V4rem4/iU91hA7fE1TQHTzB4ohVc06jWASoApJOwK1yrHkDflNrgIiICJi9OaXp4Wi1aochkANrMdijnl5AmcD6V9NcRi3ILlad8qakhAOY9o8z8NkD6Br6Xw6eviKS/tVUHzM4R1oaSFfGMysHRQqIVYFdVRmQRkQW1j4zT0LDMEy4ULQLdMyaHspPAXkajSN7TJJhbrY7xAt0CWvcWItlfjwmVxGjmSmjkgiooZbfLvGw8DItKiFBvmTax2W8N+Uv06cmy7MrZjN9X9bOpSOwNceM7dgautTUnaVF+8ZH4zhHQo6tV23E2nctEf9FOag+eY+cpidERAREQEREBERAREQEREDWunPSZcDhmq5Gox1KSe853nkBcnunzXj8Y9Z3q1WLu5JZicyTw4DlN766NKGpjhRB7FCmotu137THy1B4Tn6ISbAEngASfIQMjpnTD4k0i6U09FQSiuomoGVb2L5m7Z8hwAlnDYclSfHylWHwBZrMwAABNszY2HIbTbbuM2Klg1Rd2QN877Bncbs7wMdouiH1kbhcd2wj4idE6JdMauHIpYlmqUcgHN2qUh37XQcNo3bLTQcMNQI3EAeYk+hiwSIH0LRqq6hlYMrAMrA3Ug5ggjaJenN+r/AEo1Op9mY3p1AXpX9l7azKOAYXPep96dIgcR67dNP9op4dTZEphzzdyb+ShfMznGB7ZIO3b3idH679EMteniQLpUQUyeFRLmx71tYfqtOcaPUq2scsrCBkvswlIp2Mq+0SnWgScHRBJ8JlBTAEwtDFarWmSXFXgeV8OrW1hezBhyI2GVYmoEQ8TsnnpBtMx2Jra7chsgbT0KwbVHSku12zPBdrN4C87rTQAAAWAAAHADZNN6uujZw1H01VbVaijskZom0KeDHInwG6brAREQEREBERAREQEREBERA+aOsIf/AKmJL7DUyve2SALe2drgTCI4PZVezbtWuqluydYb9o2cOE33rk0OUxa4i3YrKM7Za6CzL32s3O54GabgqN9kCfg6ZJuf5zvaTMY1k1Btfs+HtHy+YkdsSlMZm590bf8AjxkbD1izF22nIDco4D6wLmlH9VRuF/yH5yAtQg3kjEtdz5eUj1RlA6DoOv2KFXejI/4H+gtOzz590VjNSmqnYEzHfmR8Zvz9aNMf2Z/3i/SBuultGU8TSajWUMjixG8EZgqdzA5gzkGnOrCvSYmgPT091iFqgfrIbBu9TnwE2U9aqf3Z/wB4v+2ejrYo78NU8GQ/O0DnA6I40nVXCV786TKPxNYfGbBoDqyxdR1OIAoU73btK1UjgoUkC/EnLgZtSdbGG34euO4Uz/rElUetHBNtWsvein+FjA0Ppl1d1sNetQvWojM2H6VBxdR6y/rL4gDOadTqkbifCd8odYOj2y+0FT+tSqgfi1bfGY/H6A0XjiWp10R29b0FWmGa/FGBF+eqCYHFK2K4+X1nTOrLoVrBMbiVyybD0yMj7tVxv4qO5uFs5ovqpwNJw7mpXsbhKjJ6O/NUVdbuNxym/AQPYiICIiAiIgIiICIiAiIgIicx60emTUb4PDvquVvWdT2kVh2UU+y7DMnaARbNrgJvWJ0iwBo1MJWvWqH2aZGtSceq2uckYcMza4IsTfhOrY228+Mus9+Q/nbLZccP55QK1HlwkrCVM7c7SLSe8kUjZu68CQ57R7z85bqZ2EE5nvMpYwJWMxeonMkAfn8JjvtbfyTI2Pr6zWGxch37/p4SzSeBP+1twHmZ4cYd4EjM8tC52D+ecCW2kDuA8pa/pB+C+UjNeeAwJY0k/ur8ZdTSh3qPP/iY5oUZwNs0T0xxFEj0dV0A9nWJT8BuvwnQ9A9amxcVTuNnpE2j9pN/hbunGBlLqPvBsYH1Xo7H066CpRqK6NsZTv3gjaDyOYkyfNXRbpPWwlUPTbaRroT2Kqjcw3NwYZjmLg/QuhtJJiKNOvSN0dbjiCDZlPMEEHmIGQiIgIiICIiAiIgIiIFuo4AJOQAJJ5DbPljTmkmr1XrNfWqu1Q32gMbqvgLDwE+l+k1Qrg8Sy7Vw2II7xTYifLmIGfgIFBN55U9UytRLqU4ECi5B5TM4Gj6T1WXLat+15fnMZiMIyns5jaO6W01gbhSCNhBII8jAztYFNokWqj6j1NgUqOZLG2XdLa1azCzubdw1vO15VpCvamtMbzrHuFwL95JPhAxlpXTlEqUQLrm0tqxAyMkYmmVAPESJA9PjLhpZS1eeknjAMJVRGcol/DJtgekSgiXmSW2ECk1SLHn8p2rqX0kWWvhychqVl/xdlx3dlPMzidSdM6lnP223HCVQR3VKWf8APGB3OIiAiIgIiICIiAiIgWMXQDo6HY6Mp7mBB+c+U8TRZG1XFmUlGHBkNmHmDPrOcF61+jpw+KNdV/RYhi4Nslq2u6ngTmw43b3YGi4ci9j4TJpQmHdbSRh8c6ZesOB/IwMocMDLdV1TJ2IvsOqT8pTT0qh9ZSPiJXVxVJ11Sw8QQQeIuIEfWD31Dnu1rhfG2fwkOrgKlyWsb79dbfP8oelqnssDwZWz8hmJ69R7es3kfpAiOmrvv3bPjJWjMLrtf2RmfpKaWELG7ZDidvgJmKDKi6q7P52wKcfhdZDbaMx+YmDppfI+BG0eG8TYvTzH4zChjrLt3jjzHAwIf9HP7NmHEMB8GsZQ+EZfWsOVwT8MvjL6O65AsORF/mJaqa7bSx+A+kCK3ATL4bCaq57TKMFhUTtO633DWGXfJj42mPav3AmBGelItVLS/W0gPZXxP0EgPULG5gUtOt9SeB/TVqtvUopTB3XqNrMP/UvmJymhTuf+Lk8AANs+j+r3QTYTBori1WoTVqDerMAFU81UKDzB4wNqiIgIiICIiAiIgIiICY/TGjqOIovSrqGpsO1fK1swwbcQcwRstLukMYKSFznbIDix2CfP/TrS9fE1GZ3Zqeu6rTBPo0VDqghBkSSrNrG5zAvAhdKtDUcPV1cPiqeJQk+q13S252Uah7wdu1RMAUHvD4/kJReVKYHjIOPwlLao3nyH1lbGeVSCin20JU81J1lPgSR5QKNdNmf4R9ZU6gbVcd6W/OScBpA0yDqgjwBk7SOl6VRckIbugYVnHAzwvy+M8bb5b/KehPKBWzCwNtvMw7gZap79b8rQVyntTCvqCplq6xXaLgi27hnA8R1363gtz/EJWUF7du/6yBf9Rk3RmJpU7Fwcxe4sd9vDZK9K6ZRxqouXEwMU2RtaesANpz4bfjLaKWYKNpIA8fyl/EhdchTdRZQfe1RYt4kE+MDxUB9te46w+NrQqi4BIzIHrDVz4tsA5meBYBtA7Z1b9BqKBMXUq0sQ4N0FJg9Cmw36w9Zx4BTsuQDOnz5LwGPqUXD0XdHuM0ZlY8jqnPunZehfT52rJg8aRr1FU0a1gpctcBKijLW1gyggAEgC2eYdPiIgIiICIiAiIgIiIGr9NMWqLRViAHqlVJ2F9UlV8QG8rb5wJsfcZ7bt8yfznZ+uTD62j9a3qV6beYZP9QnAiCd9+/b5wJlRgc7Dylhh4QA45+E9GII2gfKBZMtVJOXE/qj8QkhFZtlK/cAYGMo/DKV1qXCZUYV/uD+FZ79kf7g+S/WBiFpAW7hvyvxlyZT7G/3B8l+sfY3+4Pkv1gYu0pdAdomX+xv9w34V+s8+yP8AcN+EfWBiGpDIcBb4k/nKKqWtvma+yv8AcN+AfWUtQb7hvwQMQlI6he9hrBBxJIufAD+IQJlPRn7h/wB0fpKSbf8AaI/wW/KBj0W8koi8BLxrAewB36o+cttijuA/EPygTcJqqclA52t8Za0vVZq1L0RIZFXVbeGDl9bkASTyAkUB2/8AhmW6P4cviaSG3bq0UNtpVnUEE8M9gsDbO4ygfTI2SqIgIiICIiAiIgIiIGr9ZGG19G4ke6gqfu2Vz8FM+bk2z6u0nhBWo1KLbKlN0Pc6lT858pOhVirCzAkMODDIjzgTaZnrSiiZcMC0wlIy2StpSYF+ljqi7HbuJ1h/mvbwkgaZqfqfhP5NMfEDJjTdTgn4W/3Soacf3U/C3+6YqIGW/p1/dTyb/dH9Ov7qeR+sxMQMqdOP7qeR+stPpiofdHcpv8SZj4gX3xbttdvxEDyFhLRN9uffnKYECoDkPKXkEtLJFMQLgmf6vMNr6RoDcrM55aiMw/zBZgG2TeupvB62Jq1t1Ojq8taowt8Kb+cDs8REBERAREQEREBERAT5v6y9EHD6QrACyVD6ZOYqXL+T647rT6Qmi9afRg4vDCpTW9ahrMoA7ToR20HPIMOa23wOEUGkmY+k9pLR4HrSgysmUGBSZ7PDLmHQMTe9gpaw9Y2tkPOBavF5JGGUgP2guqxINtbskDI8DcZwKCXQdvt+raxAubZ5Z89loF3SGNpulFUw6Ump09So6uWNd8v0jggapyOWfrbchaBeTa1BAATlYAHVNyzG/HZ6plLYdL6oLaxTWF7W9XWsbct8CLeLyScMtyl21gutfLU2X77bryIIFyBKRK1EC4gklBLNNZJUQKKxynaeqXRhpYEVGFmxDtU56g7FPwIXWH7c5P0b0I+OxKYdb6l9aq49imD2jfcx9UczwBn0ZRpKqqqgBVACgbAALAAcLQLsREBERAREQEREBERAREQOP9Y/VwxZ8Xg1vclqtBR2r7WekBtvtK99uE5OHKmxBBBIPEEZEHnPriav0k6D4PGXapT1ah/7qWV/8WVn/wAQPhA+dFqT3WnRtKdUOIQk0K1OqueTXpvbcPaUnncd01vGdCsfSuWwlUj9RRU+FMsYGuEz0EjMZc98k4nCOmVRGT9tGQ+TAS0FEChqjG5LE3FjcnMcO6ErOosrMBwBNpXqT3UgWi5OVzmbnvzz+J8412ve5va199rWt5S7qT3UgW/SNbV1jq8Lm3lKQsvFZQzgbSB3mAAlay7hsHVqf9OjUqX9yk7/AMAMz2j+gmkKpFsMyA+1UZUA71Y63+WBg0MnaK0bWxVQUMMmu5sWOxEX33b2V+J3AnKdB0P1TZhsXXuN9OkCAeRqsLkdyg850bRWiaOGpilQprTQblGZPvMxzY8ySYGM6H9FqeBo6inWqNZqtQixdhsAG5Rc2XdcnaSTscRAREQEREBERAREQEREBERAREQERECllByIvINfQuHqevh6LftUkb5iZCIGCbohgD/YcN/49MfJY/qdgP7lh/3KfSZ2IGC/qdgP7lh/3KfSef1OwH9yoful+kz0QMEOiGAH9iw3jQpn5iZDD6KoU/Uo0k/ZpovyEmxAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERA//2Q==",
                "https://dzp3g6fzlnblr.cloudfront.net/wp-content/uploads/2021/07/crusher-evo-wireless-headphones.webp",
                "https://m.media-amazon.com/images/I/513a+PRsMvL._AC_SS450_.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRkTMMG0wd6C7d1ScxXRQWbZ4Lvi-C2zpmpPg&usqp=CAU",
                "https://5.imimg.com/data5/LF/QW/TT/SELLER-68265926/headphones-500x500.jpeg",
                "https://www.awstro.in/3638-large_default/oneplus-wireless-earbuds.webp",

        };
        return urls;
    }
    public static String[] getAirpodesnames(){
        String[] names = new String[]{
                "Apple AirPods(2nd gen)",
                "Skull Candy HeadSet",
                "boat Bluetooth",
                "Noise Bud",
                "MI Neck Band",
                "One Plus Bullets",

        };
        return names;
    }
    public static String[] getAirpodesdescriptions(){
        String[] desc = new String[]{
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",


        };
        return desc;
    }

    public static String[] getAirpodesprice(){
        String[] price = new String[]{
                "9999",
                "8000",
                "2599",
                "3000",
                "1500",
                "5000"

        };
        return price;
    }
    public static String[] getTabsUrls() {
        String[] urls = new String[]{
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEBISDxAQFhAQEBAPEBAQEA8QEBAPFRUXFhUSFRUYHSggGBolGxUVITEhJSkrLi4uFyAzODMsQygtLisBCgoKDg0OGxAQGi0lHyUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgIDBAUHCAH/xABNEAABAwIABwgNCQYHAQEAAAABAAIDBBEFBhIhMUFRIjRhcYGRsbIHCBMyM1RzdIOTocLRFBYXQlJylMHSIySCouHwQ0RTYpKzw2MV/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAMEBQIGAf/EADERAAICAQIDBQgCAwEBAAAAAAABAgMRBCESMUEFMlFxkRMiYYGhscHR4fAjM/FCFP/aAAwDAQACEQMRAD8A7iiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIsPCVYImZVruJs0bTw8CidbjEO6Njkqo2SvN44u6tie7VmbcErqMGziVii8E4RQz5XL/AKsvrH/FVHCUwHhX2A1kH2ld+yZH7ePgTFFwTHPss1UEzoKR4LozkyySAOaH62NaLZxrJ13Ftai30w4a8ZZ6iH4KNrBMnlZwepEXlv6YcNeMs9RD+lU/TBhvxpvqIP0r4fT1Mi8s/S/hvxpvqIP0p9MGG/Gm+og/SmV4g9TIvLP0v4b8ab6iD9Kqb2XMNHTVtGb/AEIebvUyhuepEXln6X8N+NN9RB+lPpfw34031EH6UyvEbnqZF5Z+l/DfjTfUQfpX36YMN+NM9RB+lMoHqVF5b+mHDXjLPUQ/pVn6WsM+NfyNQHqpF5eo+zFhiN1zNG8ZrtkiBaeaxHIV3Tsc46R4UpjIG5E0TgyeK9w1xFw5p1tOe3ERqQEtREQBERAEREAREQBERAaLGU54v4z1VwDGbE2vlrZHBgcJXMInLs8YaADZukjNmsDmtoNwO+Yzd9H913SFpC43AAzG9zlWydmbXfOp4xzFFaU3GbwWaCN7YmNkJLw0ZRNib7DbZoVVSdyrqsVZ3PMpCA824UdlVMxdnLp5SeEl5Vt5AGrmVysbeqkF9M7xfjeVZrI3NdkuHwPCFzX7tcp464+ZdfeSLGUVs6aksN0M526uBUYHpMtxcdDLcrjoW67gtTsvSJr2015fl/hfMr6i/hfCjXdwGwcy+GEbBzLYdwVupIYM+k6AtiShFcTSx5FZWtvCMIwj7I5gjKe/esvbY26qiY+Q2HL9lo2lbynhDGhreU6ydq400Y3vKglHxwvoj7ba618TQupyNLLcbbIIhsHMFIwseopmWLjZtgXE6rDaFcnpIpZWPQijq23hmm7iNg/4hO4DYOZZ0TA5oc03B0FVdw4FXUYNZSWPkSO7DwaOtpi3dN0axsPwWDlFSp1MCCCMxFjxKNVEJY5zTpabfArzvaelVU1ZHlL6P+efqXNPdxrHVFoFdl7Wx/7xWi+Ywwm20h7viVxr4LsXa276rPIR9crMROzv6Ii+H0IiIAiIgCIiAIiICP4zd9H913SFpVu8Z9MX8furREqxX3UU7e+yq6xq87nm6VeusWvO45uldnB50n327zh3XW4mja4WcAR0cWxaeo307y7uuVuCtDstJ1zT8V9iTUd6Jn4NweGRgC+6u/Ppz6PZZZXybgW1bTWsNgA5lW2mW9GChFRjyR52Wqc5OWeZp3whoJOgC/8ARaBlE5z3Plf331W6ANQudik+H25MbR9t/saL9JC0jVFZVC1riWcb/D5+Je005KDkupdhaALNAA2BXgrLVdatGvlhHMysLV4ZqModyac31yNZ1NV2vwhk3bGd1oLxobxcK1LVm9oaxSTph15v8fv08rOnpafG/kZOBLsfkEgskNtha/UfyUi+TKMNzZxpGccankUYc1rh9ZjXc4uoND7sOBclyIO0J8MlLx/Bqvk6j+MtCctjmjvmlp42/wBD7FNTAtPjLB+yadkoHOD/AEXesqVtLi/P0INHqmrl6EKfTFrSSRxDOus9rdvur83j665hWd4eTpXUe1s31Webx9deY1Fca54j4HooSclud+REVckCIiAIiIAiIgCIiAj+NJ8F/H7qj5K3+Nh8F/H7qjpKsw7qKdveZVdYtedzzdKvZSxq5255R0rojPPVW61S87JnnmeVtqadjiMlwOcXGg6di01fviXy0nWKxnjOV1ptVKhNpZTZbnWps7MIblZEdMvuCHiWGGQf4kMb+UtFxz3WzihXpnamso8VXFrZkPxzgIEB1XlHLubdBUZuBpKlOOGEmyEQsALYn3dJrMgBBa3gFzxnizxOVi7rn7vI2aFiCiy4apgGk8QBueJaeuwvIdywFjdf2jxnUFkSrCmAOYhV9a7p18MJ8P5+fNfL6mhRXBPLWSxFUj62bhGhZbHA6CtZIyxtzFUNcRoXnY6mdb4ZrkXHWnyNyTmXSMH0xEELTpEMQPGGi651i1SyVNQyK92eElNr2hb33Po43Lq7m8C29Dapxckvgea7asUJRrzvz/X5MB0a0ONgtAOGZnQSt9VVkTO+liHAXtvzKJ43V4kbG2nLX2c5zyNGYWbptfSVPfZwwbwyr2fXKd0dts8+nJkZru8PJ0rqHa2b6rPN4+uuVVAkyTl8Gyy6r2tu+qzzePrrzerebM4xt1+Z7CtYid/REVUkCIiAIiIAiIgCIiAjeN58F6T3VGy5SLHE+B9J7qjDnKzX3UU7e+yslY1c7c8o6VWXLGrXbnlHSuyM4FX74l8tJ1irMzdfIr1dviTy0nWKqLLiy4phxwki7J4aOl9i/CAkpXQk7undmGswvuQeR2UOZSzCkxigkeO+DbNOxziGg8l78i4pizhh1HVMlAu0XZKwW3cTu+A4cwI4QF2fDcjJaIyRODo3iKRjhocwuGf28i0tFfxxUJc1t8jB12n9la5rlLf59SAuhWLNTrddxVYpLrbyUo38O7IXWNste8qXYWxamccqENcDpYXBrweC+YjlWpGK9aTbuFuF0kQA/mVW6TfI16dXQ4540vNpfc0FQM3ErUED3uDWNLnHQGi5U1psSj/mJRb7MO6PK9wzcy3UGD44m5MLGtbrtpdxnSVnvs6V1nE3hfX9Hyfa9MFiv3n9P36ephYCY2iiLWND55LOlkPeC2iNmsgbc1yTwLFwjhGaTv3ut9kblvMFm1Ma1NS1bVdVdUFGC2RnVYnY7Jbye+f7yXwNfI5Wi9XJQrDlBezUgjHrTuDxjpXTu1s31Webx9dcvre8PJ0rqHa276rfN4+uV53Xf7PkaFXdO/oiKkShERAEREAREQBERARbHY+B9J7qiznKT48nwPpPdURc5Wa+6inb3mVl6xqx25HGOlVlyx6t2YcY6QuyM4fW75k8tJ1irllard8yeWf1isqyl0SzF+Zas6GPLBlDNp6eBSLEvGw0uVTVOU6jluDmu+ne7/EYNY0Et4LjPp0llZqY2n73B+akupaftIPDX1I3wzjwTWx1GNrSAWua5pztew5TXDaDsV+KNc0wZhiogYY4pLNJyt00OyTrLb6Lq584azxmTkyB+SvQ1i4VxLcxLOybW2oyWOmc/o6lG1XQwrmVNjfWsOeRjx9maNpHO2x9qluBMeaeQhtQ3uLzmD75UF+F2lvKLcKkjqoMz9R2TqK/exlfDf6bP0TN7JAViSQLfdzBAIzggEEZwQdBB1ha7CM0UffvAP2b3dzKxCZRUX/5NFVQqP4VmjjG7cBsGlx5FVhrGYuJZTjJboMhsXn7uoDhUdcSSSSSTpJzk8a6sseMR5m/otHNLis2+HX+D7NX371uba7TzBYpqHcHMrkkQOjT7FjELLulcn7z9DZhGCWyPtRKS0g8C6t2tm+qzzePrrks7s1l1rtbd9Vnm8fXWTqJZnv4FiC2O/oiKA7CIiAIiIAiIgCIiAiOPh8B6X3VD3OUt7IJ8B6X3VDHOVmvuop299leUrFU7MOMdK+5Ss1Lsw4x0hdnBxbCBtUS+VkP8xWRFMHC/ONix8Ib4l8tJ1ivrWgaAvuklKLeORbsSfMvPl2c6soisuTb3I0sBFUvvcjsRRb5IZKEVbo3AAkGxuAbZiRqBVK+PY+m4wRjBNC0RGWT5Pe+QHOGRfW22rgW3w7Sztpo5g393mc5vdQb32A7Guz2OvJPLD10vsc4SbU002D6ndNawujBOfuDjumg6i15aR97gVim5w93++RQ1UI1/wCZLlz/AH5r69fE58vqvYwUr6SofA8XLDmfawew52vA4Rb2jUvlFGZG5QGsg8BVqF9dk3CL38mTvuKfR/koAVupizX5Ctk2kK+VdP8As38EbjzC/wCSltqUoNMjjclIjjzcldf7W3fVb5vH1yuOtXYu1t31W+bx9cryjlxbmmd/REXwBERAEREAREQBERAQzsiHe/pfcUJLlMuySd7+m9xQcuVmvulS3vFeUrVQ7MPvN6QmUrU7tH3m9IXZGcfwhviXy0nWKqVOEN8S+Wk6xUgxZxSqa5rnwGJsbH9zc+V5FnWBzNAJOYjUmm6otWyjFZk8I0K3WLWLNTWvtC20YNnzvzQx/wAX1j/tHs0roOBuxvSREOqnuneM+RYxwjjAOU7lIHApXUbmFzIWtaBC9sbWNDWtOSckNaMw1K6qpNZMjUdpwj7te78Xy/k4bhFsAkLKa5iYSxsru/mINjKdgJGZo0C2k3JxVhUMtjknQdHAVnLvT2KdaaNGceF4JBgulDqYBwu1xkuP4j7VHa+lMUjmHVnB2tOg/wB7FM8VYg+lG1kkrT1uhy0eOMQbUMA09xaT/wAnWVi+CdafVGXptRjUzr+L+hoFuMTq0w19M6+Z8rYHcLZNxn5SDyLTkLJwYP3iC2nu8NuPujVR5GndHirkvFNfQ6zjHi9T1uSZg8Pju1skWS12Te+Qbggi9zozXO0rVNwDFEwMjbuW7Tck6yTtUrk18awZ2rVjVCMnNLfxPBUa25QUHJ8PhnYjEmDxsWtwxT5MEptnyCwAC5JfuQBzqWSRqPYZqgXdzYczTuiPtbOT+9Cmw5pxTwa2jtlZYlzS3fl/PIgMmDZWsL3ts0WGci+c20Lq3a276rfN4+uoPh4/u7uOPpU47W3fVZ5vH115vX6aGnsUI55Z3+f6PWUWuyLb8Tv6IipE4REQBERAEREAREQEG7Jh3t6b3FAy9TnsoHe3pvcUBJVivuoq2d5lzKVqd2j7zekL7dWpjo+83pC7Izk+EvDy+Vl6xXQew5hCxqYCc7gyoYNuTdr+sxc+whnqJba5ZOsVnYvYQkpKqKcNdZjt02x3cRzPbzHnso6G4TU8bLmSayn21EoLm1t5nfbql5sseKrZI1r4nBzHtD2OGgtOcFXw7NnXoF4nh85bicgx6xXkgldUQtJppHF+5F+4POctdsbfQdGpaJrrgHaLruFXLYFQzCmC6cknuEIJN80bW35AoatHwzbg9n0N/T9pS9mo2rLXXx88/c1eJeEo446hsrrBpZM0aXOJBY5jRrOZq0uFp3TSvldmLjmGprRma3kAHtW0qYgBZoAGwAALWTMVt1NRwS0qHtZXRW8v7+DVvas3F98TKuB87g2JkzJHuOVYZG6FwAT3wCsysW5osVzNSF5JEzyHwAmzTEBod97SDqsNpVGyqW7istFu66uNeLXhS29dvp49DpEOFKaTwdTA47GzRH81jVuFadnf1EXEHtkceJrblcpgpRGC1zd2DZ+ULEEaQslhV6nicU57PwMZdgVwl/sePJfz9iUYUxiy7tgBa06ZHZpCP9v2ePTxLSsKxmuVUtS1gu48Q0k8QVlOMY5eyNOrTQqjw1r9sow2f2DuNvSpz2tm+6zzePrrmNdhQyNLA0Bpsc+dxt0Lp/a277rPN4+uvM9o3wuu4oPKxj7/ALNLTwcIYfid/REVAnCIiAIiIAiIgCIiAgHZUO9fTe4uflyn3ZXO9fT+4uf3Vmvuoq2d5lV1RKdH3m9IX26tzHR95vSF0cHMKvfL/LP65WasGq3y/wAs/rFZyvdmd2XmT2dCT4nY0fJj3Ke5pnEkEAudC46XAa2nWBxjXfpPyhrmhzHNc1wu1zSC1w2ghcNWfgvDNRTH9i+zSbujduonHbk6jwixWg+Zk6vs6Nrc4bS6+D/R1GqlWhr3rVx45Md4WJwO2Jwe3mNiParNRh+ndoc/1bvgpoOJnf8Ax3ReHF/f7FFUtdKFRU4bi+rlnkyR7VrpcMyNexzA0ZLg8AgPBIOYG+kLi7WVVx4s58jTo0tmOXqSjAeLpkIknbaEZ2sOYy8Y1R9Klkix8BYbjq4stmaRtu6xE3c07RtYdRWRKkJxmuKLymec1V107WrVhrbHh/3x6mlwzgpk2672QCwePrDY/bx6VFqqiljO7bm+03O08urlU1qCtZUOQ0tFqrILh5r4/h/jl8CIzVWTmGd3sbwla9zrm5NydJKktXBGTcsYTtyRfnWvfAzUxvMqt1c7Hu9vA267otcjQOFiV1/tbd91nm8fXXNMIeDNhbONHGuk9rdvus82Z11i6qn2U+HOev1ZdhLiWT0CiIq52EREAREQBERAEREBzzstHevp/wDzXPrroHZb/wAp6f8A81zxWId1FWzvMrurcx0cY6V9VuY5hxjpXZwczrDaeQ7JXn+YqoVx1tHIVRXj9vKP/rIP5irYp3f2VxRO6OfZZLbS6mbHUtOux2FXitcKfarsby3i2LVpusa/yL++Rw4LoZa+L4x4IzKpWVvuRlmaK+caen+q17jnW2WHWQ/WHL8VR11LlDiXTmSQl0Zl4BlfG8yxuLXtzNI4dII1jgKnWDcZI5QGzWjk0X/wZDwE96eA86hWDI7RjhJP5fkr5YtDR08Onj8Vn13KGs0teofvc1ya5k5qVq6krQx4QlhaclxyWgnIdumcg1cllbZjOHeEiIO2M5v+J+K+XXQqkozeMlCvs62D23X96f8ATNqCsGUo/C0LtbhxtP5KxJVMOg+wriN1cuUl6mjCuUeaLGEPBnjHSul9rbvys82Z/wBi5fWTgsIF9S6h2tu+6zzZn/YsjXyUrcrw/ZdrWInoBERUiUIiIAiIgCIiAIiICOY7YANZThsZAmid3SIuzBxtZzCdQI17QFyepwNVxuyZKWoBGyJ7hyOaCDyFd7Rdxm0sHEq1I4B/+fUeL1HqJv0q3Lg2cgj5PUeom/SvQaLr2vwOPY/E8nYbxSrHyOkhpagl5yns7hK0h50uaSLEE57aRfRrWp+aWEvEK38NN8F7HRRvBKk0uZ44+aeE/EK38NN8E+aWEvEK38NN8F7HRNj6eOfmjhPxCt/DTfBPmlhPxCt/DzfBexkTYHjn5pYT8Qrfw83wT5pYT8Qrfw83wXsZE2B45+aWE/EK38PN8E+aOE/EK38PN8F7GRfNgeOfmjhPxCt/DTfBPmlhLxCt/DTfBexkTYbnjj5pYS8Qrfw03wT5p4S8Qrfw03wXsdF9B4+pcScKSuyWYPq7/wC6F7BzusF6A7EeIrsGU8jqgtNVUlpkDTdsbG3yYwdZuSSR+S6Ci+AIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiA/9k=",
                "https://cdn1.smartprix.com/rx-iZpeHskvL-w1200-h1200/ZpeHskvL.jpg",
                "https://www.jiomart.com/images/product/420x420/493177673/lenovo-tab-m10-3rd-gen-25-65-cm-10-1-inch-tablet-4-gb-ram-64-gb-storm-grey-zaaf0017in-lte-digital-o493177673-p594162525-7-202209292329.jpeg",
                "https://m.media-amazon.com/images/I/71o6PxcKkJL._SX522_.jpg",
                "https://rukminim1.flixcart.com/image/416/416/xif0q/tablet/d/d/n/-original-imaggp4gtdze4hfd.jpeg?q=70",
                "https://images.hindustantimes.com/tech/htmobile4/P37693/images/Design/150841-v4-oppo-pad-air-tablet-large-4.jpg",
        };
        return urls;
    }
    public static String[] getTabsnames(){
        String[] names = new String[]{
                "Apple Ipad",
                "Samsung S6 Tab",
                "Lonovo M10",
                "Apple Mini",
                "Redmi Pad",
                "Oppo",

        };
        return names;
    }
    public static String[] getTabsdescriptions(){
        String[] desc = new String[]{
                "Only Wifi",
                "256GB",
                "64GB",
                "128 GB",
                "128 GB",
                "128 GB",


        };
        return desc;
    }

    public static String[] getTabsprice(){
        String[] price = new String[]{
                "$74999",
                "32000",
                "18000",
                "44999",
                "25000",
                "$23000",

        };
        return price;
    }
    public static String[] getLaptopsUrls() {
        String[] urls = new String[]{
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhiwRWoCU8XR5slUob3qsRV6c7fHVjW5B4_wgOBYj-ZuKMGIvhKOf8CJJTI2n-D1p2HYU&usqp=CAU",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFRgVFhUZGRgZGRoYHBUZHCEYHhgYGBgaGRkYHBocIS4lHB4rHxkaJjgnLC80NTU1HCQ7QDszPy40NTEBDAwMEA8QHhISHj8nJSs1NjE0Njc0OjQ/PTY1ND8xND80NzQ/NjQ9PTY0NDQ9NDc0NDQ0PTQ0NDQ0NjQ0NzQ0NP/AABEIAK0BIwMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAUDBgcCAQj/xABJEAACAQIDBQQHBQQHBgcBAAABAgADEQQSIQUxQVFhBiJxgRMyQlKRobEHYnKSwRSCorIjM0NTwtHwFXODk+HxJDRUY6Oz0hb/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAwIEAQX/xAApEQEAAgEDAwMEAgMAAAAAAAAAAQIRAyExBBJBUWGhExRxkULBIrHR/9oADAMBAAIRAxEAPwDs0REBERAREQEREBERAREQEREBERAREQEREBERAREQETFWrKouzKo5sQB8TKHG9t9n0r58ZR03hH9IfCyXN+kDYonPsZ9reBTRFr1T9xMo/wDkKn5Skxn2vVP7LBWHBqtSxP7irr5GexWZ4h5mHXInDMR9oO1KmgajQ/BTzNbwct8SBKettPH4hrNjcS/NKRKfFaZyDzm40reh3Q/QmJxaUxd3VBzdgo+JM1/Hdvtm0vWxlJulMmr/APWDOINsFQc1VkVjqTWqZ3PiiXN/EzNTwmGX23c8qVEJ8HfWajRt5MumYn7XMGDalSxFY80QAfxMG/hlLi/tWxTAijgAvJqrlvAlQq/C/nNXSlSI0w2Kqfjf/wDM+HD0Rv2c/wCd4+ljl6scV262tU3PTpD/ANumCf4831lLtLaOJZHertDEsQPUuyKTwFlfKNeNp7f9h3Pg6ydUYG3XvH9Jl2dszD4jFYahh3rOrvmqJUvlVEs2twAb2I3aTy1IrGWoxjxLrXZDYLjB0PS18RnKBmHpX0LEtl38L28p8m3IABblEky9REQEREBERAREQEREBERAREQEREBERAREhbVx6YejUrv6tNGc9QoJsOp3Dxga9t3t7hcLVagVrVaq2zJRTNlLAMASSBexB38ZT4j7QsQbei2cwU/2laqqAeKqG+s0fDO1a9QurVHZne2l3di7AA8ASQOgG60n0sW6aG4PLdOimj3ctbRvK+ftBtarez4Sip3GmrVWHjmNifKUu0sNtSpv2jUbTct8Nc/8MWtPa7QvvCnrYX+Mk0sev3h+Fj9DpKfQircfTs0vHdlcSz3ZTU51GqB2b8zXA8pFfZVSncehdAN7sh/h0/6zpNPFA7nB6Ov+If5TKcUq2zgoCbB1OZL8ungbbpib1p4a+2rbiXMaOFtru5s2rHyOi+evSWCYPLq1kv7T3Lt4IO+38Im94zIrqXVGLKWRwBcr7RVt4O6+4yImz6ZUnDFUcm5dhnY33d5ySvjrNx1FJ9mJ6O38Zy16js0lcwp93+8xBCJ4impAPmWmR1p2yvXqVAP7OguRPAWspnzE4apnIdSXBsS5zkHpfS3hBwbnebdCbfKVnOMoREcYErU09TCoPvVHufy7p7/2zXHqvRT8CW+l5j/2eOYnxsAPeX42+snbCsRbwNtbFHdi7dMi/qk9ptbHDdXV/EL9FtMD4Bhra45jX6SOVKyNvaIbjMczKwPanELpXw6OPDKbfvhr/KbH9l2GXEYrE45aYRFC0US1rGwZ7gEi97HTnNPr4/JTdjrZTYHUFtygg9bTr32ebI/ZsBRQjvMvpGvvzP3rHwvbykptE+MGp43y2iIiZSIiICIiAiIgIiICIiAiIgIiICIiAiIgfJzj7W9s5Eo4VCM1RhVYXt/R0mBUeJqZSP8AdtOjmcM7Qu+Nr1cQqrUR2yooIJWlTuqEW7wzd59P7wzVOd3sRM8KRcTTY99cjcx3D423HxtJiVTay1jb3WGYfX9JBegF7pLp9xxnHwNj8bzC2EPshG/AxQ/BrL9Z3xaMJzmJW/pnG9Ef8Jyn4d36GFx1O+Vs9NuTC4+FgR85UUMPVZwiCpmO5XU28c4Gg62m17N7P3QNiirAG+QEhFIN9X3k8Cq/OYtafDdYyj01YnuEPfcF1J8BvPlLV9j1Gosr1BTD5Azk3CKrq5ygevUJUKFXQXNzfSe6m0KVG+RFzHTMV38gqDUjgAdLWsBKzGbQdzmdyvnd7chwQf6tOS9LTOXTW1YjDFt5yz0kpZgtJQlNN7It7vWqEbmOUWQa3PA6TNssuAygd92JygiyDU5b7tAdTu38BeeaFNmXS1Kmdcx1Z+oG9z1Nh1k7B4hFdaNJd4LOSbtkUes7cBmy2UaSNpmIwrpRETnK4p4ZWCqwzECxbj8eXjI+KFGm2Q5b2zC5t3TcAk2sNxHlIWO2mR3E38Wn2vh6dTDlHY+kTNUuBnIAF3TL7XcB0O4zena22ZnEta00icViMx5lMdEG9PO/zGhvMD4ek3Mdd4+I3edpX7C2sGqDDgHJlYgMczLb2mPC5IGUaC/lLTGYex7mjDhuuONj+k9vNq27Zl7SK3r3RCvxGxyO8h6gg7/AjfKmu7KbOuYc9zDz4+fxltQxTA9ywbUlD6tS2/T2XA5eI00kmoiYlMy6NfLY71f3G8eDcfGeRaY5YtSs8NYw2zhicVhsOhzLUqZ303IneZWHC/6cZ+gFWwAG4TlP2UbMzYnE4kjSn/4dT1Bu/wACB8Z1iezOZcduX2IieMkREBERAREQEREBERAREQEREBERAREQNT+0bbQwuCc3IaqRRUg2Iz3zsDwKoHIPMCcpo1cM9vR1DTPBW0A8xcfST/tc2i2IxYoIwyYcWI11q1AGc6HcFyLuOuaapsPszWxBDepTvbPvz8LIo9Y303ADx0ldPDUd0eG1ZcQF0ZaqeTj9QPjJOH2ItQAvTCNvsjWFubA6AdQQOsnbP2ZRwyXGgvlLnvu7D2V4O3h3V13ytx+2Ge6pZUB11uoPN2/tH6bpWJiZ23UmMRv+k98VSoLlQKf5L9OLn4DoZV4zaDt3nbKOF/WtyVdyCVy1mcnJrbRqz6Beg93wFzPnpETUd9vfbgfuruHibnwlO5KZ/SSmc6qPRqfbfVmHTifKwn1aiJqO83vvrb8K7l+Z6yAKz1SSgLc3Y2UeLH9NZJoYRB3nPpCOLdymv6v9OkzaNtytvRKwzVK5JTRQe9WfRF8DvdugufCbFhsKlGkzjugi3pH0eqwB1+6gubL1ms4jtElOxFnYermFkT8KDf528DIqVMRjCalRyEGmdzlXwHIfdXU/Th1KWmcztHy6aakRxvPwsMHigai5DcIwZ34Kqm7ZRz4X4kgC15ZbGLpVLFSzsHdkGuRLFiv4iNLcvHTxsyklFCEGg7zVH7t7bmPuIOHHlrrM+y9rIrkJdix1cixY34Dgt+G/nyHlZnfENTjbMoPZvZQwy53YNUYDM3ABRfKvQbyePlLXG4nOjFTZkYa+O4/EN8JSbb2iA7ICNSwNtyUwSW/eIH6cZH2bjiwrk6XSmSOTFmNvm0rek2nuapq1pHZHulY+oCEqqcoc2Yj2KiH1hysbHwJkfE7TNEHEqos6slSnuHpF0t0sxVh0a3GR8LXz0ayH2ctQfmKN/MvwmHZVBsViKGF3pVqJUfwpBw/5gL/uiO3ESjbU8x53dg+zzZRw+Boo187r6Ryd5ap3jfqAQPKbRPCrYADhPcy5yIiAiIgIiICIiAiIgIiICIiAiIgIiIHyV+2tpLhqFSu2opoWtxZh6qjqzWA6kSwmqdqapqVqOHGqrbEVf3SVoJb71QMwPA0Z5M4jMtVr3Tho+C7NK9quIUO7MX3FGd2YszMAfVLEnnLPF4pEDsx7iEI5TQvUI7uFpW3H3mG4aDiZ723tJly06JBrVXFFDwDmxd/wIpv4kHhND7RbSVqnoaRPocOGppbe5BArVeru7BAfvHkZumbfhbUmKbQk7R2q1ZizsFQDLZNFCjT0dPkgtYnexB5HLBpD0ozv3KK6Kg0L20IHJb728hxywkTObMbU0GZyug4AIvK+ijkBfgZZUsK9fK7grTIHo6KaM6jQW9ynpbNxG7nLRiI2Q3tLE2JeoclJO6vLuog6ncPqesyUsGo7zHORvJ7tNf1fz06STtKrTw6gVMtxquHTRV6seJ6nUzW6uLr4kkgAIulz3EXp49BcmWrMVhiefWVtjdsIvHPbdfuoPwoJVHE1sRqo7o0zscqr0vu8hr0mTC7OS97Gq2/O2iL1C8R1bToJMeoi+uxdhoFXRV6crdALdZmZmT8seA2auYEg1n6ghB5es/nbwmw0NWAZs7jci2yoPH1VHhfylP8AtDFe+wppyGl/Le3iZLwheopWipp0/aqt6zD/AF/2M5dS3ovpwkbVxJc+jU3tvC+qCd/Um3E628RJ3ZzDhKiKdXuLL7vVuvIefK9QlTK3o6I8X3sSd9uXjv8ACbHsKmKC1KlwTTRmZj6qkAkJfi5awPIX47sRbtrhSa9059Gj7SqBq9UIDl9LUuSPWOckIo90G1+dvhKANKmVP9ZUIYjiFW4QeJLMfhPdBQve1JO5joXPHKPZXm3w5iv2jitW1Gci7PwRTpp1O4fLnLRaZSmsRv5StlP3MS/AIlMHqais3kcp/KeU3L7F9ml6tbFMNEX0KHqxzv5jT800SrenhwlsrNaoV4ooBFJT945mb/ieM7n9neyf2bAUUIszr6R+BzVO9r1C5R5Ty07YZtHH4bVERJskREBERAREQEREBERAREQEREBERAREQPBNt85nW2rdKmJBJbEsWpg+zRACUrA6i6ANb3nebR25x2TD+hU2fEN6Ec8hUtWItqD6NXAPBis0fFuGc+6lkUfLT5n4Sep4h1dNTMzZVtiSlfE1f/Q4Qol9bYiupZm8QWdfC003C0LaE+qCx/c7ikf8RqreIE2ZkL0Nr+8cTnP4UruSPCy2lSMP3nHNAw6r6d2+ms6a12lG+8xP5ldbE2H6REuoKF2bIdzsoATOfcUF2bndRxkrb+1Bh1f0ZzOSFNTi7nQKvJRbcOA0krD4r0eEULoWLKW5DflHK/6SixNDOaY1BZnJbgqqFzN+IAtbkCels1zNpmfHDcxiuyjw+zCx9LiCXZjol95v7R5X0+Q42k4muiWD2YrotJdFTpYbvDU8yDPe1cVk+4SBoNSiEd1E+9ltdvLmJV0qTsLqMi+8dXPhylq2zu57RjZlxOKYjvsEXgg/ReJ6nWesPTc2yLkB9t9WPVU3zGhRD3Bmb3vWPxOg8vjPdXEZfXbJf2V1c+PHzM8tMzxv/orERyssNQpIczku/XXXwGgkvF7R7ozsETgvE/hUatKegKjC6qKS/wB7U1J/CN3wDGS8NSp0yG1d23VKgzsx3dynqW8W08JGaRM77+ysW9NvdYbOpO9iA1JG3HfVqDkoHqr1H5jul9tuotDAiygI7qijeuVbuSPe7yLdjobcgAfuy9mNmU1wwZ/Vw171avWq3sJzHiDfdKf7QcacRXTDU1zigCpt6npTbMFUetlChRyOYa6yUTN9SKxxG6kzFa58y1XF7RZ7lTlU6Z95a3sqPaPyHzmTB4VUVatYWQG6UTqajD225gcTu4DiR6ZKdE3e1WtuyXuidHK6ae4vmRMBzu5ZiGe1yW0Wmo4twVRwUTr7ccId2+/6Wex8K2NxlGi2vpKgd1+4t2cnqQDbw4T9IBbCw4Tj/wBjOylNevihdlQCkrsLZnazVGtw3ADow8B2KQtyTMzy+xETx4REQEREBERAREQEREBERAREQEREBE+Eyq7RbYXC4atiGsfRoWAva7HRFvwuxUecDnXaba/p9q5VN0w1NkHI1GKNUI/hTxRpV1nsi9SW+YtKHs7iyXR3fMzs4d7+szvWJY+LEGXWOFlQfdI81Nz9JmY/yh36O2lL1gCiY2vTf+rxaZ/H0ou3h3w4lc+FamcrDv0SUce+hsA4HKwHgCbyT6L09NVU2q0yWpm9swPrIT1sCDzHAEyfQxC4lVucmIQZbsLZraFHB638DfqD3Uq5LTnb9PODZSjU2PcbVW5HgfGT8JgUKKHtdc6g8LOuU/QSkqUmRspXKfcP1Q8RM2HxZ3X8jOn7atoR+5nTneMtQxvdqu7gs7O5Cnhdj8Bw8pGr1Sf6xjc7kXeeWnAeM37EYSlW1dRmtYPuYef+hK8dkwv9S9ibkswu7E/f9nyF/GStoTX3TjVrPlqq0n9oiivujvVD+o/hnumadM2VbOeLDO5J5JuU+PxmxYbsdUJJqPlX3aWrv4u1rH5SRT2Ziafcw2Gp0Bu9MxD1CDxvrl8BeT7LNxavqraey6pHpK7rhk9+qc9RuiJwPTfyl7sDDlmIwFEgnR8fiO8+7UoDuPz5jjM+B7MIh9LXL4mryYkLfldtbfAdJZ2rPZamWnSG6jSO8cmYgXHy6SF63mMVj/i1bUiczMftlbHYfAUXrZjVqE5TVJu1aofYQngN5O4Acd05nitoVHzHSkjklsp77ljc5n9Zrm+gsNd03LaOxTWfO9WwHdREUWRL+qt7jxNrkzHS2bh6Petdvfc5m8uXlKdP0s1zM8ylq9RWZ24abh8ARYBWX7qrmqMOi+wPvN5SbX2W6UmdwKaICwpA5izezmPtMSQLndfQCbK2KVRZFsOgygn9ZDq4N8RiMNhWBArVAzC1r06fec892vlOm+nFKTMyjF5tOIjZ0/7Odk/s+AoqRZnX0raWOap3hfqFyjym1TyosLDhPU+a6CIiAiIgIiV+1aVZqZFCoEqXuGKBwRY6ZSwHLW/CBYROR7Zq7bRrftStwCoqUmb8KugLfulpqeP2zj1bLWr4pG91ndP4RYQP0PItbaNFPXq01/E6j6mfnR8U76u7N1di38xmSk6j/oIHeqnabCLvxNM/hbN/LeRX7ZYQbqjN4I36gTjVOsOslU6/T5wOqt21ocEqHyUf4pgq9s7erQJ/e/QLOe0q56fWTKdZufwH+d4G3P2yfgiKeCsTf9J8/wD6es3FUPDu5v1M16lUPFj9PpM6U14aeGnzGvzgXB29VPrVbX3BQAfgwE8f7Te3ed2/Nr1ATObeUgpSPBj4A2+oJPxntKVvYQ9QMvnmBJPwgZjijfLm754Fw5HUqWRuPKKq6WOYC2oOYfNgfkZ5DAad8DkHBU+T2PwE8PTQKbFVGupQ0t+p/pEyb+YgadtrY6Elgi3N7bj4e7Y8dTKGrhstgrOLXNw7i2otoNAfObxj++AV7wPuHOD5spJ8jNYxyAb9DyK2I8WJ+VhAq6bupOSq4I3CyuT8AbadZ6xG06rMHLJm3FshVmtYDNZrHobX+U+VFv4X3A5vPS1vCYHHkOXq6DmF/Sare1eJJ32XVLtJVP8AR1KCVRyDnMPDunWYam2KJNslVejBXA6XDhh85TE7iRcX9m17/imPNbS9uGl9SdwIvpK16jUrxLNqxaMSvqe26QNs7r4qxHzAljh9uIfVr0z0Jyn4WmoM2gG4X5qdeNtAZ4cA2BUcg1jr0JuRKx1lv5REpToV8OiU9rNwKHwf/OZhth/ufnH+c5kUVTdRkPMNv6iwBHhJNDG1ge5XrC1vWYnjbQMTm+E9+7r5r8vPoe/w6Gdp1Duy/wAR+gM+emrNuv5If8dppQ7SYxDb04bo9MA/NAYbtbiz6xU+AKfObr1NPTHyToxHv8NzbB1G1ZiB957fJQfrMDpQTV6lzyQf4jc/OapR7SKf66lUc9KgI+BUH5yZT7V4dfVpFD7zLnP5rkytdak+f6Ozt4j+2wJim30aQUf3j77fibU+UtfsxwbVsbicU7ZxSUYdG3gsTmcrflYj96aRiO0aMpYPmIBIUgi5toACJ1/7NdlnD4CkG9epeq53EtU1BPXLlHlOfqr17Yis5bpny26IicSpERAREQPk8MDzmSIFVjaTMCp7wO9SLg+IM1fHbHaxVCVX3LB0/wCW4KDyAm95RMT4cGByTG9nlPrUFH36LGmfyPmQ+WWU1XYKg2WqF+7WU0j4ZxmQ/mE7PX2cp4SsxOxgeEDkeJ2ZVpAM6EKdz6Mh8HUlfnPKX/7Todbs8EJKZkJ4oSl/EDQ+cqMVsNr3KI/3reic/vU7Bv3lMDXKdSSadSZq2z8u8unSomdf+ZTFwPFJiXDMNchYDe1M+kHwXvjzUQJdOrJlKtK7D1EOikEjeL3I8Rwk2m4gTqdWSkcyAlSZ0qQLBGM+lRvsL8xofiJFWpPTVIEbHUEbeoPiA1/M3MocVh1F8t16g/S97eUu8Q8p8WYGv4nCdb+IvIDULcbfh1t5EgGW1eopNgwJ5A3PwGsU9j4ip6lCoepQqPzNYQNfddLEEnxsLeA/zmE026+IOnwm6UOwuLfeiJ+Nx/gzSVT7Bop/psdTQ8VWxPlmYH5QNB9GLHNcngdAPMWufiJ5RQvC/TUD5G/znTaXZnZaevWqVDy1A/hX9ZPwybOT+rwJc83GcHzZm+kDkS0STYJmJ3aZj9NZaYTsxjKlsmGqW4EoVGv3iLTrlHbLqLUsKiDyt8FCz2cfjH3FE/Ct/wCa8DleN7GYmhT9LiXp0EuFzO+bU7hlQMSdDwksdiQMPTxAerWSoQFXD0SzWIY529IUyJ3fWI4jnOkfsOJf16z+Asg+Uyp2bLauWY/eYt9TA5nR7M6/+UI+9iMUifGnSUuPjNu2b2bw4WjahRzhr1gEd0Zcrd1Gq7u8UNzyM23Ddn0TcAPAWljS2YBA0ftP2JGMbDBEp00puS5FlJRrXQKgsSco1vpOj0gFUAbgANOkx08Pl4CSAsD7efZ8n2AiIgIiICIiAiIgfLTyUnuIEZ8ODIlbAA8JaT4RA1zEbKB4SmxfZ9Cb5LH3h3SPMazeSkwvhwYHN8ZsVzvIqW3CqocjwfRx8ZWVME6cKifhPp081ezjyadRq4IHhIFfZo5QOdU677gEfojZH/5dS3yYyWlSpa4w1c8PUyi/4mIE2XGbEV/WQHxEq63Z3Sys4Hu5iR8DAgF6/wDdon+9qqPkgb6zw1RvbxNJeiU2c/mZrfKTU7LE72f5D9JNodk14qT4kmBQM9D26uIqdAVpj+AAz7Teh7GCD9ahap/Pebjh+zaruUDwEn0tiKOEDT6ONxNrJSSmPuqF+t/pMgp4t/Wqtbocp+KBZvFPZiDhJCYRRwgaEvZ939d3f8Xe/muZNw/ZcbrG3Ik/TdN2WgOU9inA1jD9nEHsgeAk+nsZBwl1kE9AQK6ns5BuWSEwoHASVEDEKIE9BZ7iB5Cz7afYgIiICIiAiIgIiICIiAiIgIiICIiAiIgeSs8mnMkQI7URynj9mHKS58gR1w45T2KQ5TNEDwEn3LPUQPlp9iICIiAiIgIiICIiAiIgIiICIiAiIgIiIH//2Q==",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVFRgXFRUZGBgYGhoYHBoYGRwZHxoaGBkcGRgdGRwcIS4lHB4rIxgaJjgmKy8xNTc1GiQ7QDs0Py40NTEBDAwMEA8QHxISHz8sJSs1NDUxMTQxNDQ0NDE0MTQ0NDE0MTE9NDQ0Pzo2NTQxNDQxND80NjQ9NDQxMTQ0NDY0NP/AABEIAL0BCgMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABAECAwUGBwj/xABEEAACAQIEAgYHBAYKAgMAAAABAgADEQQSITEFQSJRYXGBkQYHEzJCobFSgqLBM2JyktHwFCNEg7LCw9Lh8UOTU2Oj/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAECAwQFBv/EACkRAQACAQQCAQIGAwAAAAAAAAABAhEDEiExBFFBBRMiYXGx0fAVgZH/2gAMAwEAAhEDEQA/APZoiICIiAiIgIiICIiAiIgIiIEPieNWhRqVnvlpoztbU2QFjYczpPPR65cLzw+I/wDz/wB83nrXxfs+GYixsXyUx9+oob8OafNwqGTFcomcPek9cODO9HED7tM/55mX1u4A7piB/dr+TzwEOZeHMttlG6Hv6+tnh/8A9w/uj+RmRfWrw4/HUH9y/wCQnz8KhlweNkm6H0IvrQ4af/Mw76NX/bMyesnhp/tJHfSqD/LPngPKh4+3b0bofRaesLhp/tSjvVx9VmRfT3hp/tlLxJH1E+cfaSnteyRst6N0PpNfTjhx/ttDxcD6zIPTLh5/tuH/APag/OfNHtx2yv8ASB2xtlO6H06npPgm2xmHPdWp/wC6Zl45hTtiaJ/vU/jPlv8ApC/yJT2yfyJG2TMPqpeKUDtXpnuqKfzl4x1M7VEP3h/GfKOen1L+7/xK3p9S+QjEmX1iK6nZl8xL846x5z5LGT9X5TY8EBavSCMQfaKQVJB6JzG1uwGQl9TRMGGp5VVSbkKBc6k2Frk85ngIiICIiAiIgIiICIiAiIgIiIHlvr2xWXC4enfV6xe3WKaMD4XqL8p4aBPU/Xxi82Jw1L7FJn/9j2/0p5aJpTpWyoEvAlFEvUTSIZyqomRVhVmVVmsQiZWhYtJOHwzOwVBcnl+Z6hN7huFrS1azP18l7u35906dDxbatsR17ZX1a17aWjwtm1PRHaLny5eNoq8LI2a/eLfMEzoHTT+foJFemd/nY/7dPOep/jtGK4nmfbD71u3MVKZU2IsZiIm64nh+je2o1v1jnb+E0xnjeToTo3x/x1UtujLGZSXGWzmlopEGJVKk7b1aYL2mNoi1wvTPmAfkxnEz1r1L4K+IqPyRQo8Ab/41lLLVe1xESixERAREQEREBERAREQEREBERA+b/W3i/acUrDlTWnTHggc/idpxom19J8V7XGYmpe+evVIP6udgvkoA8JrFE2rHDO3a5RMiLLUE2fDeHtUN9Qg3NvkO2b6Wna9orWMyztaKxmWHDYdnNlF7b9QHWTsJOw2DQ2zVUF+23zM2uIVadMhQB0duq+l9dzrv2zRhUtuQfH5jKb8+YnZraceNMRMZmY5ZUn7kTMTh1ODSnTXLTZSTu1wSe8jl2D/k3Zh3nr/h1Tk3pfZYEdpC6+NtJRUcbD91gf8ACZrp/UYpGNnH6s7eLnnPLr6lHolrBgNSGAJtzN7azX4oBCrr7rGxHUw107CPoZplxVZdjUXxYfWYmxbMApYkA3A00NiPzmsfVKfMTlSvi3zzLb8TAyi2zg27HUX077/WcmDcTcYzF3FJSdszHu2H+EzTU9h/POc3n3reYmG+hSa1xKhlpl5lhnmy6FpiVMoZCV1JbsO+e8epjB5cM7kau5+pX6Is8Kw+9+oEz6X9XmC9lgaSncqCe+wB+YMyt2tDqIiJVYiIgIiICIiAiIgIiICIiAkLiuLFGhVqnQU6bufuKW/KTZyfrNxfsuGYo82QUx/esqH5MfKB80jt3l6iWiZFE3rDKU3hmF9rUVCcua+o30Utp26TsXGRQqLlA06JI873vND6PYA5lquSqqwK9Z1tfu/nv6zEprawPh/InvfTtPbXdaOZ/Z53lXibRWf7LQ8aphUG9yQBtbrNhbTb5zVVUNkX2YDMFZSpYswNwLjMRckdQOnnt/SEszU0GpY6C/MkKvYN5AxGAqU8Q1Ige0QgEI9hdVBurkjW1vHScfnX3a0x6w6PHrNaRMoBQgkEG4vcW1Ft79UpMtF2Acrm1XKxG1mOoY20vbslwq2plNNWDaoL3AIsHve2u1uZnHMy6Me2KnuLHL27W8pfWLDol83c2YS+uVIRUCggWZgWGYm2rZ7Af99kxY4AFsugy6dIEe7vcE/WRb8pK/nDWVa18zdfRXu/6+ZlALACY1GYgD3V/m/iZmaWvbcmeGMy0y8ywzGSFplJUykhKdwvD53VPtuieDMAfrPqrhdLJRpr1KPMi5+Znzf6BYP2mLoL+sWPgCB8ys+m7TG3a8dKxESEkREBERAREQEREBERAREQKTzb14YrLgaaA/pK637VRHY/iCz0meL+vnFXqYWlf3VqOR+0yqp/A0mO0T08oWZAJYszUxfQak6ADmTsBOirKXoNOmj0UOWwZFNrkAXA0FrEecyvVMgYWsaNBFqDpge6DsL9HMeWltJq8fxhhsQOwAfnPqNGv4ItPHHy8mtLWvMT7nCzGuXrgZlX4cz2yi973vpbWR6aO4d7IQigsfc3YKuUJa7E+et5jpO7tnU2ewOjBDyGmoudtBKVabp0XUrmF7Mtri+hF9xcb9hnz+vfdqTMe5erWu2sQyWdaNypCO2jZhYlNwV30zdnjaUxRYKiMHXICVV1y2D9InXe57NQJa+IDKEZbhb5QGItmN3sDcayS/EM9ValVndly+9la4S2VTa2lh1TDdPUrWj59dMAyM/w5Bba65gLXsW1zHt+khcSsFax3awFwdNCOkDYm30myoujOz1Mr3B6Iul2t0bkiyi/Ub6TScS0AXfU7a7aaW33lLWTWFlEqo94XO/8JVjIaiSKYmtYm0ItGFTLDL2lhmckLTKGXGFFyJEpek+pzBZ8WXI9xBr2sS31Qec95nlXqSwdqdWp9prDuAUD5h56rMGhERAREQEREBERAREQEREBERApPnn1xYvPxN1/+KnTp+OU1P8AUn0NPlr0zxftcfin667qP2UbIvyUS1e0W6adZ0/ozhgqtVIBbVVv8PIt37+XbOYWdV6M1QaZXmp+Taj5hp6ngRSdaIt/r9XH5EzFJmFuMfU33kWhw1qys+yrues7yVxRLEdsnUMWtPBlfifMB3kkX8NJ73k3464iHJFrREbe5mIaXDKns3Lo5P8AVhHUHKrZruGN7AlA1hY7HTS8wMqa5SewWBB7205dkmU0K0lZaq3NRm9mPeBRQAxK9IXDkAGw0JB3tDrZtM35d2tu7Yz5X29TOV+Cwj1XWmgu7mwF7cid+WgMsFBzqEYjTYE77bTNgGQOS7ulkcoyXDe0CnIAQDYE7nTvG8tcKPdc6DS6kchYAqT3a22G3LKZ5SxnLl55vC3hNfjBduuw2H59Q2k2R3xdiQqC40LG5vbTQC010qRaeUTMxHDXOh3IkvCreY62JbmB5Wl+DcX7DNqRWt8fupfM1ZMWlrHr/L/uRTJ/EDovj+UgGU14iLzg05zWFDLqI6Qlsy4amWNhu1lHexsPnac9umkdvon1VYPJgKRtYuM/73T/AMxnaTW+j+GFPD0kGwUW7uXytNlMlyIiAiIgIiICIiAiIgIlJr8VxmhT0eqt+oHMfJbmBsYnJYv05oLfIrPbfMVQfiN/lNTV9N3IBK5AfsqbjW1ruoVu8HuvuQ7zFVxTR3OyKzHuUEn6T5NGILatqWJYnrLG5+ZntHE+JCqLNUJNtVdiLX7Dpz5TgcVwanmYMn7hyHv2IPiJMTMInlywyHskzAV/ZtmBuCLG3mPIgTLX4Jb3WPiAfpaQn4fUXlf9k/xsZtpa9qWi0fCltOLRhusfjkqKCLhgQbEeeu0w4qr/AFKC+1x5tf8AKaQ1GXQ3HYwtLhiOsT1p+o01azW3GYw548eazGPhtMTRRVQpVVy1NWdbFSjm+ZNdDa3Xrcdcje075kp4ynky2IbK1/dsWJGW1x0QBe9uyZ2wKEE0qqPo7DN0GyowVQVNwWbNcKCTYGcf24mPwzlrmfmMKYTHlFdVCkVFCtmBuArBujqOY538wDHtkOrIDtt0dtxZbAA90x1OHVUZlZDmUsvR6eqgMdVuNFIN9u2REe+15z7J7iO/S+5IRbkDrNvObWhwdVGupmoVjm6JO+hI102PfI3Eq77MzE9pJnoeJaulSb3rn4c2tW17RWtsLuOUArCwsDI2HXok9Vj84FK1MljvsO3laWCoSoA0HM9fZObUvG+bTGMxxDatZisVznHyvqVM2vgJjMrKGc9rTM5laIUm69EsN7TFUEte9QN+5d/8s0s7z1S4PPjkNtEQt4llt8g8zt0vV9BUqeVQByAHkLTJETNYiIgIiQa/FKSEguCQbEL0iD1G2x74E6JoqvpCvwoT2sQPpeQK3G6rbEL+yPzN4HVkyHW4nSXdwexel9JyVWuz+8xbvJP1ll4G24h6VqmiUXft0AHgLsfAfnOfxnpnXf8ARlB9pUBdl6tbEA94Xvkq8h4tKTGzgFh1XzgdmXpDwkoaziHEHa3tazqeYqnoE76ZSFvbqYyDnLaoijQf1iZhccjlyqtTwzHzM2Q4Zlu1B1udLuqubdQc6g9rZiJrq+CKjK6EXJJqXLC/XkRbEftIBvAxq+Z9GzkDep0MptqSoNyL7dHxuJjSppnAZyCBmOV0U7gnMzZTcHpBhyuNpkamzKuqug0yrlA7baHyBExO4JOYtTAuQAXe9hprcafqhjAtsDcIQ7NuKblVzGx6SogHZdywN+V5r8WpU2BuxuFXJ7NdP3VY94G3hNi4YhWYEIOjdEyOQLtqM2ZV1O43MhVApL5GVVIPSfUsAdr2zMtxbMwO3OMpxOM/CC+JKsEbKzHuAtvoVJO36sqtRGBNuiuha2nhzt3gTGwIU5ASLjMwJyk2090WNtdcvPWR3CjQWZiB0irEg9V7kKN9Rl3hCUcOjjSzDssZBrcGQ7C3dp8tvlMtVrEMxLsNLubAXH7ZAA11zyr4ooNWBYnYMCo67aXbnsxgaqtwdh7rX7x+Y/hIb4R1+E966/SdUK/Sy2uefw9/v207ZQOjX6Q0NtevqgczhOI1KTXRypsy6dTCzDxEyPxFmFmVSej0gozAKuUAHktradYm/rYBW3APeLyBW4MvK47j/GaU1r1nNZRNaz2gU8YRs1u//mYKtMu2ZmLHtN/+pnq8LddiD8v+PnIz0nXdSO3l5jSaX8nUt3P8IjTiOlHpMTc2NtgNhLWW3KVWqZkFXsld8TzPaNsoxlDJdkO/058pnbhgZbpUVz9gBs/LZbdLnsToLxkw1k9d9SGDu1epbayD7ov/AKnynldXBstrlSD1MD1chtvznu/qcweTBZyNXYt+JrfhyzOy0PQoiJRYiIgJoOL+jVOsxqKzU6p+NOdhYZhz2m/iB5xjaWJw/wCmp50H/kTa3WeQ8cvjGGxqP7ra/ZOh8jv3iejzQcU9FcPWucmRt8yWGvWV90nttftgc09WxsFZj2WA82IB8LmW3c/ZXzc+egB8DL8ZwLGYfVLV0HVcsB+yel5F+6QaXE0Js90YGxDbA9V+R7DbukoSvYg+8WbvOniq2U+UyIABYAAdQFh5CW5ovAo6A6ka9Y0PmNZQhhsQ3Y2nzH8DKkxeBBxOFRjdlKN9rb8aHQdhI7pgqcOe11dXHU+h8HUbfdPfNpeYSg3Gh6108+R8bwOdxGDUCzIyc75QyXHPYqPvASFjKrHKufOB8Ka2B1BNgcv4R2zr7nmQfDXx5fKQMVg0bW1j1qSp69bbjXYwOUx1PpZWX2a6X6Tfh6RHhmHcJBe7AKmUhbkEJ16tZr2v94ze1cCUuUKZtbM4LML36OYnVT1Ecu++rdD0rqzsTm0Koo6yQultdibwId8jBkDBrWzEjcCzEMbHXXQX3hHKNvdmuq2bJv1WIN+wkiXIAqE3QMbgqwYsR8OrL0vlr5y1Ftq3RJt8IQEdXME+JMDHYe8xAtbosx013YaAbbG8yUXa5YMyrt0AwzdgO34SDbfSVKENe5PUL25WOmx57mXOgBs5dNPiuCNNLZrXHcYGJHYdFRYLzsVPdYk3vvqv1kupVddShCfaYgj99AVI17DMKUSbhQpC3sxzKDpqQXGbtlq5QhJdgx0sucb8m2JG+x1vAlNWS4FwSdspDX8BqPECPYqb217vz6phVnCZlAUXsOkUexFiQqlWKkEjXtHYcDaWYFmO2o59m1vEwMmI4YjfDftIsfMGQK3B+okfi8uf1mxWu66sRltf7XnexkihisxIK7b9JV312cg9fX9IHPVOD1lFwmYdaEN5gG4kJlK7gjvBE7Qhb2PRPUwKk919x2iXf0DNfS4532A7b6CBxlaqStyxa3I30n0x6E4L2OCop1IoPeoC/wCWeMVfRtLgBGNQGmQqK1rNVVCCbZSbZjYa2BM9+wdLKiL1AA99tfnCUiIiQEREBERAREQE13EeEUa/6RATawYaMO5hrbs2mxiBweM9DqtK7YapmG+R7KfDTIx8F75pnxb02yV6bI3YDr25TuO1SwnqswYnDJUUq6q6n4WAI8jA87pVlcXRgw7Dt3jlLjNzxL0IRjmoOabdTEsO4NfMPEsOyc7i6OJw36enmQfGLW/fHR/eCmShIMtMw0cYj6A2b7LaHw6/C8zmBjYzFUmVpicQIFdZrsRhEbca9fMdx3HgRNrVWRHWBpH4blvka2bfMM3cb3B07STIZwrjRs5I1GWxF+7MLDbVuqdCyywiBoXo5SucBLWzZQ3Sv3nJmHzvA6LEpY7ZS97gcxbVbHe1rfnvSJFqYBDsMp/V0+Wx8oGnQDMS5010W+pOubMbDXnpeXYOm3SyABWGUs4yg9hdr3Nj2aXkw8OZDmSzG9wWJzAcxY9E3+6JBamysc/RvpbpDMTrfNoGPn3wKIi5WDK5YjTLcBfui4b+PXtK+0ZkCgKq3GmWwOls2W9r8uXdLsGDf+qTMdixAK7/ABM1wdttT2ScnDlXpVmVcx0C3QXY8rasfCBrcimygF3Bvpqee4tZe/Tbxk1eGsyXqOEQAk3tpbX3iSBpcnf85lo4u9lw1LNfUHLYaimwOXa5FW/SPwmdPwv1e4jEHPiXKIfhO9iKimw5dGp2e6NTA5X21NCy0KeepZhexAuBVsD8TDNRItoNRadevoPUxmQvmp0l1y+4rk5SCRu1rG2g33nf8G9GcPhh0KYLXuWYAm5JYkdWpJ8Zu5CWp4PwVKAuOk53Yjl1KPhE20RAREQEREBERAREQEREBERASkrEDneJ+iOHq3Kr7NjrdAMpPah6PiLHtnL430exeH1T+tQfZBfT9g9Nfulp6VEDyWnxFT74yEaE7rfqJ+HxAmdiCLg3HWJ6BxLglCvrUQZtg69Fh94bjsNxOR4h6FVad2w75h9k2Rv9jHwWShpqgkZ6ZtextrrY20Fzr2DWXVqjo2SqjK3VlKt35W3HapIl9HFbFGGnZsSVJuN/hA7oEEywibM41/1T3g8hbr6rDwEjviGO4B0tqOzXnud4EIiW2meq1zfQdg/ntmJLscqKWbYBRc3gW2gryPla58v4zo+Heh+Iq2LgUl/W9637I18DadZw30Pw9KxYGo362i3/AGRv43gcFgOHPUNqaM5Gmg0Hedlm8w3q79o4qYh8psgyKb+4zMLnYG7HrG09Bp0woAUAAbACwHcBMkhLV8L4HQw4ApU1WwAva5sBbQ8tOQtNpEQEREBERAREQEREBERAREQEREBERAREQEREBERAjYzBpVXLURXXqYA+Ivse2clxT0FRulQcoeSuSR3Bx018c3dO2iB47xHAYjD/AKam2UfFup7nXTwaxjAYGviP0NNmH2tlHex6PhvPYpQQOJ4Z6DAWau9z9lNB4sdT4Ad86rA8NpURalTVe0DU95Op8TJsQEREBERAREQEREBERAREQERED//Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRUZGBgZGhgaGBoYGBwZGBgYGhgZGhoZGBgcIS4lHR4rIRgYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QGhISHjcrISM0NDQ0NTE0NDQ0NDU0NDQ6NDQ0NDQ2NDQ0PzQ0NDYxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKgBKwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAACAAEDBAYFB//EAEQQAAIBAgQCBwQIBAUDBAMAAAECAAMRBBIhMQVRBiJBYXGBkRMyobFCUmJygpLB0QdTovAUFiPS4UOywkRUo/EVJDP/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIEAwX/xAAoEQACAgEEAgEEAgMAAAAAAAAAAQIRAxIhMVEEFEETImGhMoEFcZH/2gAMAwEAAhEDEQA/AGvGjRXnrnkCMYmIxoAOTGjSvjsRkRnte1rA6C5IAv3a3kykoq2VGLk6RZvGnPoJjnUMmGupAIOQgEHUEFm2k68J4k21ML4ml+pM4exHpnb15dosmMTBXo1xFt3RfFl/8UMlTodjW97Eov3Xf9FEXsLor132RxiO6W16B1j72LP5Gb5uJOn8PEPv4hz4IB8yYn5L6/Y/WXZy2cDcgeJtImxSD6afmX95oaf8PMMN6lY/iQD/ALJcToLgxutRvF2/8bSfYl0NePHsx5x9MfTX1vI34pSAvn25Kx/Sb2n0PwS/9AH7zu3wLSwnRzCLthqfmgPzi9if4K+hH8nlrdJsOPpMfwH9ZF/mijsqu3gF/wB156s3B6CapQprzyog+Qi9mBsAPAWh9aQnigvg8tXjrH3MNWb8J/QGdLhuOFZcwBUglWVt1YbgzdVJgyns8biaewfLWX8Qs5/NLx5ZOVMieOKi2kXwY95GDHmoyhRRi0V4APHBjAxoFBho+aRxxACS8fNIoV4EkoMfNIgY94AS3iJkYMK8AHijAx80AHvFeDeK8AIjHjGNaMBRRjFeIBGQY2nnR15qbDmV6y/ECTEx0axB75E1cWi4PTJM0nQzGl8HTFicmZDqLdU2F9fqhJ3lEw/QiqyHE0FI6lRaigm2ZTdSFJ0BICWvprNzSa4B9e49o0nno3vmggIQWOBCCwHQwWOFhBZIFgVRHlj5ZKFnL4pjcvUTU7H9r9g5nyjhBzlSJnJRVsWM4mlPcjzNr+G5MqUuP0ybMGTvIOXzuAfhOZVwtzmdrc22NuS/VX4ntnPxgpLsN/pbi/8AfhPSh4mKSrdvszRzSbNtcEXBBB2I1BHdKlZLeEz3AeJmm4pseo50vsjE6EH6pOh5HzmpqpcWmHPhlhlT/o0r7kcuoJiulVPJisPVA0dXpMf6k+N5uKomS6dUCcMXAu1J0qD8LZT5WY+kiLppkNXsVFaPeQ03vqNjqPCSieijCw4o0e8CR48GODAAoo0UCh4940UCR494Me8ACEe8EGK8ACvCBgGODAAo8G8eAEURijGMBGNETALRFD3jGCTBJgBY4JW9nxCmeytTKHle2g9UT809GVbTyfiVQoKVZd6VRT5EhvmlvOesowYAjYgEeB1E82aqTR6EHqimGBDAgqJIoiKCVY7sFFybAdpiJABJNgN5lOP8RY5RshzWJ90aGwJ7zv6bTrhwvLKlwTOenZcs6j8dViyU9SBq3K+1uzsPb2TnV6y0lzudewdp7hORwIOHY5WygXOlwx+iVPO+/kYONplmzYhwnJF67gcuQPfrPTh48ISaT2/bM8ouUqb2I8Rxp2OgAHKUqlRWFwLZ+oyja591gPEeoHOT1K2HtlFNvvFjm8eUo0KfXdb3UKrqednRh52BHkZspJbRo7KEIq0mgaNXMgB+sV/Mv7qJ6JwjE+1oU3OpK2J5svVJ9QZ5gr5SPvk+Si/6meg9DTfCp95/+4/8zzPOlqik+UzpFblvFJr4zkcTwoq03pnZ1ZfzKR+s7+IS4nKqzzkxNHnXA6pail91GU35oSuvpOksoU6fs8RiaXYKmdfu1QHFu4S8pm/HK4ow5Y1JkghQBCnQgUIGDEIAFEIoxgAQMV4wivAAhFBvHgA8cGNeK8ACvCgXigSHFeBCgUBGJjEwSYAImCTGJjXgAiYxMRMExAR4lM9OonNCw8UIYfKb7obiva4Oi3aq5D4oSnxCg+cw9FrMCdr6+B0M7v8ADWtlXEYY706mYX5NdDbzQH8UxZ1Ur7NuB3GujcqJIggKJKs5Hc4vH8YRZEsTuwObl1RpbnfflM5gVzsVcZVABygmz3PaCTp+80fHalMOit7xHWPIbLfxN5HTSmgLgAEDfc/Genhko4kkt2YssqkyrjKS06dgwoprfIBmN+Xf3zKYh6LMFUspJtmYhgSdswAuNe2+nKXuL8VzsbAWGxYBj5A6CcBnV2yMApOiuvVsewMBpY7XtpNuLG4RuXLO2GLS1MbFZkYq4sR6eIMu4gZEC/SKKDzzEl7eWcjzhVrOUZ9dFZvFbg+RK285Qx+JLOe1rkfi+kT3DbwEuc9NNnSTbqyu7XPcBl8zq3wv6iaTh3Sj2FFKNOmGKgl2c6ZmYsbKOwXte/lMqWAF+wbd5O58yPRYyXtpuf7P7eZnj5Hqlvv8lnofDuk6VDlqAITswN0PjfVflLuJSxM83TMvvAi/pNtwLFF6RUm5p2A55Dt6WI8AJzyY0o6o7doky3SWnkxlN+yrSZD96m2a/wCVh6RkaXunVO1GnW/lVUYn7D9Vvms5qGXgezRl8hbplkGPeRKZIJpM4QMcQBCECQhFEI8ChCKKNAkUcGKNAoK8V414ogCjgwLx7wAMGK8ER4wIC0YtIGqwfayR0TkwS8h9pBZ4womLRs8gNSLPEBNedLoxifZ8RXliKZHdmC3+dM/mnJDwcRiTTNDEC/8Ao1QTbtW4e3h1WHnM+dfan0aMD+6uz2YCGogqQdRsdR4Q1mY1mV4vg81Rw5Iub6bldhYnuFpVxSsy5E7BqSdAB2sx+c1HGMEKiXuFZNVY7d4PcZguKY/MMiHqDc9rsPpHu5Cev4jeVKuV/wARkljeuinixQXqtVZm5ogyjzJuR5CcrG4UKAytnRtj+hHZBamzsQNZLgaZbPSbS4uO5hsf75TVNzuuUaN4rdlxiT7N+x/1AJv+IPOJnJ8Tv4dg8PmZ2qVzTyfSQ3XxG47+31nFxdPKdPdO37eMy+XGain0EXvuMTc25fOWw2WyJ73ad7W+ivfvr4yCihBCjQnt5DtbyH96S/g1VBnbY6Iv0iBpe3Z4zhgxuVt8jlKkVcRTdCCSdeZvfxvNR0Oa7PyyLfzJt8jMziMUzsQ1ggBOWwsO++95uujXDzSoguLO9mYdqi3VU99tfEmcc7UbS4Y43W5X6Q4L2lCtS7WRgv3gLr8QJiuG1s1NG7Sov4gWPxBnpGKFrGeaYOl7J61G1vZ1XCj7DHMnwM54JfdRxzx+2+jorJBIlaTKZsMLEIQgkxXjEHeIGBeK8CiS8UDNFmgAca8HNFeIA4rwC0WaABxXgZos0ADvHzSPNFmgB6JT4Fhm97DIPwgD95IOjGGP/p0A55ZcSlfvHeCD6ywUYjRreOvwnmapdnp6Y9HKbopg+2kvkSPkZC/RDBn/AKf9bD/ynbRW7QD4SGuXB6qC3iB8CDHrn2LRHo49XoZg7XFNvHO/+60pUOiOGYHqEW5VHvfvuZ2meq3vXH47i3PRdJD7GoGzK/iG1v4aStUuxOMejnf5Ow32h4O04vS7o3RpYV2osxIsWDNmsFubgeVvObNXe1jk8u34Tl8Uw5em4ZVHVNuemoHwicpNVYKMU7om6H4z22DoOTchAjfepnIb+OW/nO6swf8AC7EWSvhydaVTMPuuCpt5oT+Kb0SSzh9KcSRTyDtsD53v8BbzmAxE9E4/gGdcyjMRuvabbEd+p0mIxVJWuV3HvKdCD4T3P8fOH06X9nC2ptsp8BcLXW43/v8AWXOLYmg7h0TIbkB8wBcX3KW1Gm9x+k4r5kcEbg3HlI8WRmDjY/IksPQ5h5TRNJS1dFOCctRexDFWD+pHbyP6ekgqsAdgVOoB0F+49h/cS/hOHVaydSmzA9trL+c2HxnRodEajC1WoiEC+VAXcgGx6ug7ewnsk5s+OC3aHGNmVqta+VLFt2dwRbkNbeUPDoWPVDVH5KCx+A+U0eKwXDcKTndHcBrB3NQhtMv+nT+idfe5SHE/xBpoMmGw1l7C9kXxCJe/qJ5Ht024r/RensrcO6L4mo6s6BELIXzkAlQRcBBc+tpucfiqNEXrVUTkGYLfwGpPkJ5Vj+luLq3vVKL9WmMg/MOt8ZSwfCsRWOZKbtfUu2i+JdrA+sySlKTtlbI3+O6b4ZbikjVD2EDIv5n639MxXC8XUx2OcBUR6ijq5jYmkoAu7as2W5v3SPF8MNNbCtTepe3s6eaoR4sosCOUPhfB66uK4Ps3U6PmCsCQVOUDW9iRzjhcXZE6kqNeOiGL+qn5/wDiH/lLF/VT8/8AxLfCeMYpFFqvtT2tURQoGmgN1e/eZ3MP0xF8tSidNCaThwO8hstvDWdfrz/By+jBmZ/ypi/qL+cfrBHRfFH6C/nX95vMNx/DObCooY7I4KOfBXsT5Too6t2CL2Z9AvHgeYHozir2CKfB0/eOejGM/k/1p/unp1OmB48wIZyjUkjzgvJl0P1o9nlZ6M4z+Qfzp/ujHo3jP/bt+ZP909XV77X87Q1PMCP2ZdC9aPZ5E3A8UN6D/wBP7wf/AMLif5L/AA/eevNr9GRvTTwh7MukHrR7Z5I3BcT/ACH/ACwTwfE/yKn5DPVgyq2XMP77pNcdlrwXky6H60ezyBuGYgb0Kn5G/aRnB1QbGk/mjftPYGpZt9PA/pE+DB3AMfsvol+MuzyEYOt/Jqfkf9o3+Dq/yqn5H/aeupgl7b+INj8IX+FXv84/ZfQvWXZEaTHW36wTTPaT5D5ydqgt73xjKoJ037d/mZmNRGoI0URnpt4+MnLeHrBNUc4WBWam/ISJ0YcvLUy2xJ/u0QTvEBHNfDk6kytUbJ9If35zsPRTkJTxFNBsov4RoDA9Gn9hxVkvZa1NlA7LjrKf/jb809LvPLumL+wxOGxQGXI6FrDsBGYflQ/mnpuMxlCiM9WoiL2M7qgYWBBW513+EVpDolDTm8X6PpiBmIyP2Ouh/EPpD4984fEv4l4OncUles32FyJ5u9j5hTMhxP8AiVjKlxTCUB9kZ3/O+n9IlRySi9UXTBqzX/5MRVzYivoNTlsijxdr/ISnV45wnC6IFquNRkBqtfudzlHk08wx2Pq12zVqj1DfTOxax+yDoPKXcF0exNUZhTKr9ep1FH5tbeAnTJ5GTJ/KQqSNPxX+JFRwVpUERdNahLtobjqrYA6d8yvEeP4mvf2td2U36oORDf7CWU+YnRo8FwyG1Su1VvqYZc3q50+U62FTJf2FCjQtvUqsKlUeux7pypi1IzGB4DiKoulJgv1m6iW53a1x4Xl6nwaghtVxGdv5eGX2jfnPVE7VbCl9a7Vqt9s/Vpaa3AGgXvsZOKaoqgNTAOy0uq7Hc5TqW27AO3WOkLUyjh8NkI9nhqdG+z4k53PeinQHuF5Y/wAG1YE1HqVyNgWCUyeQQW8Pdlt0YHOiOmbdn6/llF2PgCIOIqISHzrU7LKMgB1BBddAO59IANSRUFl6jILlKaNc6dpUkk76giOFYgugVDszZ8zW1tcHQnxOklyOlmQCmmpIRwTryVuoo1OoMjCZuvSV6jWv10FgO3KTaw0vdb+EBDE5uuodzoOsoyW5giwYd4zQs1rWcJYf/wA0uG8ACCfIKD3xnt7xdUtclAGS47zcE+IHZHRGsWpoVJ3YNuNg2VtX/FYwAOiQwIVBqNc+rea3J8mtJMNizSB9k9S40tS9xe7Jqg8xfeUsZXpLrUqZmH/TdNBp9FQb68zcTm4jjTG3s0FO3fe3gmw840mxXRtMP0orouZ2ouBvmOQj7zrpf8AlnDdPMM5AeyHmbsnky3t5gTy3EVGc5nYuebG/oNhAtK0L5FrZ7thuJJVW9FkcfYYMPMjaWkxB2ZbHyt6zwFGKkMpKsNipII8CNRO3gulmMp6CsXHKoM/9R63xieN/BSydnsudjtb1kVGuWFypB7Rynn/D/wCIdtKtC32qTfJH/wB003D+l+EqWC1gp0GVxkN+V26p8iZDi0UpJnXxADDUEEbEbiRJVROxieYRifMAToLmttEe8SSiqmKvqLH++4aScYjN5cuyMUP0QR56ekFkbcjz3iGOa3O4/Cbesf2w+uI1Nrdtz6STP3QAqigo3Y6eXy2j1MYibuB3k2gVEBPf3DSHTwxO+npKsVD08fSYXDofMQKmOpj6aDzElPDEPvC/iAf0jjhtL6i+ggAFPE022ZT5yQlOayKtwqi3vU0PiolHFcKUA5Aqns6u0T2AvtkHKV6rjl8P3nOw1RwQirmG1xchbcyfkJcfCkmxPwI+V4tVDox38QqGfDEgC6G4ty0Y/wDbbznlLOSbkknQXJubDYXM984pwcPSdBY5hvc3HLQ+E8pq8AGHCo7hX93r6Zzc2IJHaOzXlKW73Je3BnUosdhbx0nc4Tw3DML1TWd/5dNBYj71ybekv4OnSpn/AF6Tk9hDDKe6wt3fW8p23Qsgak1NFBuMjWFh2FwAo81aXUURqZVpI1ID2VClhV0/1HHtKmu13OgvyYxYnCZrO5qYkX1JzhB3otgGHcLyxnR0JNJ3Ydt8x0t1ke+33Ne7skmHYsj/AP7IUctyv2SzL3D3gDtrACNVULnSqlIA7LsLW0Ja1m32APjpHWmWUn/DlmXZy5vvuHfrLuexd95JgDmJC0kqZxYP1ut2fSOY/wBQkSIEa1Qsik5QEJyeR3U93UEQCVhYo1Zw2hCBbNa+312Gh1F766xYUF1ZVSmBe92AFzYnrJuDfsLXvEjmmwNMHISSWdOqO8nVr97AjvhYmiCFqGojHUAWKqb7AMupvyuw7oAR01S5p1A7tYmyOWUemqr963jLANROqwKIQCCUDNbX6mijvII75GyMyArhsuXQtsQCfeWxB8uoTGFSkq/6lQtbcP1d7/QsL7G1wdt4AMiIrZqdq+obUaXNtQ69RfAC8n9g18xIpjUkIbC32mbT4X75z6vG2c5aFMt9phYeSjW3jaRHhtSqb16hI+qNvQdUeOsKFZNV4vRpmyAu3Ndb+Ltv8ZWyYiqb6UVP1bqx+9bUn0nUw2DRPcUDv3PrJ7R7CObh+DUlGoLE7kk/C0hr8DU+4xHc2o9d/nOxaK0dsVGVxHC6ifRzDmuvw3+EpFZt7SDFU6ZF6gW3NuzwO8pSFRjrRWnQxFFHa1ENYblj1fInUec6XCOjr1jdFzjtdrimPA7v5aQeSMeRxg5cHBp0C2osAN2Jso8SZ3uA8A9q6jLmU63fqKQN8qe8w1tc2GomwwXRJEIuwdxbVl6iD7CbX9ZpMBw1afee1jqx8+XdOMsjlwdVBLkAU6oUAdUAAALroBoJYw1csOshBGnjLNpC9M7j/mTZdEobXY+kkzjtMqio23zjmoO0QtBRJUdO0jzNpH7RPrj80AKh8eRi/wAKv9gyqQrZYXDW2ML2bc4atv4Rg459tpLGAUbvg1EYC4O3PaTGoL23Pd+8BRmBzWI003Hme2NCK1Osz+6LjnqBryvvD/wYOrdY8jt6fvLK2HZDzQAr08MF2AHcNAO4QKqiS1Kh7AZHSA3O8mhlVwR/9SlxPhFLEoVqorAjtGo8DO23hKmJGoA948hoO8yWikzDcS6MugHs2DoBbIwGew2sToxH9jtmcGANyyBqbqx6rDXS4DWO4IPaDvsJ65Tw6jU9Y8zv5coGKwdKoMroDyOxHgw1EqMmiZRTPLTxeslkqghbm7otzfsNjcc9rnuE6FCrQNnp5nfS7DUga6Fj7ut9yPCaDiHRhtTTOdfqvYG3INsfA+sy2L4KUe65qbjxU/8AI8LjunVST/BzcWi02Be4cj2d9bJu3e19D45fAyviHpL1gWzDTOrElSexnbqgdzad0qtiXQ/66F101XQea6BvO3hJ8Vx5BYUqZOm2qqPEn9BaVTJsuKldk1qKLG62F7gnnfluVEpnHYamro9FWc2Nwc5vfXW+p+9YicZ6jte5yBt0S6r6f3eClMDYWlLG/klyXwWX4jVNwhKIbWDHOw7wxFx66SpkubsSx5sbn4yW0U6KKQnJslw2LdNFtbcgj9d50qHFUPvXQ+q+o/WcciCRE4pi1GpVgRcEEcwbj1Ee0y1Ooym6sVPcbevOX6HGHHvqGHMdU/sfhIcGOzt2gO4UXYgDmTYTntxQt1aSMzfaGg8gf2gUeH1Kz2Oaq/1U9xPvPsvgNZDqPJSTlwPV4oWOWihY/WI0Hl+9pDQ4ZXrm6qazeOWmvi/6KJtOE9EMoBr2Yb+zTRB976/nNVTCItlTKB2AWt5SHJvjY6KCXJhuHdHVprnxK5iuuVdKa/g3bxM11GkLArbL9nYfCT/4X2mrnT6Itt3m43llKVtBtOen5Olg0bbAD1F5KTGajIWDCF0FWTq0cWkC1JMrxphQNQd/rAC3HYR4yR3XYytTFjZduyGwgnpjQbco3s2/syUhucHrc/gIwJ6Z31vpI2pZhpbeMqMQR2WIkuGpZBaNiI8hzDkP2iZSQbC23z7pKU1vJAIhlJKbg308JIrvfVRaWYxaMQPlGywrxrQAG8dUEYnl/wAQgpiGCUjNSB3h2MZrwER+yy7SCvSR1yOgYd4v6cpZ6x7pFUQ+MBmZ4l0a7aTW+y5uPANv63mSx/CCjWZCjf0nw7D5GeoDUWMapRVlylVZdrEaekSlKPAnFPk8crYR03FxzGo8+XnIgJ6Rj+jIY5qRyH6puV8juJmOIcFZD10KH6y+6fTT5GaI50/5HKWJ/BnrR7S5VwTLrbMOY/UbiQWnZNPg4u1yQ2gkScIToBeM4VSFN2c7ImrHx5f3rFKSjyOMXLghRCxsBc8hLmG4fmYJZnf+WmpH322Wdng3AHqWNVhST6i3zH7z9k3OAWjQQKiBR9kb99+2Z5ZnLZHeOKt2cPg3RLQGtZV/lpoPxvu01mGwaIoVEVVGwAsIyY1DzkwYEaG0512dLJAJUxtIMyLcam5B7VG49SJLdxtYwVOuYjXbXsHIRWFE6JbtklpUbEEQxiBv8o7CiwwlappJFqKe2MUU8oMED7FTuIigGxh+ztttHt3RNDs5+LZgNjuPQkCXKSgQqtEMpB7YKUtBvCgslBEVhIzTi9meZjsQkc9ohrFFBCCtEYoowBJMjN4opLKQRe0hzs3cIoofIicG0kBiilCFaOIooAKCyxRQArVaWsZTFFI+SkMrnlDdAwsRcHcHtiigM4HEOjKHrUjkPLdPTdfKZ3EcJqoevgvbX+kj2HqrKfUR4o02uCWkwsF0Xr1T11FBPqocznuzHb5zQ8N6P0KIsiC99STmJ7yTHij55FxwS4jBKDdR5STD4dbXIEUUpJCLdKmOdpN7S22sUUYB06t97CA1Vb22iiksaJDTEBKKmKKSxkowy8ohhlBuNIooxEmWPFFGALRCPFABXj3iigB//9k=",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9xEhb1_iCNskTOU_YW1bd4jKPSkL4SpW2oHLdnPvM_UKsGkMTLWVbKq-kv_EIcwkKHXU&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0V6nV9m1HrbbA713MiqrZXRHSGyv3X68OGw&usqp=CAU",


        };
        return urls;
    }
    public static String[] getLaptopsnames(){
        String[] names = new String[]{
                "Microsoft Laptop",
                "Hp Pavillion Laptop",
                "Lenovo Ideapad Laptop",
                "HP 15s Laptop ",
                "ASUS VivoBook Laptop",
                " Lenovo Legion Laptop",


        };
        return names;
    }
    public static String[] getLaptopsdescriptions(){
        String[] desc = new String[]{
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",
                "With Mic:Yes,1 Year Warranty,",


        };
        return desc;
    }

    public static String[] getLaptopsprice(){
        String[] price = new String[]{
                "99999",
                "100000",
                "120000",
                "130000",
                "900000",
                "850000",



        };
        return price;
    }

    //CLOTHING

    public static String[] getMensUrls() {
        String[] urls = new String[]{
                "https://5.imimg.com/data5/SELLER/Default/2022/6/DB/GG/RU/25922548/whatsapp-image-2022-06-06-at-4-37-37-am-1000x1000.jpeg",
                "https://www.triumph-sports.com/wp-content/uploads/2020/01/CRKJerCha01-1.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTJ-s0RUvsy2_eHiRKnMP4ifKia2eBHz8kGDw&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRA8yDy4mw1ROQtvQwrocQ9lfSIR4PZa5acYA&usqp=CAU",
                "https://m.media-amazon.com/images/I/61DLZiEPXoL._UY445_.jpg",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEBIQEhIVFhAVDxATFRIYEhUWFxUVFhYWFhYVFxUYHSgiGBolHRkVIjEiJSkrLy4uFx8zODMsNygtLisBCgoKDg0OGxAQFy8lHR0tMC0tKy0tLTUuLTctLS4rLS0tKy0rLS0rLS0tKy0rLS0tLSsrLSstLS0tLS0tLS0tNf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABgcFCAEDBAL/xABLEAABAwICBQYJBgsIAwAAAAABAAIDBBEFEgYTITFRByJBcYGRFDJSYZKhsbLBCCNic4LCJDNCZHKDk6Kjs/AVJUNEU2N00SY0Nf/EABkBAQEBAQEBAAAAAAAAAAAAAAABAwIEBf/EACIRAQACAgICAgMBAAAAAAAAAAABAgMRITEyQRITBFFhIv/aAAwDAQACEQMRAD8AvFERAREQEREBERAUVxSW9XIPJZG3q2ZvvKVKHVf/ALlQfpM/lsWeTptg8ipksF46V9xfzn2roxmrytPUVSMuO1DZpXRTyMBlkOVsjsm1xPiXt22XEU+TW1/i2Dns5gbv2j1f0F6Ydy16bpliA3Vb/RiPtYjtMsQP+ck7Mg9jQn0yn3x+mxd10VVQ1ou4gDiStcptJK13jVlT2VEjR3NcFjqidz9sj3vPF73O94ldfV/XP3/xcuk2llI1rmmdhd5LTnPc26kfI5jMdRRShl7x1T2kG25zWuBAvuNz3FUPhujNbUM1lPSyPj53zgaGsOXYcr3kB1js2E7VOfk71oFbVQ3/ABlKyQcDq327/nPauq44ry4vlm0aXlih+Yl+qf7pUQkdzOxS3F/xEv1bvYofJ4qzytfx+pdGiLL4jfhBIfW0fFWGq/0O/wDoO81LL78YVgLvF4s8/kIiLRiIiICIiAiIgIiICIiAiIgIiIChcj7yTv4zSAfZOX4KYzyhrXPO5rS49QFyoE+QthufGIzHrO0rLJ6b4I7RHTzEtXC+x5xGUduz4qpbbVOtO6j5hpPjTTuaz6uADWHtkfGP1TlBgtKRqHGWd2fJCFvwX0UXbMyjcvrcnSuHILy5Epw7DS0/4ddKD1ZI5e7b7VAeSit/8hic0ZWzmu2cA5skoH7o7lJ+RSovS18A8bWwEfrmujv/AAyo5otS6jSxsW4MraxrRwa6OYsHolqT0NhcTbeCUcYpPdKhkh5gvwU1r/xUn1b/AHSoTKeaN24Lz5Xp/H9mgwBrZzwpwO94/wClPVC+T1l5KuTovCwfZDyfeCmi7x+LLNO7yIiLtmIiICIiAiIgIiICIiAiIgIiIPBjzvweQeU3J6ZDfiq/0klcG6tgvI5zWMbxc8hrR3lTTSmTmRs6TJfsaD8S1RemaDilJm3EyZR9MRPIJ7iesBZW5s9WPjHtV3KvGIq2KkabtpqKCLre4vlkfbi4vBUMClPKnJmxmuP+7EPRgib8FFrLaHlEXICEKjkLhGrlyCz+QbbPWDoyUru4z29qxdHUh2lok6DiTmDsjdH7VkuQl1pq49Pg0FuvNIB7V4p8P1GlkEZ8V1XFK3z6yMOJ9POOxJ6F+4ifmZPq3+wqH1cfN+ypVjUmWB542HeQFF6l2wcLH1rDJ29OCONsloNSZIZXdL5yeoBrQB7T2qSLB6IOvAfrT7rVnF3Xpjk8pERF04EREBERAREQEREBERAREQEREEI0ixDNMTfmtcI29/OPab9gC6MAYZcRY4NOWCN73PtsDntdG1t+JBcewqP6aRObLTsDS4Nq2NvfbzX3BI6RYKYaDV7c1RC4tbPrhJkuAS3IxtwN5AI28Mw4rCvNnvyx8cXCg9Ops+KVzvz2ob6Dyz7qwRKzGl2zEa++/wDtGtPfPIQsM8r0PA4a9dgK8Tgb3C9EZ2IO5cFcBZKnnhja9t3PL2gEiNrS0dIbI4ki+482x4biqJryFzgV08R/LpC/9nJH8HFduMVgl0vpgN0UtPF1nVuk+/bsWD5L6trcYp8oyseyoY4Zr83USP37L7Whemhu/SuMnea1jj+wDknoXZpHVXkZCOhpeevcPj3hYWvdsI8w/r1Lt0hkDatzr7rAjh820/8ASwlbi7LB2be8NA897bl5rTy+jjp/iEk0DqCTURHc10bh9rMD7oUtVfcneIayqqGgWAj39JLS2+zzZvWrBWtOnjzRq8iIi6ZCIiAiIgIiICIiAiIgIiICIiCIaZaOOlOviF3gh1rXLXAWztHTs2EKAUeGONZrKhjZTnDWtL5IpBKTa92vaDckC5vYjcNyu5fL2A2uAbEEXF7Ebj1riac7eiv5ExX4zG2rvKRTOjxWsDm5S6US2uDbWsbJa432LiOsFRohWNy70mTFGydEtJE77TXSMPqDFXJWjzushIt9l9FdchsO0IPQFzdcBcqiS8nDf7zgd5Dah9uPzEjR6yFncLZl0tiDv9Vg7fAre1YbkvkAxSEdLmVAHWInPHurMYxJq9J6F/QZqIem4xJPSrQ03hLH+EENEWUMJubl9nW2W4Ai9/JUCjkztp2xsL3a5zy2NpebCV3QNu+3ernxLDop2auZmZmYOtcjaNxuCOJ711YXglPT5tRCyPNbNlG+24eYbTsGzasZpy9Fc+q60wuhGi5pWmaQk1ErbuZstFms5zBbxjcDb5tnnlSIu4jTz2tNp3IiIqgiIgIiICIiAiIgIiICIiAiIgIiIKR+UNF8/Qv8qGpb6Loj99VIru+ULTfg9FNbxaiWK/1kee38IdypG6o+Xm25dEw2DrXe5dMu8dvwSR3xuuAvte/EcKMMFFJawqKR0vW4VEzf5Yh714EEh5PHWxWj88krfShlb8VmuUR2qxminOxrfBXHzauocSe6yj2g8gbidET01cLfTdkHvLOctrAKiDjqJb9kht8VfQ2RRebDKnWQRS+XFG/0mg/FelcgiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgg3LVAHYNOSLlklM5p4HXMYT6LnDtWt62f5UqcvwetAF8sGs7InNkPqatYFYHy5dEnHgCV3PK+Wszua3yi1vpG3xQW7yr4LqsIwd2XnQxx07j+nAHG/W6L1qqVtDyjYN4VhdTA1t3iLWRjpzxEPa0deXL9pautOy6QMho5LlrqN/Q2tpHHqEzCpZy3NvXxDo1Dh3PddQeCbI5snkOa/0SD8Fd3KhogyppzViYMnhZM+1swfEec4WG3O0C4tv2jpuL6E/0PbbDqEHeKGlH8Jiy68+HmPVR6pwdEGNDHNIILQLCxG/YvQuQREQEREBERAREQEREBERAREQEREBERAREQeXFC3UTZ25mamTMzym5TdvaNi09iPNHUPYtv8AGmk004b4xp5gOssNlqDG0ZRY3FgrAFd2Gi9TAN16iAd8jV0OavukdaaJw3iWIjrDwUG5K1Q0zwg0mIVNMW5Wtme6MWsNS8l0WXiA0gdbSOhbXqtuWvRLwqk8MiH4RStc4gDbJBve3rb4w6nD8pQa9zNuCL22LMaT6Qy1TzZzmQWAbEHm1rC5fa2Yk337t3Xh73XyRxHcqJ1yKY/JTYlHTZyKepLo3sJ5usykxvA8rMA3zh3mC2VWmcE7mObJG6z2Pa9juDmkOaewgLbzR/FG1VJT1TdjZoY5LeSXNBLesG47FBkEREBERAREQEREBERAREQEREBERAREQEREBahY3StiqqmFviRVM8Tf0WSOaPUFt6tRNICTWVZd4xrKou69a+6sDH3XfhUeapp29Dqmnb3yNC6V68CH4XS/8ul/msQbfrghcooNZOVPQ/8As+s+bH4JOXyQ/QN7vi+zcW+iR0gqGC/WFtRyiaMDEKCSAfjm/OwO4StBygng65afM6/QtWBfpBB3EbiCN4I4qj5Nlfvyf8a1tDLSOPOppbt+qmLnj98S+pUE5WPyBV2TFHxX2TUkgtxcxzHt/d1ig2IREQEREBERAREQEREBERAREQEREBERAREQFqVpazLiNcOFfWfznlbarVTT+PLitePzyU+kc/xVgYBZHRWPNiFC3jX0Y/jMWOUh5NIs2MUA/OM3ose74INqURFAWr3Krg/guL1LQLRykVLOqW5f/EEg6gFtCqi+UJg2aCmrWjbFI6F/6Eu1pPU5tv1iCjXLJaKYsaSupaq9hFOxzvqycsg9AuWOcF1PF+6yo3TRYXQuv1+HUc5N3PpIC4/SyAO/eus0oCIiAiIgIiICIiAiIgIiICIiAiIgIiIC1b5TB/fFf/yB/LjW0i1j5WKMx4zWXNw90co6nxs+IKsCIKV8kQvjlEPpVB7qaYqKOKmXItT5sbpz/px1Eh/Yuj++EkbMoiKAsJprg/heH1VLa7nwuyfWN50Z9MNWbRBpgDcAgbwvhwUp5SMHNLilXFazHSmaP9Cbn7PMHFzfsqLuCo2O5Ca7WYQyO+2Goni7C7Wj1SBWGqZ+TlXcyupj0PgmH2w5jvcb3q5lAREQEREBERAREQEREBERAREQEREBERAWunLnFlxdx8qkp3euRv3VsPUTNY0vcbNFui+82GweeyqvlF0VjxKqZURzmNzadsRvFmByve4bC5vlHvTcQsRviFFkKZci0pGN04H5TKlp6tS93taF2YjycSRZb1LXEuAtqSOgnfnPBWVyV8ntNTshxAukfVWlAJcAxty+M5WgC92+UTvUi0T0s0mO1mIiKuRERBTnygMBe/watjjc7K2SGUtYXZW3D4y625oOsFzsu4cVSrYXOPNa49QJW5Uz8rXOtchpNuNheypuqwinfJJM7Y58j3loOy7nXNh1lSZ0sa9yhWhtBUU+epZK+KWzcuRxBytcHOD+hzTYc03vboWytDVNljZKzxXtDh29B86pqaiBieyE84NLbWsdo3W6VYWgWIsMb6MG76c2v5TXc7MO0kd3FSsz7d3iIiNJUiIumYiIgIiICIiAiIgIiICIiAiIgIuCVHdJMRLmamFwu7Y99yLN6Q0gbSeKCPaQ4y+aaSLZ4Ox9m2OwluwuOzndOy6xmscXxZXgNY67m2N3DKQBftv3Lvm5uw33WtmJ2DcsVUVFto2Lqa7gidTt6sekdI5rWAkNsb5TtJ4eYXUj0Or5tcylaWmCKFzpObuJJygEdJcT5rMKr+bE3E2D9vAW+AWc5Nasx1kwcHfPQt5xB2ujcSBc9NnP7lxFNNLZPlGltZkzLw+Er6EqrN7My5uvIJF9axB9V77RSG9rRvN+FmnaqbqYjY+Vm2l18oBO02B37dl3BWXpTWFtO5jfHk5gF+j8s92ztCgBAudhzjNtDXbiTuIAHWLneL2VgY2orHMFmtswNAuBtcbb+B/rzKRclNO8zyS9BjfnP6ThlH7p9FR2qDSA3d5+jr+Ks7QSiEVDEbWdI0Su+0LtHY23rUkSRF8gr6QEREBERAREQEREBERAREQF1VUpaxzgLlrSQONgu1EkV3X1U7jd73uB2gtvk7AFi5at3+4eprj7FZNVhELzcssb3Ja5zLnicpF+1eduBQjocet7vgpWbRGpTlV1RUP25YnnzkBo9e1eCPD55iOa9zeEbXEdrtyuIYRCP8Jp6xm9q9Hg6u5VXFBgMzW2bDl7PaDa/qXrocBqdbG5wa0NkDiQd4G21r9KnogX0IVNT+x4WR2XYLr2CJc6pdDxri5Xt1S4MSCA47UZqp2/mBrBtIG652A8Se5eCWqtfYOvp9amk+joLnua+2dxcQWZtp89wsXNoIxxuZTv3WdbuzriLTvmEQGrc2R2ra0ule4NbzidpNhfgrlpY8rWsG5rWtHUBYLDYPohBA8SDa8buaGtB42337VI2sXSuWhfSALlAREQEREBERAREQEREBERAREQCuCiIOEREBERAXKIgLhEQFwiIOQuQiIOUREBERAREQEREH//2Q==",
        };
        return urls;
    }
    public static String[] getMensnames(){
        String[] names = new String[]{
                "Long kurtha",
                "Levis Sports wear",
                "Blazzer",
                "Blazzer",
                "Causual Wear",
                "Sports Track Pant",

        };
        return names;
    }
    public static String[] getMensdescriptions(){
        String[] desc = new String[]{
                "10% Offer",
                "20%offer",
                "20%offer",
                "20%offer",
                "25%offer",
                "15%offer",


        };
        return desc;
    }

    public static String[] getMensprice(){
        String[] price = new String[]{
                "8000",
                "400",
                "5000",
                "5000",
                "700",
                "1000",
        };
        return price;
    }
    public static String[] getWomensUrls() {
        String[] urls = new String[]{
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_XMsbViIxHf60H4tUsTVILc2vV-fkPyMnCQ&usqp=CAU",
                "https://rukminim1.flixcart.com/image/612/612/xif0q/sari/0/m/c/free-minal-creation-women-s-exclusive-kanjivaram-silk-saree-original-imagh4qxxyhbjhyv.jpeg?q=70",
                "https://cdn.shopify.com/s/files/1/0490/1158/9282/articles/sundari-silks-choose-perfect-wedding-saree.png?v=1645704076",
                "https://cdn.shopify.com/s/files/1/2482/1950/products/Lakshaara-19-09-226232.jpg?v=1663965687&width=533",
                "https://m.media-amazon.com/images/I/81rDWuu7GhL._UL1500_.jpg",
                "https://m.media-amazon.com/images/I/81JK6SZoKlL._UL1500_.jpg",
        };
        return urls;
    }
    public static String[] getWomensnames(){
        String[] names = new String[]{
                "Kanchipuram Sarees",
                "Uppada Patu Sarees",
                "Traditional Sarees",
                "Panjabi Dress",
                "Chudidar Dress",
                "Chudidar Dress",

        };
        return names;
    }
    public static String[] getWomensdescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "10% Offer",
                "40% Offer",
                "10% Offer",
                "25% Offer",
                "30% Offer",



        };
        return desc;
    }

    public static String[] getWomensprice(){
        String[] price = new String[]{
                "8999",
                "9999",
                "5000",
                "4500",
                "3000",
                "2500",
        };
        return price;
    }
    public static String[] getKidsUrls() {
        String[] urls = new String[]{
                "https://images.pexels.com/photos/1620826/pexels-photo-1620826.jpeg?auto=compress&cs=tinysrgb&w=600",
                "https://images.pexels.com/photos/1493108/pexels-photo-1493108.jpeg?auto=compress&cs=tinysrgb&w=600",
                "https://images.pexels.com/photos/3227268/pexels-photo-3227268.jpeg?auto=compress&cs=tinysrgb&w=600",
                "https://images.pexels.com/photos/15298312/pexels-photo-15298312.jpeg?auto=compress&cs=tinysrgb&w=600",
                "https://images.pexels.com/photos/5560019/pexels-photo-5560019.jpeg?auto=compress&cs=tinysrgb&w=600",
                "https://images.pexels.com/photos/1648535/pexels-photo-1648535.jpeg?auto=compress&cs=tinysrgb&w=600",

        };
        return urls;
    }
    public static String[] getKidsnames(){
        String[] names = new String[]{
                "Kids wear",
                "Kids wear",
                "Kids wear",
                "Kids wear",
                "Kids wear",
                "Kids wear",


        };
        return names;
    }
    public static String[] getKidsdescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",
        };
        return desc;
    }

    public static String[] getKidsprice(){
        String[] price = new String[]{
                "2000",
                "2999",
                "2599",
                "1599",
                "1299",
                "3000",
        };
        return price;
    }

    //HOME APPLIANCES



    public static String[] getFurnitureUrls() {
        String[] urls = new String[]{
                "https://i.pinimg.com/originals/2a/5f/21/2a5f21482c482d271977ac0bf2da371d.jpg",
                "https://m.media-amazon.com/images/I/51dx6RUA+BL._SL1000_.jpg",
                "https://www.ikea.com/in/en/images/products/gammalbyn-2-seat-sofa-blue__0865034_pe781333_s5.jpg?f=xxs",
                "https://m.media-amazon.com/images/I/51K6H4Nl-4L.jpg",
                "https://5.imimg.com/data5/SELLER/Default/2021/11/GE/ST/PD/136730391/new-product-500x500.jpeg",
                "https://cdn.shopify.com/s/files/1/0096/4594/9013/files/Swing_Chairs-5.jpg?v=1655964757",

        };
        return urls;
    }
    public static String[] getFurniturenames(){
        String[] names = new String[]{
                "Sofa",
                "Wood Furniture",
                "Comfortable Sofa",
                "Marble Dining Table",
                "Single Cot Bed",
                "hanging chair",



        };
        return names;
    }
    public static String[] getFurnituredescriptions(){
        String[] desc = new String[]{
                "40% Offer",
                "20% Offer",
                "45% Offer",
                "41% Offer",
                "20% Offer",
                "30% Offer",

        };
        return desc;
    }

    public static String[] getFurnitureprice(){
        String[] price = new String[]{
                "25000",
                "30000",
                "21000",
                "38000",
                "25000",
                "15000",








        };
        return price;
    }


    // Appliances

    public static String[] getAppliancesUrls() {
        String[] urls = new String[]{

                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUSFRISEhYVGBESEhgSGBISGRISERgSGBgaGRgYGBgcIS4lHB4rIRgYJjgmOC8xNTY1GiQ7QDs2Py40NTEBDAwMEA8PGBERGDQhGB00MT8/NDE0NDE0MT8/MTQ4PzQ/NDQ0NjExOj80MT8/ND08PzExPzExNDE0PzExMT8/P//AABEIAP4AxwMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAAAQMEBQIGBwj/xABIEAACAQIDAgkJBQYFAwUBAAABAgADEQQSIQUxBhMiQVFSYXGRFDJCcoGSocHRgrGywtIHI2JzlKIXM5PT8FNUw0Njg7PxNf/EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/EACARAQEBAAICAQUAAAAAAAAAAAABEQIhEjFRAwQTMkH/2gAMAwEAAhEDEQA/APs0IRGA4RQgOEUIDhFCA4RQgOEUIDhFCA4RQgOEUIDhFCA4RQgOEUIDhCEAiMcRgcswAJJsBqSZi4/EGpyRcJ0agt39nZNHGWNgwuN9rka+yV8qdT4tLBmDONzG3sjzP1j8JphU6nxMMidX4maRm5n6x+H0jzv1j4D6TRyp1T4mGVOqfEyDPDv1j8PpHxlTrn4fSaGVOqfEwyp1T4mBn8ZU65+EXG1Ou3wmjlTqnxMMqdU+JlGdxtTrt8I+Mqdc/CaGVOqfExZU6p8TAocZU65+E5NR+ufhNHKnVPiZyQnV/uMDPLv1z8Iszn0jL5ydT+4xZk6n9xgUTn6zeM5Kt1m8TNDOnU/uMM69T4tAzGpk7yT3kmauBxpACubjcG3ket9ZzdOoPFo+R1B4t9ZBrAwlTBN5ygWAAIGvPe/3S3MqcIQgERjiMChj0JK2ZlsPRy6+IMwtr7Up4QIatWryyQoREqObWuQqpc2uN2s38bvHdMzGYGlWy8aivkbMuYXsd2k1PSEtdCVUVnu5YLyadiVJDC+Sw3HvsbXlkUz138Kf6JGMKmbPkTOCWzZVzZjvN7bzJC43c9r257Sg4s9d/Cn+mcuQvnVCPW4ofevYZ2rX3eHP4ewzkOrXtlOU2NrGxHMegwEgzarUYjs4oj8E5YEMAXbLkdjcU/RKfw9pndN1IutsvZunFZgGF7W4t73Nha9PeeYdsDnj0/63xpfpk3Fnrv4U/wBEroSALBLE3vxjtp0glZFjMZktYEksECA+c55m5wACO82HOLlXeLPXfwpfoi4s9d/Cl+iUagqhcwFMtvyWGU9igDMD9o27dxMBjxUUHXUHRm1DA2Yabxfceca9EC7xZ67+FP8ARKW1MamFpvXrVXSkgBZ8qtYEhRoqEnUjmnVRgDYEaC5zVnUg93RqPETA/aVrs7F83JTU7v8ANpwiuf2hbN/7x/8ARqf7U4P7Qdm/93U/0qn+1PjFDEIisq8VZlKnOHZrsoAKnJpY3PtlnGbTVwFGQAVA9nLupAvySMguNfYAAJzvLlvU6V9af9oWz+bFOf8A4nH/AIov8RMB/wBy/wDpv/tT4i1JSf8AMTU30FS34ZLhQiMGZkYD0SHynvBQ3G+a0fctncOMFiKtOjTrualRwijI4ux3alABPVCl/G/iB8p8F4NYim+OwJRUVlxCaU84uCecZRc+3p3z71Tbd3SxGhsxbF9WOinlG59KaMz9m737l+9poSVThCEgIjHEYFDHnUd3zla8sbRPKXu+cp5h0iaiKGPxFZGORqWTSwdKjN23YOAfCQO1V7F/J276VQ/+SazKjecLnpuIuLToPjKMk03IAIw5AFgOKqbibkf5nTOAHVs4FANc6hKgOtwdeM7TNni06D4xcUnQfGBxg6ZRbHLvJAQMoAPYWbW9/GOq9mU634t9wud9PcJKzDm3SFjy19R/vpwCm5O8vu50y/KUcdmVlqKCxpsWKi2tNiM1hvLXUf8ANJpXkdRb+zceeBQfbdEC4bM2tkAbOWHogW3/APNZxsai6glxZ2Y1GUWIBICqNNQcqi/Ne+/fLfEm97n4X+6WEAAsIENSpqfO6P8ALdtem/OJ5/8AaT//ADsWN3JTXm/zac9RKW1tn08VSehWUtSe2ZQWQnKwYaqQd6iQfnvEYfDcUChq5z5rMp4tm0uL5d2hta3bMcoRe4Ohsew9Bn31uAmBKpTKVDTQkqhrYgopJJJVc1hqSfbEnAPAqGVUcK/nKK2JCvv84B9d8mD4fsxKfGIa4bicrMcua9rEA6a2zCR5ELsQSKIqaHlXyFjYA2Nmyg7xzT7lS4CYFCGRGVlBVWStiFYKdbXD9JPjOX4A7PYsWpMSzZmLVcQSza6k59Tqde2MV8y4O0Ka7QwIphlPHpmRwwI00YXA0Op38+k+8UGBAIII6RrPPUOCGDSqmIVDx1Mhlc1KrEEbjZmIPhN+gioLAi2/XL8rSwauzN79y/e00Zm7LIJe3Qv5ppSUOEISAiMcRgZe1qVyh57H5TO4nt+E1tp+h7flKE1BBxJ6YuJPZLEJUVuLPZHkPRJ4E2gQhT0H4Tk6EsQdwAGnt8fkJdSiTq3JH9x+kkTKvmgX6x1bxgUkR28xDbpOg8TH5JW/9sd7E/AS0+K6TImxQ7YEPkVXrUv7/rF5LWHUb1W18DJfKx0GMYodsCo+dPPQjt3jxGkQcNuB+E0UxHQZzUpo+pFm6yck+3mMDPKHo+6cGk3RLVSmya+cvWG8d4iVwYFbiG7IeTnsnltrYq1aqgd84fSmquzHOXy5co5XmNfmAGtpawu0hSwmKrhyQiXBYEMrjOnKW1wQwsRv0ktyNSbZPloV8fTRhTzEuSRlRWYggZiCRoDbW17ybZ+Jp1xmpvmtvFirDvU6+2eU2fUoKGNaniGp57pTfjhZmVQzlqa8pmYkb9PbOae0EoVqTqK/FcZTpJmV8iU6jhXRiygvqQQbdHOJwn1efl3Onv5fQ+3y8ePO+Unu+q+obFp5Q/ePumpM/ZQ0f1h9wmhO1fPOEISAiMcRgUNp+h9r5ShL+0/Q+18pQmogigTOSZQyZYpU8vKbzvgO7tiw6ekd/N2CRYitA7rYiU3rEyN3nkducLUplkoZXcaGof8ALXut5x+F+nUQPVvWCgsxAUb2JAA7yZlV+EuFQ2NVWPRTD1PigInzXGY6riDd2Z3Ui+YnIha9rjRUuAdBc6HSJME1uW7erT5IHZr9BA+ijhXhus/fkqfSXMNt/DVNErJc8zE028HtPl/kidZ795vOXwTWuji41y1Nf+ewGB9lDSVKpHbPjOztv4jCEKCVG/Ixz0WHYObvHjPoXB/hNTxVkPIrdQnRvUPP3eF7QPWJU5xIK9DeyDvUbj2iRK1pZp1IHj8dsNqtR6gzBmIsytSsArVCOS6kG/GG4IO5SLEXm7wZ2caHIYGzML5irFiSxYm2mubcAANwAAEuYullOdfNO/v6ZNgXu6esJnl+tWPLbU4OYBKz1MM3F1SbVMPROSmTe2bLbklbnRSBfm330uDGwcDR4ypRYVsWysz16lmqi41y2UBRqBoBfnvL2Iw6M1XOt2DuyDldJ7LeBlrZtAKrtYD92ygBr2HRawtuE8/lczTvWjsvzW9f8ol+Udl+a/r/AJVl6egOEISAiMcRgUNqeh9r5TPM0Nqeh9r5TPJmojljCmtyBzbz3TljJsNuJ6T8BKO8Q9haZ1V5YrvvmLtzH8RRqVdMyrZQdQajHKt+y5BPYDCvOcKtt3Z8NTJAUfvWXzmY+bRQ9Jvyj0X6CJ41sLmDsx8yw0vlVmBy/wBoJ8Bpe8546xJYljcsTflMzasTzk83tbpl6qTxdMNq9QvXbeAM+VVFu5M3c4hE+yUXJWRQbLTz2te5Dpck85teWsBgXrOtNVIzHViNAo3kyKgxpYerVsAalqCA3sSxzOd/Mqj3xINmbeq0XFRVQ2uCpUi6neLg3B7fvhXsH4I0stlaoH6xKkX7Vtu7PjPK4jDtTd6dRCMhsbBip9tt09bV4aYfIWUVC9tKbKo5XMC17W7de6eIxm06td2Yqheo18qIb3tuAuTAhxDI2mUhb36LHntKS0zSIytcAkqRo6ZbG7Ac2oNxobXFjcDTXA4jeaYX+Yy0vxsJewWwxWJV6lFWyspC1qD2uGKFrObgPlBHQx7IHqeCXCDylTTqH9/TF79dB6XrC4v03B6beoSfKdh4JkxWFSnURqjOCzUmWoqKoZmD2NtUV1I5rjpn1phYWHt7YRIpzKQd272SnhnyOM17I3ttzSwhsZXxosVbp5PzHzk9zBNtlvKUNPVVLA5gSGsL9G7f0y6MaSrKy25JUEG+tra3mbSaTic/xzM+F3+tTZXmv6/5Vl6UNk+a/r/lWX5qhwhCARGOIwM/ano/a/LM5po7U9D7Xymc01EcNJk0Qd0rtzya/JHcJRBUM8N+0bE2p0qY9Nnqe6Ag/wDsPhPdOt54D9otMZqBJsvFuD3Z6eY+zSIrxLBiGCZmJIFlGhN9LndvmmyM+IakBy1qDDgc16dqY1+xvlfD02RKiJfPmDAgXsy3IPbqbWlvE1Vp1KtXlFq44+kRbKVrIrlib8xdha29TftDvbmLV2SlTN6WHUorddybu/tbd2ASnSSQ0UJ3T0WGwiYVRXxADEi9KhfV25me25BvPToOeBC2zkpItXEllFQXSiluNdeuSdET+Igk8wO+Y+JxpY2RVRLWy0wQSP4nJLP7T3ASbHYp67tUqMWqOd/wAA5gNABJV2RlGaq2XoQaufZzQM/DYUMQOc8wBJPsE2U4MvUR1ZTSQpm4yspC3UZrKguzGwbTTnPNI8FtJ8PyqOVL6Z8oZresd3sv7Jd2XWqVPKXqPUcpRNMGoWBFWsRTVQpvbzm103brQNP9newkp1q1YMHyUlRRlZWU1GuS580tZObTlHpnv2E83wGYFMR08aPDKCJ6RoRwJDjPN7iJL090hxZ5DQOcO0tLKOHMuCSjV2R5r/zPyrNCZ+yPNf8AmflWaEzVOEIQCIxxGBn7V9D7Xymc00Nq+j9r8szjNREDmSIxsO6cVIUzKJLazyvD3A8ZQDAaoxW/Qrjf7yoPbPVAyPH4VaqPTa4WohUkbxfcw7QbEdoED5Fs6qTYi4LGzEaG/T2bibdk6x+GzrxIH77DZ3pgXPGYdiXqUl6XRruo51ZgNRLD0Dhqrq4A5RVgLZVfS5F/RbRh2FeYm1LarEFGBOhzJUS6kMDprvVgfbe8KjweLVVDDVd4HTFUrvUfMxLMdOnToHZMOviXNQkWNRtWCrYO28tlGgY6k2sDvmnSxj0kDVKdRFYD95lORgQDYPuI9v3SDawVMU+USoqcm2a4IDXtl0NtA2vZIsRVvdubfuOtrkHM/Paw3aEzKO3U3ZzbdbM508Y2rVGRqtOgxpgE8bUQqgG64ZtCey5MonclyEW7VHIRVQZmZzYAa9IvzdE9jRwIw9BaVwSCWd1uc+ItkaxG9KaEpfndr6FDPL8H8UFJKKxqNyTVuFcA6FKQGlIHQF7liNBbm9JRxO96hXkrlCLpTUAWUeqOrz8+/UNHgdiMlWpTaw40DKOlkvu15wT7pnrmM+a7EpPiMTTqU9FptyD/AAi3GOR0W0HSSvWn0i8lQm3HulHEtp3kS3VNhbp1lDEtcgdGsRUuGl1ZUw6y2IqNXZHmv6/5VmhKGx/Mf+YfwrL8zVOEIQCIxxGBnbW9D7XymbNHa29O5vyzOM1ERuJEGsZOZXqLKJwZKh5jKlN+aTo0DG4TbB49eMpgccgtY2CugvyCeZhc2PaQdDcfNMTTdDUVRzkNScHMp3WIOv8Azn5vtKt0zK23weo4vlNdKoFhVp2D26G6w7PAiJR8LqYZWZjcqxO5idD2H/8AZo4PaeJoElSSSACw5LkDddks3xntanBapRfNWoDFUgCM1A5H1FgSnnXGp00lXyHBA243E0Du4uumdAe4jWMGG3CzE2tkcHpFTGX/ABzMxe0MTXJLX1GUk+dl6GZtSJ7ZcBhV34ynb+GjTVvgLzhMJgyQFOKxTA3FNQwS46LDSMHjtmgU7h2JN9BTNte+2vsm9hsO9dkp5TZjyaKWzv63QOfXQbz0T0NHglUq1DUWkmFpPY2P7yroADlUaLe1zqNTfsnsNkbHpYZStNeUQA1R7Go/eejsFhAi2DscYdLGxqMBnZfNAG5Ev6Iue8kk77DSxFvDn7J2zgaCZ9erfQbvvgcVqm8nd8pRTlNfphiKlzlG7n75PhkhVqksmkaCdyI19j+Y/wDMP4Vl+Z+xvMf+YfwrNCZqnCEIBEY4jAzNr76fc35ZnXmjtjenc35ZmzUQSN1kkRgVXW07SpO2WQskoso8mVpnhiJ2tWBpI9p02RtHUEdoBEoLiJIMQIE4wmHGoppf1F+klDKosq2HZoJU8pE5bFCBbd7+yQvUsJVfFHulV6/tMKs1a9926UKta+i+MGzNv3dEkSlA4o0peRbTlEkkBiO8UUiNrY3mP/MP4VmhM7Y3mN65/Cs0ZKpwhCQERjiMDK2zvp9zflmaJo7a30+5vlM4TUQxHOY4CInDCdxGBEUnBSTERESiDi4ZT0ya0RgQWbs8IFT0/dJooEJpdOsYSS5YwkKjCSRVnQEcIAI4QkBCEIGzsXzG9c/hWaMzti+Y3rn8KzRmapwhCARGOIwMrbO9O5vlM200tt01bJmUG2bzgD0dMyPJ06i+6v0moiaEh8nTqL7q/SHk6dRfdX6QJYjI+ITqL7q/SLydOonur9IEhinHk6dRPdX6ReTp1E91fpAktFaR+TJ1E91fpDyZOonur9IEloWkfkqdRPdX6Q8mTqJ7q/SBJaFpH5KnUT3V+kPJk6ie6v0gSWhaR+TJ1E91fpDyZOonur9IEkJH5KnUT3V+kPJk6ie6v0gSwtIvJ06ie6v0h5OnUT3V+kDe2N5jfzD+FZozN2IoCMAABnOg0HmrNKZqnCEIBEY4jAy9s/8Ap/a+UzDNPbO9O5vlMomaiAwihAcIoQCEIoDhFeF4DhFCAXnIAOpAOp36886nCHT2n74HWQdA8BK1bBKxJuwvvC5bdGhIuvsIlq8V4UZB0DwEWQdA9mh8Y7wvA5Q6dxI8CR8p3I6e77TfiMkgbWxPMb1z+FZozO2J5jeufwrNGZocIQgERnHFDt8TI2w45r+80DN2+xHF2/i/LMU1yJ1wu4P4nFoiUmVQlQVb8bVQsQCADYbtZ5/ZHAbG08QmIqOjIoP7rjqpUkqV1GWxGt+m/PLo3fKI/KO2blPYqEctSD/C72jbg/RP/U99/rGjB8o7YeUds2W4M0Dz1fZUqD5yNuCeHPPX/wBaqPnGjL8o7YuP7fumg3AzDH0sR/r1h+aRtwGwp9LE/wBTiP1Rop8d2w44yweAGE62L/qsT+qL/D/CdfF/1OJ/VLog44xceZY/w/wnXxf9Vif1Q/w/wnXxf9Vif1Ror8eZwlc2385++XBwAwg9PFf1WJ/VJF4C4UelifbiK5/NGiicR2xeUds014GYYc+I9tesfzSReCOHHPW9tWofnGjH8p7YeU9s3F4L4cf9T21Kh+ckXg5QHM3vtGjzqYk695+8yQVzNnE7GCj93TDnoeoyj7jPnZ4DbSvUAdsrsxDHEszC+7XKLW+/ojR9O2A16bH+M/hWak89wd2bWo0KVKtcvTQKX4xnZiOcmwm0MOP4veMyJ4SPih2+JhAkhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCEAhCED/9k=",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFRYZGRgYHBkYHBwaHRwcGhwcGBoaHBgcGBwcIS4lHB4rIRgaJjgnLS8xNTU1GiQ7QjszPy41NTQBDAwMEA8QHxISHzYrJSU2NDQ0NjY4NjQ0PTY0NDQ0NDE2NjYxNDE2NDQ0NDQ0NDQ0NDQ0NDQ0NDQ2NDQ0NDQ0NP/AABEIAMkA+wMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAgMEBQYBBwj/xABIEAABAwEFAwYJCgMIAwEAAAABAAIRIQMEEjFBBVFhIjJUcYGRBhYXU6Gx0dLwBxNCUnKSk7PB4RUkNBQjM2KDorLxQ3Ojgv/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAtEQACAQIFAwMDBAMAAAAAAAAAAQIDEQQSITFRMkGRBRMiYXGBFCNSoRUzwf/aAAwDAQACEQMRAD8A9mQhCAEIQgBCEIAQhCAEIQgBCEIAQhCAEIQgBCEIAQhCAEIQgBCEIAQhCAEIQgBCEIAQhCAEIVZtLbd3u5a22tAwuEgEEyBTQICzQqDxxuPSG9z/AHUeONx6Q3uf7qAv0Kg8cbj0hvc/3VzxyuPSG9z/AHUBoELPeOdx6Q3ud7qPHW49Ib91/uoDQoWd8dbh0lv3X+6ueO1w6S37r/dQGjQs5477P6S3uf7q5487P6S3uf7qA0iFmvHrZ/SWdz/dXPHzZ/Sm/df7qA0yFmPH3Z3Sm/df7qPH7Z3Sm/df7qA06Fl/H/Z3Smfdf7qPH/Z3Smfdf7qA1CFl/H/Z3Smfdf7qPKDs3pTPuv8AdQGoQsv5Qdm9KZ91/uo8oOzelM+6/wB1AahCy/lB2b0pn3X+6jyg7N6Uz7r/AHUBqELL+UHZvSmfdf7qPKDs3pTPuv8AdQGoQsv5QNm9KZ91/uo8f9ndKZ91/uoDUIWX8f8AZ3Smfdf7q7Z+Hez3ODW3lhc4hoEPqXGAObvKA06EIQHF5p8prQbzdgci2D1G0Er0tea/KX/VXXqH5gVo7kPYhfwyy823uQNlWXm29ysQAltAXotR4OH5cle3ZFj5tvcnG7HsPNM7lPACUAFVxjwWWbkrxse7+aZ3fulDYt28yz0+1T6LoIUZY8Fk3yQP4HdvMs9PtXP4FdvMM9PtVjKJUZY8E3fJXN8H7t5hnp9qD4P3XzDPT7VZSugqMq4LXZVnwduvmGdx9qUPBu6dHZ3H2q0hdAUZVwTdlV4tXTozO4+1Hi1dOjM7j7VbIJTKuBdlP4sXTo1n3H2oPgzc+jWfcfariVxMq4Iuym8Wbp0az7j7V0eDF06NZ9x9quQuF6ZVwLlQfBi59Gs+4+1cPgzc+jWfcfarUuQFOVcFczKnxaunRrPuPtXPFq6dGs+4+1XBC4GlTljwRdlMfBm6dHZ3H2ro8Gbp0dncfarosSQ1LR4GvJVN8Gbn0az7j7U43wXufRrPuPtVo1OtVXFcF4tlUPBa59Gs+4+1Y7wt2dZWF9ujbFjWBxs3ENoCfn4k9gXpTSsD4e/11z/0/wA9ZTSsaRPbEIQuc0OLzT5TD/NXXqH5gXpa8z+Uz+quvUPzArR3Iew5jQHJwtC5C9K5wNM5iK7KSVyVJFxeNd+cTeBxyBPYqXaO37Ozdgb/AHjgYIY4YRv5dQTwE8SESTdkWWd7Ivsa7iVJeNv2TA0w9xcAYaBQHeXEV0puTl123ZvmGvERzgAK7iCVWVoq72NYUK05ZYx1LgPXXW2ES4gDeTA9Ko7Ta9YBa1u/WOomD2KVcbawfJ+cdi3lwykRJiSM9Vz1K2VXSbPSp+mTX+12+i3HrxtpjaMaXnta3vInuEcU9dNrseKgsdqDJHY4CI64VffyGumJ35Gtagimp71FtL1iHDcsP1LsnY9CPpVKUVZv73NC+/sbm8dQ5XqySbO+NdkHR2emqzYtgMvanGXoigMLJ4qebRaF/wDEUkt22aj5wb13EqO7bRc2RAIdmDB7txTjdpYRAaD16KHj3GVmtDln6R/FlvVcCqm3kPq5o68yJ3YiYXLzfXtBLXzpBz65EFWl6jCKu0/wY/4id7JouA1LDVH2FtFtq35q0oYiRIMjXEDM03+xW922cWmC7G05SeUBvn6XUf2VIepwl1Jowq4GVNuMnqiGAuwplvs9w5vKG7I9xzUO1Y5vOaR1ghdsK0J7O5yuDjuJK5C5jXJWpQUGpbQkApTXqGWVh5qwXh3/AF1z/wBP89bkOWF8OD/PXP8A0/z1lPpLxPbEIQuY0OLzL5Tf6q69Q/MC9NXmXynf1d07PzGqY7kPYmuak4Cpr2BolxDRvP6DMqtv22rOzy5TtBEuJ4NBp2rolioxeWOr4RFPBzqapacjjrOASYAAkk0AAzJJyCzG1tuEnDYOIaJl+UnTBrA36ynb+61t+VeH/N2YM4G1cTpSgnriNyp71gcYY3C0UE1PadetdFOaludUPT3HV/gi3i8veC1z3EHPESS77U6cE1druJ4KbZXWc1PsbFoGgA9KvOvCnHg66eCnUd5CLG7PtAGhvJaSchMkCQDmTDRTgp132S90BxDGdY9J1SH7QwjCxrjwa0mOuAqy9Xi1fQtfG7CfVFVxqdSttovqdjhGgnbVvyaSzfcWEs/u3PFeVLzTTFBA+zPYmDf7sznNZUkw1m/cSBRUNjsq2NRZPg7xHoNQlWvg9eHHmNaOJHfSVtGnBP5S/s5JTna6V2anZ1/uzwMDmE7snazLXV9CkXqzs8JhgnfGvFef3vZFsyr29ueSduG2bWz5JOJuUOkx1bupVnhcyvB3Ip4qUX+4mvqjc2dq0swlrTAwkaEdqoLzdC11KjT2FFy2jj+1wOfUM/8AtSbS0kVXFKEqTa2uevQkuqLumRwI4J4EHVQrUxkkMvSzeEzq97m0mizETQ14KWxojldSon3nCJJhRbTbr8mx1n2BVXps59L8nLWrwp7s2F1tm2JxkhrRmSQG9pOSudn7eu14dgs7ZuMfRqDnEsJADxlzSYkdvk1vei8y8lx0ygdW7sUR1lOQrpnM6RxWkPQ45Wpyd34PGxGJc5JxR7s22tBLXFpP0XH6XAikFIF9cDhc3DM6gtMQKg8TlVYDwd8L32RFhew/BlLw7G3ca8rPr4RC3nzjLRgc1we0iWuBBG8SR6+C8LHYXEYWV+3ZrYQlGXYfbdbJ+mA/5aDuqEzabIcKtcHDuPs9Kg3W0diLmkiCWw6rZGoqrWzvwJoeUMwr4f1erH4yd7clauEjfRFa+7PaYLT3JLmEUIIPGiuBf/rCn1t3Xw4p0WzXUIB66jsOS9CPrELrMjneGaKNjZIG9Ynw8sS2/XMHX5s//deottGso1oHUP1Xmvyhum/3MyT/AIef/vPBaU/UoV6ipxXJDpOMbs9iQhC6SpxeXfKm/DerodwnutGleoryv5WT/M3X7J/5tQmHUiFeL9aWjjBifpO06homrN7LE4iMTzq6pPZoq597IyUd+LN0gnfn3KaNCy1Vl/bPq3TivjFXY9er255JP7BNMbKS0fBT7a0FSt51lBZYIvDCu+aY/YtaOdXgPaVZWDgBIbhOhNXdhOXZCrWENzqU8bR5E4XRvI+PQuGWebvuaTivwWjLRg5x6yakqRZ7UY0clvaYB7As2HPcYAAJ31PpT9nd3Ew92Edk+hXVCfcxdOD6mXA2yNysrC9YmhzCCdxBrFDFK5hZa1FiyMTo4k/om27asmENBxtBmC15g72mFtGjJ8+Dlr+zHRNJ/c1jr0x4h4A0+Nyo9pbHY44mxO8frGfWor77Z2lWPBJ+ic+41TItnt5pPUoUqkHx9xDD05xundeSM67lhEioNDGfEHepDb1ioaHjn+6U69B1HUPx3pi0a36UDWStlWU9JLUusPKmrxY5aEiunCqiWbKmcgJ4damMZycQq065gwot4syaDmk19nUoi1F2vozRzlKN7aohva+1fyRQZaU3mck5YbJe/gMq/oFa3ZkCBQa8etWMQEnjnD4xVuDklhE3mm7t7lfd/B5kHES6DEig0mg69Vf3TZTGEYGBpG4Dvk1NJUa7PAEaGqsWXrjkuKeLnJ2kw6Sj0pE/+wWb4xsY8DRw+KKLZbPbdi51lRjyJZNOOEnmu9DvSki+wf0Txv7Yr3b+xZrEK2WWqfYwdGV7ki4lrpLXTIIc00LXfRkd9deKq9pcl4IMagileEJNsGzjY4tIyjMTuIrHAyo1pfbQ1dZstG64The3iDzXfZMa10HDPB05VM1JpN9noaU1KLzSV0T2bQe0EO5TRMmSHddDXvlO2O32glr8TJ5pIkdjvaB1lQLNjXtPKLHSYDtRpNBB30OShW9laCQWlzeAxN7xMdqq8JTd1NW+zNFThMvbPwnswXDEZmOU1zJOWZ5OnBZHww2g22vt1c0EFps2kEQQfnpTjomufxoqrag/mrsNzrIcf8Wi6MLhqNOonTvf67HNjMOoUnI9/QhC9I8g4vJ/leP8zdvsn/mF6wvJflgP8xdfsn8xqmO5aO6MsHbkA71wnh8aJDgd/q/Vd+S59W8Tl6Vckh41STfw2jW+j2pqE29gNDkqRo029dSlevWy6WTJVlfz38Z/SiWy/Hj6fQq75yKAd6SS460+Ny19iG6VjieLklZu7+iLS0vrY5pJ7Kdqi21/eQZdA0gEntdmmg2RVKDNFdRjEpKdSpotCLhBOsnV017V02cZuaO32qW2zMw1pLjkGgknqAzT9psu2kA2cEj6RaCOJEyFLrRju0vuc36fyVzrMA5z8b1YXW3MRing6vYCnf4O/DLm90H1E0US1uzmZ1VHUp1Va6ZtCnOk80Vb7Em92ri3kMB4zJHU0j29SrxbvB5RJAoQ79DmnW2hHH1pZtQ4CW50UxhGKskKspTlmc3fjsXewNsNHJcBwkehWlu2xeZwAHWJHqKxVqwNNHCRoKx1wVLsdplsB4cTvA/dcdfDt/KHfsb0q8b/ADdnz2L91xDasceo+0KHaXnC6C4A9Y9IUFu22aPh24gg9U5Jb7221EDnDIisdmoXM8N3lt3OuFeMulpk673wO5pB6ipbbcAS4wAqKw2fa4w4secIkkNdHVXfknH7KvDzLmFvBxiOABMqjw1JytnVjN1mo3a1LJ+17OYxHrgwmX32aggjh+oUKy8GbSpcTBqOU0A6ZyYrRS2eD7x9Jo0FXa0rQk/seCToYVbT1MqWJktZRFWm3iNAIBFIFDpuSLHb9mZxNc07wAW9omiVZ7CYOe8H40JgahShs1jRQ4eOEE5gHM0Po4LNvBxVm23yJTqzfxSS43ZCdtd7pLGHDvMMbXXUJB2tagAgtB/yAudwhxhv+1TbS4WJOJxeTnXCOzmmlT1zVLbYWAIkO0+k6acQRuFKKFicJHaLYyVZLV/8KG97Ut38m0faOB3ucGnhhYGtOlFBuzALxYRFX2eQj/yDiVrW2dh9RswJkuI6qugqk2m5hvV3wNa0Y7PIAV+cFTv0W8cdTq/txi0cWKw8o03JnvyEIVjzDi8j+WI/zN1+w7/m1euLyL5Yv6q6De0j/wCjVK3JjujMELgHaVYM2a85iO0J9uznCYA+OMLaWKpW6l5Ppl8dlcqzZnXuGf7Jt7f8sdeauhs1/wBZjeNSe+BCBsUHO2nPJk91Qqxx1GO7RlOMpvUoAxPMsCcgr+z2XZjN5P8A+QPWfiE4LpZipc89rQPV61SfqtNdJEKEU9SlZcnHOApl3ujBzq9dO4BT8NmND2k+1GNmjR3TG7NedV9RnPRXS+h1RhBdhFjaYRhYcIO7PtJrC6bJ30QTkTNZ7hn1lK/tUVFOqAO8a+1IdfzOc9vx8Fcjqzk72LKy2RMsQ8ad8eo9a5a3XHzoH77lX/xCcnA8MQ06j1pL76Zz9JV41px2ViuRvuh1+wmOrjgQcgO6Sf0S2bIsW0xPcOJaI7h+qiG9Jt16cexavF4hq17FXhk3dlk3Z12BnBUxJc9+dNxipHrXPm7uBSxYc6ljDUDe7NVvzjjod3aPgruN2f61k8SqOtWe8n5K/p4LsXLL8xlWBjcowtAoYiI0oN8pFptF8GHGAYzynMRpQH9lTk0OVYk1XS+MqZDsoY0Vbt76lfaS2sWf9tmAa5CDEaDI+uNUm02iTrmCJg67jOUz3nrVWX8Z6jMGvtXTXd6q8VWxoqUSc6+yd2ZoRxiI6xwokPvbozEGvoGesVNa+gxEaBqf2ia9iScOe7tp1nsRJFvbRJdejSp09unxRIdfd5k9nEDSRr35KM61aPpcPiEw++MGRnSiso37E5YJakx963eyJ3FNi0js4/sq9+0RoN8TJUV+0HnIgUOQgwM9OCuqTfYq61OOly9DyZnLtIVe+0DrzYQQYfZgxv8AnAf1VU97nCSS6K1JcdxO4CaVTuyz/fWPC0sx/vb3rooUssrnn47EKVJxS4PpdCELsPFOLyL5YnRe7mdzSe60YvXV4/8ALMf5q6fZd+YxQ9iY7oZffXce/wDQJp1+O/ur6tKKutia13jlEDUCm8jOKda5a2mZ14cmYJ5uJuKYBoMpMVXj+2mfUNxjoyW+/RmTumRE6ichU67+uGLS/PB1GdTujdI35KNLjDgXCcsUClKnFym8monOpKS4mSQRUHTMZUcQQ1oMt5InIzRXjTijOVV20H3Xx++chwE5AmlebWs4upNuvTiQMRFYwiSDOVZHExuFMqKeHUIAoYBJyggDMa5Rw3ykCBQZUbrOUExlU04yDG+6UeDPNLkWbaBImlakQaV0NDwzGXFl1qMNJGVSaAOgTSNTqZ471vIzk55zvxSSY3GJ48EgmACRoBnzcJINdAKf7lKsVu72Z1pLg7CMLpwieVkPqxXOtdaGoQ482uQOue6QQctZBiI3hcrSKgh0u3tJIgDMNJI0rBqutFRSQYgurGZmoJAplB4RMmSHrqDJqcUS7InIiABQxmTTgIoFzDhMSZFeY4GorynRBI3ismuaDZgiJNORySygMZYh3aZQJkI+ZIGEcCScQbzSXUkkmozpvNUVu5Vya2FB76uD5aDAPOoBmRSJrqMkC0fljMiZhsZQM5668F21IBcOUYEES0GS4A4SaA4QCfswJMFMteHAYda0wlrcQgkDFAPE5AZQATKin2DqS5Ys2r4kvNAO/XTLXfXrKQ63NKurxOR688iIjTiukkZCBDaEmmUhoDncoZGHATJpEHjrNwEmuepOtZJ5LjnWQKic1OVEe5Lk4bT6068cu9INrHXSKU74XHsiQ7PUOw4iRFCYrWedXPemXNzoOOYz5p49c+oxOWJV1ZjwvUZTu+O9IdejvP8A2d3cmHMMmeIzB4SIzodNyap2eqQeOdFGVF41pXsPuvXXxz/X4qkm3OWWggDX0pgM0r6qaDrS2M36jLShrkJj2K1kaKchwuPFNmDMxv1OkZE5dmqdDKZRl2iAAJoUBkTuNd+W/wBCFJSchhpyHAHIAiBLZkV1010hca0jOa8JB3kbq06+9OkSNSM/onI5V9aVhEzJjeeTkIgSYz+N83MWmNCQcqjccuHoUnZ4/vrH/wBjNI/8jfj9TmkvjMk1MScqUMkSIETMRQ1TtydNvYnXHZz142+haUneRy118T6RQhC6DiOLx75Z/wCqun2XZCTz25DU8F7CvHvlncBeroTkGuJ6haMnLghMdyjxEtqQRUmCJ3CJAEQQ36Uz1yhswJcZzP0cxi5ok4RizM0FCYlRrTaliScNoWiDDg14dXIUbO+TTQySSEO2tZGT85VxxVD2nnTVzGUdU5ClYK8/JLh+D3Peg92vJIa0E1kGZza4y4Tunm5R2yDCQ6lIoJkTTk0MNIgxQTOUiaVjv2nYwYeJdiJ5L5lwEYuSWkgcmcqbkn+I2Mjl0g1wvJBkkxJAE4jlurXNklw/BX3afK8kp7iQHCIgEFucSQIE0+jSSJjfCCRTnQdHc0HIlsUjhXPgog2pZQOUJz5r89ZJaZEADfPBcO0LGeeINDDXik00ygkJklw/A96nyvJLwmQAO+IgNBDSWzAABkazQwE28S2DJpIo2HYgIJwTOojtg0TDto2U8/va/IRFMgc9+iW7a1kRV05HmONa5SBvGukSVOWXDIdSnyvJJ+bkkRTeJGWTiCAdJiciE42zqcxM0piFCDirlw4aqFY7UsJBx4TvLHGO5pGn76Jf8VsRk8CmjbSZIEnmxlI4xKq4z4fglVab7rySy0ADKQZEExJESADxb2A7yQOaZoCDSKzOHlAuMUkQIzzG+YY2pYV5Y1PMeZqTXkjfv1zR/FLHLHTLmPHWOafVuTJLh+Cc9Pe68k3BhIbVv+WQ0jkYQABOWHUjIZJIHB0RWSXEhjZBBJgnCOvPiFE/ilj9f0PjhTBuJ7uNHGX1hGIY3AgVDLUjM6hlTmJ3yijPhhypW6l5FPYaERHOzpMhtJz1NZFU0RXFqTP0Ruqerr3dnH7RspguIgmha+QcjILYkZ9tISHX+yiMYiIjC8zkM3NpQaqyjPh+DNyp8ryBYPZHJoY36Znflku2gkxQmsHfnAp3f9psX1gBAeN8APEmBnAjf7cglMvjPrzXVrsooJwneaGk75U5ZcMrnhyvIPsqgVgQN1OEmcOXwQm3s4T8cPjNOsvrK8oDUAB2eeYaNwA70o3qzryqiIPK3jhM0nRMsuGSqlPe68kUM4EA7wZ/ZKI4bt/BLdbs0P8Ay69RP/SSLdv1vQVOWXDOiNanbVryEONO6M9Z6vjek4Izjfn3ydEt9qwjOd9CuG0bv9aZZcMl1aX8l5CpAoTkQe8VmNad29KYwkwDBE/pme7UwZK78836055l28oNs3eOOdd09/oTLLhmcpwa6l5B4oIkUoMWKYk1yEwK00yKVdv8exqT/eWeZJ+m2cwKTKQbRsZ9Q3bhxrrKVdHA29jHnLP/AJtWlGMlLVHLiXF09Gnt3PpBCELpPNBUW3vBW63xzH3izL3MBa0h72QCZPMcJyV6hAed7e8DtkXSyNtbWD8I+raWpNATQY9wKwd523sJvMuF5d9q1c0fmkr3HamyrG8MwW7A9n1STGmcGuQUG7+CNxZzLndwd5s2E95EqbkHzHbXoOc5zYY0ucWtmcIJJDZNTAgSc4TtytHY2uDPnQDVkPhw1BLIcOsFfVNjs+yZzbKzb9ljR6gpQCXFj56udtdnvY12xbUNc5oc4Wt6OFpIDnAYawJK9U8mmzfMO/FtvfWyQlyTHeTTZvmHfi23vo8mmzfMO/FtvfWxQouDHeTTZvmHfi23vo8mmzfMO/FtvfWxQlwY7yabN8w78W299Hk02b5h34tt762KEuDHeTTZvmHfi23vqVY+BF0Y0NYLdjRk1t5vLWiSSYAtIFST2ladCAx7/k52e4lzrFznOJJLra2JJNSSS+SeKPJts3zDvxbX31sEJcGQ8m+zvMO/FtffR5ONneYd+Ja++tehLgyPk52d5h34lr7yPJzs7zDvxLX31rkJcGS8nezvMO/EtffR5O9neYd+Ja++tahLg8k8NNiXe6Os22GzbS8Bwc57mvvBDIIDRLJqa57lh9svc7D83cH3YNnET8+8u3SbQQ0dQnjovpNCm5Fj5QdeSKFwB4xPctN4P7Y2e2zDb3dn2rwXctjy2WkyAWB4AIypnC+hXWYOYB6wCoF52DdbTn3axd9qzYfWEuLHnvg5ddi3x4s7K72rXEOMPc8DkgE1FodD61q7PwBuDS1zbEgtII/vLTMGR9LeFZXDwauli8PsbvZ2bgSQWDDUiDQUyVwlyQQhCgAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhACEIQAhCEAIQhAf/Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw8NDQ4NDQ0NDQ0NDQ0NDQ0NDQ8NDQ0PFREXFhURFRMYHiggGBomGxUVLTUhMSk3Li4uFyEzPTMuNyotLisBCgoKDg0OFw8PFzUlFRsuLS0uNy83LzArMi03Ky0tKzc3MTcrLSstKy0rLSsxLSwxKystNS0zKysrKzctLSs3Lf/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAQUBAAAAAAAAAAAAAAAAAwECBQYHBP/EAEsQAAIBAwAEAxEMCQUAAAAAAAABAgMEEQUGEnMhMbIHEyQzNEFRU2FykZOUsbPR0hQiIzI1RFRjdLTBwhYXQmJxgZKhoyVDdYOk/8QAFwEBAQEBAAAAAAAAAAAAAAAAAAECA//EABsRAQEBAQADAQAAAAAAAAAAAAABEQIDITFB/9oADAMBAAIRAxEAPwDuIAAAAAAAAAA1TWXWmrZXHOYUac487jPMnJPLb7H8DDy5oVdfNaPjJldebGrWvHKlTc1CjTUtlx2uOXFHOX/I0ytlNpppp4aaaafYa6xcG3PmjV/otHxk/UW/rHuPotDxk/UaZJlhcG7frHuPolDxk/UVXNHuPotDxk/UaSmXIYN2jzRa/wBEo+Nn6iRc0Ks/mlLxsvUaTEliXIN1jr9VfzWn42XqJYa9VH82p+Ml6jTKZ6KLaeU8NcTXGn2V3UMiNwjrrU4vc0F/2P1Hqstap1atKnziMeeVIQb228JvGeI0qMFwKOYRWHjO1l5bbeey3/ZGW0GuirffQ85Mg6SADKgAAAAAAAAAAAAAAAAAAAADV9Lvoyp3adH8xzrTVZVLmvNZxKo+Pj4Fj8DoWnHi8l3adHzyOaV3mdR/W1l4JtGoPPItLpItAqXJlpciiSBNFkMCWJUeiB6aK2pKOUsvGXnC8HCeSDPRSnNZdNuNRRm6coxU5Kai3FqL43nHAB71a4Tltw96s8Cn77+HAe7QXVdvvomPhcXG2889U260a9u7aELanbbDcKsaipp7T+DeeePLlKOyse9yGgeq7bex8zJvodJABhQAAAAAAAAAAAAAAAAAAAABp+scsXj3dP8AE51X+PV39df5JHQdaHi7lu6fmZz2q/f1vtN0vBWma/BDIsZfJlhQLkWlcgSRJYkKZLECeB6rVS2k4Z2o++Wysvg7C7Pc7p5ImV0Ho+jd1XQuYOpRlSqSlGMpRlmGJRaa4cppDq5Kc5s34zdDRs61qqlKvKU5U3OVCUYpuPXxhZWetlcOTzaA6rtt6vMymi9XLeVeEas9I1KcdrYjUxSjU7DrSglxYwlFpNPL4xq683ds/rVyWc/H1sXrN2fHSgAVAAAAAAAAAAAAAAAAAAAAABpOtjxdTf1dPzM55N5qXHcvL1eC4mdC1weLiT/cp+ZnO10y67l/pBf+moa/BbItLmW4AoVGCqRRciWBFElgBNEzerFeNO6jKpnZdOrDEU223HiMJEyehKsadzTnOahFc8W05bCTdOWOEnXyrzNuNzp3SoVJVK0KypScKdtmjJOC2HmMn+02847hgNXOq7Xe/kkZh6etIwaqXtvxuCVSttYk01FJPOHwGH1b6rtc9sfo5GOJJLi982XLHSgAVkAAAAAAAAAAAAAAAAAAAAAaNrn06fewX9jni6Zd/wDI6R+9VDa+aPpOpSv4UKfOud1YR57VlQuajt5bPBtbHA01ji4TXqNCNR1KjvLTNWtWqyajXjFTnUcpQ2XHKw31zUHlZaz1ztEnwXNtJdnM1+Bb7k+vtv65eoDzFUej3J9fbf1v1D3J9fb+MfqKIokkC9Wr7bb+MfqL42z7Zb+NfqCKRJUn71p7MoyUk8Z62PxPPONdNKFO3qLOG/dShhdnGzwk+KqXxKLfYVx+OBZsytc9Xmyz7F1xa8/cXOrUWy8qNOWxFvDWJceY8PCuvg2HV19G2u9l6ORqsbu7Ta9wRaXFL3bRxL+XWM9qhWrzv7fn1uqCVRtNV4Vtr4OS/Z4jM5nM9NeTy9+S73fbqwAIwAAAAAAAAAAAAAAAAAAAAANN1pk1Vnwv49PkQNAtrmmq11KrDnjd3cqPvVNLFw9rMW+HMU1nrPhN91r6bPeU+RA5tH49x9svfTzLBWo1luKcY5ezFvacVngWeuWFzKM0CKpBIqgL4olgiOJLFFRLAmgRUyaIEkTMatLo23798lmIgZnVtdG2/fvkslHSQAYUAAAAAAAAAAAAAAAAAAAAAaTrY/hqm8p8iBzmPx7j7be/eJnQ9bJfD1d5T9HA57H49x9tv/vMyxVsihVlppF2SqLEXIoliyaB54slgwj0xZJEggyaIHopma1c6st+/fJZhaZmdXOrLfePkMlHSAAYUAAAAAAAAAAAAAAAAAAAAAaBrfLoit39P0UDRWsTuPtt/wDeqhuuub6Kr99S9FA0upwVLn7bf/eqhYtRMtLpMsKioRQqUXoliRRZJBgTRJ6bIIk8Co9FMzerfVlvvHyJGEpma1c6stt4+RIlHSQAYUAAAAAAAAAAAAAAAAAAAAAc213li6r/AMafoomoVemXHdu71+G4qM2nXypi8rrd+iiapnLqPs17l+GtNli1G0Wl7KYKi0qCqRRWKJYlkUSxCJIIngQxRPEonpma1c6ttt4+RIwsDNat9W228fIkSjpIAMKAAAAAAAAAAAAAAAAAAAAAOT80SXR9Zfu0n/jRrVB5gn2ZVH4ZyZn+aS/9Rq7ujyEYC36XDvc+Hh/EsVVlrZVstKipUoipRfEliRxJYhEkCeKIoE0SiWBmNW30bbbx8iRh4mW1c6ttt7+SRKOmgAwoAAAAAAAAAAAAAAAAAAAAA5BzS/lGru6PJMBR6XDvI+YznNOeNJVO7Ro8kwlHpcH+5HzFijLS5lEaQLkUwXIC6JLEjiiWCKiWBNEjgiSIEsDLavroy13v5WYumjLaBXRltvl5mSjpYAMKAAAAAAAAAAAAAAAAAAAAAOUc0G2jPSVRyTeKdFYzhNbPXNekklhLCXAkuBI2fXz5Rq7ujyTWZmoIZFCsi0ouTKosK5AmiSxZ54sliyj0xZLFnniyeDCPRTMxoLqu230fMzD0zL6BfRdvvoCo6UADm0AAAAAAAAAAAAAAAAAAAAAOW6+/KNXd0eSazNmy6/8AyjU3VHkmszZqCKRaVbLcgVKlqK5KL0yWLIUySAHoiyeDPNA9EGVHqpsy+geq7ffQMNTZl9Avou230CUdNABhQAAAAAAAAAAAAAAAAAAAAByvX/5RqbqjyTWJnUtbNTIaRnGrTuq1nXWIzqUoxqqrBLgi4TyljsrhKUdQNHqEIzjWqzjGKnUlcVYyqSSw5tRaSbfDhLHCXRymRada/QHRvaavlVx7Q/QDRvaavlNx7Q0clK5OtfoDo3tFTymv7Q/QLRvaKnlNf2ho5OiSDOrLUTRvaJ+UV/aKrUbR3aJ+UV/aGjl8SaB0xak6OX+xPyiv7RJHU7R6+by8ouPaLo5vSMvoHqu230PObZdak2NTZ2Y1qWG2+dXNaO13Hls1DUnQOlYaRzpDR8KNtCpVq07iOkHVdP30nTpqCk1NYaWXFPCTznjaOpAAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/9k=",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgVFRUZGBgYGBoYGhgYGBgYGBgYGBgaGhgaGBgcIS4lHB4rIRoYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QGhISHjQhISE0NDQ0MTQxNDQ0MTQ0NTQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDY0NDQ0NDQ0NDQ0NDQ0NP/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAAAQIDBAUGB//EAEoQAAIBAgIFBgkJBgQGAwAAAAECAAMRBCEFBhIxUUFhcYGR0RMiQlJykpOhsTJTYqKywdLh8BQjM4KU4hVzs8IWQ2R0g9MkNIT/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBAX/xAAlEQEAAgEEAgEFAQEAAAAAAAAAAQIRAxIhMTJBBCJCUXGBsWH/2gAMAwEAAhEDEQA/AOuEcI0RZoOEWNiwFiiJCEOvFjYXgOvEvEMQmRSlol41mjC8CTahtSAvDwkCfahtSvtQ2oFnbheV/CRQ8CyGigyBXkitIJbxZGDHAwHQiRYBCEICRYkS8BYRt4QKwMURojpQ6LGiLAdFjYt4CwvCEBCYwmOJkbQGM0YzxWkTGA2tiFQXZgBzyg+l1FrK7A5g2sCL2uCd4vMrWapZ0X6NwOe57pad1fCIRkyMV2uAY7VgARf9b5GorlqirU2PCGi2xe19pCb7917xKWNVjbMNvswINua++PpbYwSHwoKmpn4mZ8XcDt5TF1ndA67AZQFBz3g9pkybW8Hjw8o4RyyKTvIF5ZUysrKtJFaVUMnQwLCmPBkKyRYEgMWNEWAsSESQLEhEgLCJCBVEdGAx00HXigxsUGA6LGxRIFhCEoQyNpIRGsJBCwkZEnKxpWBzWs+HFkflB2Oo3PxlegCcHW+i1M9pIm9pfC7dJ1G+1x0rnOX0RjlKV8Owbaq07Kqi5Do20qk8l7HORuvTewx2sJhkG967+4IPvlHWU3xJUZhSF9Xf8Iaq4oIEeqHCYfwj7ttQxICCyjazI3nLKR6MBxFbwhNwSXvYi+febb+MK3cNQ2EVb3sAL8eMmCyXYjgkOZiiSoIBJIqwFUSQRAIogOixIsAhEhCliQiQCES8IFURwkamPBlQt4sS8BAfFEbeLAdCJFgECIQgJaJsx8LQIiJzem9XidqrRco48eynZJKi9lfyb26jwnUWkWJHiP6LfAyLE4crS0WzpSSmdgPtvUG2xVwtQqAVyvvNhuFzOg0fo5aS7K5kklmtYknm5BzSvogZUv8AKf8A1zNi0LaUQWOCSQCAEIaFjgsW0LQACLCEBYQhAIQhAIkIGAQiQhVBDJAZApkqmVlJFjQYsBRFES8AZA+KIy8WA+ESLAWESLeFEixfyH9BvsmTCQY0/u39B/smBn6H/wCX/kv/AKzTYmRof/l/5Le+q014WexCEIQsIQgLCJFvMggIkICxIQgEQxY1jAW8IzahAy6byZWmbQrS0tWbQ/EY+mmTuAbXtmWtx2QLys2n6P0z/IfvtFxOFR82GdvlA2P59czK+iWGaMG5jke4+6ZtMx061ik9y1qOmaDeXsng4Ke85e+aKsCLg3HEZicTVRlyZSvSP1eNpOUN0Yqfokr2gZGY3/l0nRifGXcgxQZyuH05VXJtlxzjZbtXL3TSw+nqbZMGQ84uvaPvtNRaJcraVo9Nm8cDKtPEqwurBhxBBHukgqCaYT3i3kAqCO8JATE4xKfy3C33DlPQBmZkY7TaOrIl9phs7TLkAcmyvvte3POYeszuWY3JJueuOw7eOOmGtrsMLgHo00rGptpsFCpA2t5YFdlRynlvJ6WlKbW8bZubDayz6d0s43/6KdJ+6cVjT+7/AJoXGXc3heYWrNcmlZjfZawvyC27oms9YAXJAA3kmwHSTDMxhYvC8w8XrFST5N3P0cl9Y/deYmK1krPkpCD6IufWP3ATna9Yda6F7enaVKqoNpmCjixAHaZmYjWKgm5i54IL+82HvnFVKrObsSx4sSx7TnG7PP2TnOt+IeivxI+6XQ4nWx/IRV53JY+qLffMypp/Esb+EI5gFA7ALykAOELnknOdS0+3auhSPToNGazuCFrDaHngWI6RubqtOqo1ldQyEMp3Ebp5qU4m01dWcY6VAi3KMTtDkFh8rm5JumpOcS462hXE2jh25Mjd41qgmVpjSIppl8o5KOfj0Cd3iaHhhxiThv2qp843uhJuMIKGOqWFiOyWUx1Xzh2SbDauYkZGl9dPxS2ugMR839dPxTUzJwpDHVfOHZHft9Xzh6svjQWI+b+sn4oo0HX+b+sn4pMyYhQOOqkWJB5ioldgSbkAdAtNkaDr+Z9ZPxRRoSv5n1k75JzPpqttvUsQoY3dvm8NC1/M+snfD/BK3mfWTvmJrLrXWmO2GrWN1ax4g2PaJaXSVYZbV+kC/aJefV2qfIt/MnfIX1dxI3Jf+ZAftRG6Gt1LdoV0tU5WA/ly7ZPSx9UkeMLEjcBuvMvE0KlPJ0ZOdgQD0HceqMR7eMrWO/r+BjdPsnSrPNTFOZ6/jHYdvGHTKjVDfI25L7N/dcSzhcMdsAu9+Hir8FvOkWienO1Zr29Cxj2wNPnZpxWOfxOudDp6kyYFHWrW+Xs22kYAEZmzLc8g38swMJh7guwJNr+MLEjiL8nRlJa21rT093tDh9KOibCC2ZJJG+9rWHUZWxGJdzd3J6dw6BuHVEqm53ZSK889r2s9ldOteoA4/Huig9fwhsE7/fEKjp6chOboerX/ACj7c4HvMdhcFWq5IjsOKiy9bHITUpasYjykt0MhP2pqKTPTE6la9yzFtyC/OYuwx/WU3k1eqjdTv0snfJP8FreZ9ZO+ajTn242+TH2ueGFM0KOMqILJsKOZBn08Zo/4JX8z6yd8a2g8R839ZPxTpWu3qHnvebdyz6ml6wGbL6sxamLq1XB+UTZVAHE5ADiTb3TcxeruKbIUsuXx6fZ8qbGqerb0nNWsoDjKmt1a1xm5Kki+dh1806enLhk/8K436Hr/AJQnoV4ScGUEJHtw251YSQkRe8lesuwFVFW29hfaJvfL377wFhI9uG3AkhI9uLtwHxZH4QRlbFIgLOyqo3liAO0wJmUEWOYPId0wNYND4YUalRkCFEZtpCUtYbyBkeyRY7W2mtxSU1DxPiJ2nM9Q65zOP07iKxCuyhCR4gWyZG42uVhe288kxM1da1vHPTC0bSqtUQIoCsygNW2jtXPKgN7dJE2NZMPVo1gHxiLlf9zQRVXIZWux7ZlvSe5VyDY7xv6uElxZ8IF2/G2RYHdlz23y4hZtMtPH4gvh0RNJtUJYk0npU8iCLZ7IPv5JraRp4zD4JUdaNVDZhbbp1kbLMXLKekFZyNCiiMGVcxmI7SbVKzbbN41rDkAA4W3STyVnCLC40uTthsjY3Fj19+6dFo3Qr1xdHpgemCwHOq3I67TCrUXAQuQW2LXtY7N7i/aYlMWzBtwO4joM81orFntrN7Vicu7w2qCDOpUZuZQFHab/AHTWw2hMOma01JHK/jn617dU4jBaxYmn5ZdQNzjbHbfa986LA6202yqKUPEeMveOwzpWaenn1K63uc/p044RLytQxSOu0jBhxUgiSF51eVLeAMaay7GzsLfla5Lb73BvcfCM8JLgTgxwMr+FiirIqzeF5AKsDVgT3hK/hYQjN8bjFs3GWFSPFGd8Qyq2bjFAbjLgwpjhhTxjEClstxhstxl39l55Ux+Jp0V2qjhQdw3s3MqjNuqOE5k2zcZXxmMSkLu4XgN7H0VGZ6pz2ktaHa4orsDzmsXPQM1X39U593LEsxJJ3sxJJ6SczOVtSsdO9NGZ8uHRY3WZzlSGyPOexbqUZDrJ6JhYiu7ttOxc8WN7dA3DqtG4bDu7bKIztwUXt08g6TOj0fqi7WNZ9geambdbbh1XnP6rO30Uc2qkmwBJO4WuT0CbOA1bqPm/iLwObnq5OvsnY4HRNKkLIgHFt7HpY5y6MPOldKPblfXmfFzFbVmiygeMCPLB8Y9N8j2TPfVFh8iqD6SkfAzuBhTD9mnTbDhus4NNUX5ai25lJktTVIhbo+045GFlPRvt13nbGhGmlE1rMLFpicvKsZhnRtl1Ktz8vODyjnkFrz1bE4NHUq6BhwIv2cDOa0lqcDdqD2+g9yOpxmOu88t9CY5jl7dP5VZ4nj/HHC43Z/rhHK4It+h0cJNj8FVom1VGXgSLqfRcZHtlNs/1nOExMdvTFonmFvD12Q7SOyNzG1+/om1gdaHFhVG0POWwbhmu4+6cztcOw74bY5cpqt7V6ZtStu4ek4PFJVXaRww5bbx0jeJY2G4zzTD1ihDIxU8jKbEHhfh0zqNF61C+xiOjwij3uo+I7J6a6tZ4nh4tT49q815h0ey3GLstxllUBAINwRcEbiDmCIeDnXEPPy5/E46qrsqlbA2F1PAcsjOkK/nJ6p75YxFP94/pD4SLwdr/AK4TnhqZR/t1fzl9X84sXPmhGITMulWToJWQyyhnZFhFkwSNojmlkU24TORhawHEin/8ZFZybEsVBVbb1DEAnpy5jPP8RoLHOxd6Tsx3szoxPNfa3c26er1RbklVzJMRbtut5r1DzXDar4lzYoEHF2X4LczocBqjSTOoxqHh8lOwZnt6p0ZMbeIpWFtq2n/htCiiLsooVRyKAB2CSiMvHKZtzSqJMiyBDLNMyCVUiMknRDwjXU8okyKbrImEmcyBjKGmJEJheA5kBBBAIORBFwekTEx2qGGqXKqabHlT5PWhy7LTaBk6GS1Yt3DVb2r1OHnWkNR8SmdPZqjgDsP6rG3Y05vF4SpSOzUR0PB1K36Cd/VPcqQ5pLUobQsygg7wRcHqM420a+nevyZjuMvAVvcBb3JsAM7nmHGdVoXU+pUs+IBpp5nlt1eQOnPm5Z6LT0bRpEtTo00J3lERCekqBEeK6MR3yX+RM8Rwq06SoqooAVQFUDcABYDsimK5jLzu87AxB/ev6Q+EjZxbM24nk5N8kqt+9q+kPhKelX/ctbefd4wnL8/1Z7HhU89e0d8Jg/so/RMJz3QuHoqCaWDwhY5zjqOtiD5nrrgf7ZpUdeUG7wH9QPwzvN4Z2y7qhQVRkJPOFGvS8cL14n+yA17/AO1/qj/65ndC4dpVpBt4mRjMKRu3TE/44/7Y9GJv/skVTXS/k0fb/wBkRaIML7Rm1MStrMp8ml7b+2QjWC99lEYgXsKl/gs1vhNsuhBjlac1Q0/UJ8aiqi17+EJ4fQk1PWMcKftf7Y3wbZdTh6RYzZw2FC78zOMoa2hdy0vbf2S0uuR4UOuufwTM3hdsu0AiMoM5Aa4HjhR/+g/giHXI/wDTHoxB/BJugxLoMXhRvEyKqEGU31y5qHVX/slKvrSG8ml1Vv7ZYvBtlqkxLzCXWDaNlVCd9hUubDlts84kdPWJtks9NECneamWdt52RbM2mt9fybZdIsv4TClt+6cfS1tpjlo+3XumhT13QbvAf1A/DJN4Nsu2pUgNwk04ldeB/wBP/Uf2Rqa83Of7KBz4r+yZ3QbZdjWpBt4mRi8KVzG6ZDa7rxwx6MSPwyvV12Q/Mf1A/DLF4Nsr7SO8wq+tiHkpdVYH/bKdXW0DNUR7ebUv8Fl3wbZTVGvWqjgy+8ZSDSRuj9A5vKEh0TizWerVK7JcqdnavawZd9hfdfdyy1j18Rxy5fETE9Se2fs9PZFkuxzH390Jwy6ORp4VD5I7BLFPAIfJ+HdHU6Y+cpe0Tvluii8tWj7VO+evMOWCUtEUz5Pw7o5tBUuB7R3TRw5Qb69D2yd8su9K38eh7an3yZMMN9EUxuB93dKz4FByGbjhDuq0T/5U75Tq0L+XT9onfLmDDKbCpwl7QlIB3sPI++I2GPn0/aLLeiaOyzkshulvFcMd/KBM2mMLHa+ib/RM5elh1sMp1aDf0H7pg08GwA8en66zNJiM5WUKYRDySzS0ah5D2yanhT59P2iy9h6A+cpe0Tvm8wziVZNC0jyN2jujX0NTHIe0d02lRBvq0fap3xlVFO6rR9qnfGYXEuefR6DkMrthU4TarYf6dL2id8pvhD59P2ixmExJug6IFU2HkN9pJdx6A0agOYunxSR6KoFahJZD4jCyurH5S8g5JYxS3pOLqM1zZgqjNd5OQnO3lDUdOfTBp5o7B3SVdHp5vw7pKqD52l7VO+SoF+cpe0TvnTMM4RJoqm3Ifd3S2ugaQG49o7pbwaJvNaiOmtT75eZ6fz9D2yd8mYXEufq6Jpjyfh3SnUwSDyfhN7EBDurUT/5k75lYlByPTPRUQ/fGYMSyqtBBuHwk+ApAI5541qX009dZcwlK1N81OY+Swa3TbdM2mMLENbVsHZfq+LTXPOOPwmbq3YI56Pi01n3Wtvvv6JifGf0e1j9mTh+uyEd2+7vhPPy6PM0wo5uwSzS0cG4erHURkJewwn0XAynoEHyl9T85KdWxb5a+p+c1MOZaDSK5SroDZ8sep+cqvo7Z5R6s62uoMzcTTEg55sN0dks6MUqz2NvE5Bzy06S3oNBtvkPkffJaOCJ5Q06zm925D90xadDLk7J2yUlF7KB4p3ATmcOgsOqZpHa2lWTB34dktUtD7XlAfy/nLtGnNLDoJtGQur/019T84NoC3lr6n5zpVAjHUSDk6mi9nygf5fzldsLblHZOlxCCZ1ROaUUtFIVqEg2Owdw51k9Z3ak+0b3IytlvWW9CIPDH0G+0st4ymoouAAM15AOVJztH1NRPDmVwt+HZLGG0VtHePVlqmgl7DkCdGUKavg+WvqfnHnVv6a+p+c1aVSSs8mRzdfQYXy19T85nVNHW5R2TqMTnM6tTykyMRcKL2y7JuaLogUK4tudfsiUETOa+j0/dV/TX7M56k8NV7WNVLmmTzj4vNu1yTzHf0TL1ZWyHk3cn0nmzuJ6/hMz4yfdCzsHn7fzhJNgcITzurzSiMhL9ISlhjkJeSfSedbpPLAqzPVpKHmVWKlSUazx7tKlWBDUeS6KxAVn9D75VqCLgFuz+j98lp4I7baY0Z9BmFh6mUtUUzPQfumfQ3TNVlqUnmhRqTIpGXKbTeUagqRHqyorRHaQFapKFV5LUMpVJRZ0VWAqE/QP2lljE4oGk/OV+KzOwC3c+ifiI7Y/dP0j4rOc+Sx0dSeWqZmfSl6jNyjQpNJS8rUzJ1kEbmR1F8WPePdfFMkqx1XxprYBf3WI9NPsCZoXxpp6M/h4n01+wJz1Omq9rGrGdMn9fKebBU27ZkapZUcv147zZrkhbdN5mfGSPKGj+uSLItoc0JwdHmWH3CaKQhPovOUb49YsJFMaVqkISCrUj9H/Kf0PvhCLdEdrlLl9EzKobuyEJmqyt05bpwhNomEGhCQV6kqPCEBdHfLPon4rJG/hP0j4rCEzPax0gpckuUosJtFunJ0hCZETb5M3yT1whMysMo75o6K/h4j/MX7AiwmNTpqva1ql/C/XnPNmtuboHxiwmZ8Z/pHkvQhCed0f/2Q==",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwoNCAgICA0IDQgICAoICAgNCg8ICQgNIBEWFhURExMYICggGCYxJxMTITEtJSk3MDouIyE/OTlDPigyOjcBCgoKCg0NDg0NFzcZHxkrKysrKzc3KysrKysrKysrKysrKy0tKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIALcBFAMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQUCBAYDB//EAEQQAQABAgICDgYHBQkAAAAAAAABAgMEEVLSBQYSExQVIVFUVZKTlNEWMTJBU5EiYWNxgaHhIzNygqIkRGJzhLGywuL/xAAVAQEBAAAAAAAAAAAAAAAAAAAAAf/EABURAQEAAAAAAAAAAAAAAAAAAAAB/9oADAMBAAIRAxEAPwD7iAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLQmur151fNu1+zV/DLQA3dWlV2pN8r0q+1KJYqMt9r0q+1JvtelX85YEgy36vSq+Zv1zSq+bBAPTf7mlV8zhFzSqeUoB68IuaVRwi5pVPIzB68IuaVRwi5pVPHMB7cIuaVRwi5pVfN45mYPbhFzSqOEXNKp45pB67/c0qvmnfq9Kv5vFOYPXfa9KvtSb7XpV9qXmkHpvlelX2pN3VpVdqWESkGe6q56vm2cLVM7qJmeTKYakNnB+1V9wNoBAAAAAAAABjd9ir+GWi3b3sVfc5jZnZ/gt/eIw129G4pqm5Tdpo3OfuynlUXEsZauxWP4Vh+Eb3Nqd8qtzbmuLsxlly5x97akEIlKARKJJQAgQAIzQDLNGbHMzBlmZsczMGWac2GacwZ5mbDNOYM805sM05gziWUPPNMSD0bOD9ur+FqRLZwc/tP5ZBugIAAAAAAAAML3sVPn23La/icXj7d+zbmui3aiNxNmnEWL3q5K4mYzyyzj64ifc7vZG1vmFvWoqmma6YpivcxXuZz5p9bn52EvdJo8JR5rBO1XA3cNsZZw1+KouW5mJzjcZxlEckZzlHJyRzLWYUvFF/d1URiac6aaKp/stMRyzV9f+GTifE9It9xALlip+KMT0ijuf1RxTiukUdz+oLeUSqJ2KxXSKO6nzRxXiuk093PmC2QqeLMV0mOxV5nFuK6THZq8wWsoVXFuL6T+VXmji7F9Jn+vzBv4u9VbsXr1u3XduWrVdyjD0fvL0xGcUw8MBjbt2Le+4e/Yqqw9F6uK+WKKpimdxnl7t1McuXq9XNrcXYvpM/OvzOL8X0if6/MFrmZqni/FdI/5+ZxfiekflV5gtszNU8X4n48dmrzOL8R8ensT5gt805qfi7EfGo7EnF2I+Nb7sFzmlS8XYj41vu08W4j41rugXFdUxTVVETVMRnFMeuXnGIryz3nEe1FMU5291MZT9Llq+rLn5VZGxt/41vuoRXsdepoqrm7byppmqf2NPMC4s3qqpyqtXqI3MVbqubeWej9GqeX8m9gv3n8sue4qufHp8NR5rHYLY+beKqu1Xaq53mqjcRapt0+uOWcvuBfgIAAAAAAAAML0fQq/CWlLfrjOmqOeJhVTej1T7vWCJnLEf5lj/ar/ANvTNp4iurfbV61vc1UUXbVVFdc2qZpmaZzziJ5foR7vfKJxN3Rw/f1aijbRLTnE3dHD9/VqMZxVzRw/f1agNyWMtOcXc0bHf1ajGcZc0bHf1agN2WMtGcZc0bHf1ajGcbc0bHf1aoN+ZY5tHhtejY76rVYzjK9Gx31WqDfzRm0JxtfNY72rVRw2vms95V5A38zNX8Mr5rPeT5HDKvse3PkDfzM1fwyv7Htz5HDK/se3PkCwzM1fwuv7Htz5HC6/se3PkCwzTmruF3Oax3lXkcLuc1jvKvIFlunniav2F/6rNyfv+jLS4Vc5rHeVeSZv11ZU171FEzE1TFc1VTGeeWWX4Ast03ti+Wu5PNTEfn+imi/C52E5bd257primPwj9QWQCAAAAAAAAAptkthK716q9ZxFVmK4iaqN6i7G6545YXIDmZ2s4rp9XhY1mM7VsV1hV4SNZ1ADlZ2qYrrCvwkazGdqWK6xr8JGs6wByM7T8V1jX4SNZjO0zE9ZXPCRrOwAcbO0rE9ZXPCRrI9CMT1ld8JGs7MBxfoPiOsrvhKdZHoNiOsrvhKdZ2oDivQbEdZXfCRrHoLiOsrvhKdZ2oDifQXEdZXfCU6yfQXEdZXPCRrO1AcV6C4jrK54SNY9BsR1lc8JGs7UBxfoPiOsbnhI1k+hGI6xueEjWdmA430JxHWNfhI1kxtLxHWFfhI1nYgOQjaZf6wr8JGszp2oX4/v9XhI1nWAObtbWLke1i5q/wBPFP8A2X2Dw8WbFuzTMzuI5avVNc++XsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhYYGRgaHRweGhocGhocGhwfHh4eHBwcHCEcIS4lHh4rHxwaJjgmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QHxISHjQrJCw0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIALcBEwMBIgACEQEDEQH/xAAcAAAABwEBAAAAAAAAAAAAAAAAAgMEBQYHAQj/xABCEAABAgMFBQUFBgUDBQEBAAABAhEAAyEEEjFBUQUGYXGBIpGhsfAHEzLB0RRCUnLh8SMkYoKykqLCFjM0Y9JTFf/EABkBAAMBAQEAAAAAAAAAAAAAAAABAwIEBf/EACsRAAICAQMDAwMEAwAAAAAAAAABAhEDEiExBDJRIkFhFHGBBRNSoTNCkf/aAAwDAQACEQMRAD8AtwtgulRU1f0z4wY2sPQigepr3ZCIgSXo5ZVeL4l6UygoltV1PgquHomIWzVIkza/hcipowwz1gqrWntVIGBB7vKGSbICWc0DprQeqweVZkkpxL5HliYNx7D0WpsCSwdtfTQEWwOAXqHBHPA98NjZkkGhoe0PWUHRZh2mTXHpBuGw5Fupjie6OqtoL8S3rxgibOPwiop69YwdEgUYYhhGXqHsBVtFe7HKAbaHxGn6woiRhTJuR9eUc9xUU4UyMHqHsIm2A/C+goeuXjCZtRJoVHKj1GZwh2mRhRssITt81EqWZi6JAbiTgAOsajCUnSE5RStiSbUcQkn6Zxw2pWACvoNYgU7zEmiWSWFch0eLPIF9IVqH7jFsnTZMValyRxdRjy3pd0NvtK3+E+HSCC0rP3Djwx+kSXucen7QmZHn+8TplbI82leDd58YBXMNPn4Q9VZw/rpBkSfP9xGaZq0MUyljHU1fvirb62qYEpkhTBYdbP8ADkmL8tFGMZ7vsP5kfkT84zk9MdjeL1S3Gu4VkSm1Aj8C/wDjGrWfDrGcbkp/mf7FeaY0eRh1ivTO4k+pVSMp3yP85ObUf4piY9nUsFU1ZAJASAcw7u0Qe9pe2T/z/wDERYvZ0nsTjxR5GKLuJvtLyhTpD1eMf3hSE2mclAupCyABgOUa+jBPOMd26p7TOP8AWvzMalwZjySu4zm1J4JUfIfOLfv+trKeK0DxeKr7PkPaSdEHxIixe0VbWdI1WnwBMKPaEu4zlE0xM7MsxVUxH2GzXqxZNnSmxjmyT9kdeKH+zJawWcCJuVKpDOwymiUQKROKLSY1mWalIREgYxIKiNnTwVplg9pTluAxPiBDcb2RjVS3DJlvgkkQItEiSkJA0gRX9heSH778FWk2UMgdamoOnGsKGzipFHLdNDocYUKDTAqByFVfTF+kGVLAvVF040oD6rFKJBBKSDhQDr6aOpkhxhg5AzOo6wqlFUlqtX6vHEpwB17J+pgoDnu3GGJr9MOkdVKcHLLkBn61g61jtPw6H6YR2/iW+7UamExoAQKjhlRuXrKFAmtNKfWChsXwHfwMHQaB9H9esoyaABgOFOPr5wAnDlSAnAU4xwqwpx5QAcQjDFmzisb8n+HKTkVv/pSfrFmo/j+0Vbfdf/YGt80/sHzjq6NXmRy9a6wSfwQlkAAIKQq8kpD4g5EcX+cWrdGcVWdzUhSx0SogDuEQdkshAkqOClgA8QQ8S+5h/lv75g5dsuY7/wBRacVXk8r9I1a5X4J5XzeCHDvEGvVPAsflBSad8eQe+JN5eUHB7oTjoNev7QgFFmjcxGd74q/mf7E+UaGtPZ6fvGc74f8Akq4JT5RPMvSVw9w83G/8hX5D5pjRpGAjPNxR/HX+T/kI0OTgIr03YS6nvMh3nU9rn/nP0i0ezsfw5p/rH+MVHb6ntM4/1r8zFx9nqf4Cz/X/AMRG13GH2lyRgmMX2op5006rX/kY2cYDlGJ2pTrWdVK8zGp8IzHktns4R/GmHRA8T+kTHtBTeRKTqsnuSfrEd7NUdqcr8g8zDrem1hcxKBUId+Zy7oxKWmFlIR1Toh7JIGAETtgszsTDWwWZ8YsMiU0caVnf2oUs0todiCIAAhK1WtKElSiAAHJMVSJN2JbUtiZSFLWaAd+gHExWtzrQqdapkxWN1gNAVBgO6IHeHbRtC2DhCfhGp/EYn/ZzL7UxX5B5mKwjvZzzlapGmJgRx4EVIFevgBPDjnqIC6kjAliCM+Hy6wRVR+bjRsvCDk4klwkUrUanjGDYZCmYtjQ40Onf5QCo8Oya0y1HnBELwDj6n6wcYY/erg+OB10gA6UntJ6ig9ax0GubEPyPpoNMR8VNCeXDpBrprxHp4TGBOTjGhGnGOpGHMhuGvrWAkeI7o4Th3coVDAT8PhygyEuHFK0xgt36QtZgFAjMU+kOMU3uZk6RC23Z8wqpbVo0SJaC0VveeVcVJSVqWQFupWdU5OQOkX2ds5KqihiD2rusZykK96lF0EBKg71dwQflHZ0+jHlUmc3WOeXC4Ln7CFoRds1iOiiT1WD8oiLNZbchAMiQgoULwAmKBJIDqP8AEABJqzRabXsda0SUGbKAl5ua9GiWsVjEtCEFV4pSA4oKBoplnGUErt23/bOTpcU4TbapUl/zkpknatrSQldmmNR1pDgc7qT5xI2Ta6VgXgUKKiLqiAokEhNAc2fqItKUnGK/vbaLoQFEVKsWyAIbufpHHKKo9JSZ1Q5H9cYOjn60g6rMXxEGMgt8Q7omkUs4o06P9YzjfAPaVUyT5RpPui3xDuiv7a3Z98srCwCwoRSkTyRco7FMUlGW5EbhoadM/IPONDlCgiq7A2IuzrWolJCkgBuBeLXJWm6Kh4phTUUmTzNSk2jE9rKefNP/ALF/5GL3uAn+WUdVq8kxSdp2JYmLJBDrUagjFRMXvcRDWUfnX9I0mmxNNIs8wsl9EnyjDlqck8TG326iFHRCv8Yw1CSSAMTGp+xmBb90toiTZ5y/vqUEoHG75VhzsyyqUbyqklyeJqYZbE2Tg9c4t9ms4SKRyTlqO3HDSrfILNZmh4lLQEpaITb+30SBdHaWcEjLiYUYmpSJlc04JDny5xnu9FvWucuWpXYQWAFASwLnWNG2ckXLzGofCMo2vPC58xYwK1NywEXUaVs5ZZLdLgapjQ/ZyjsLOq/JI+sZ4I0/2ey2s6TqpZ8W+UajyYlwXFSoEITZlTAihMhzLSXB+HPUHH1zgwl9oPpUMGbSHBkpqWfWO3AMonRsQQigGFafr6zhYJx4+nEdEcvmCwDkcMoCEYUoPOEveGkcK+MKx0LJQB8+esdCeMIX+MAq8IYCwljV4FgHaUeMIKVxh1ZVMBG4cmJcEkgCI23pUld4GpAY6NQgef8AdD5C4OpKVYh4onTMNWivW5MyYEhSnAUCwABPDmcOsWGyWYJQlKqkAOX9Ug32dAYtUVGOMKhUZlK+AjGuTnuxpFZ3h2SicqXfUoBCiWDC92bpBJGFcq8YtBMV/a80+/QgfgWo/wCpAjNujewWA8EQD31B84Fz9OHDzidlKOhcFMyClHie4wVQwy+sLcA4m+MGEzhxgiW1/fOFENdfurBuFI4oAioBgqUBNEgJHDzpCylDGnrGG86cBy+uEFhQLbOWpC00dSSkUwcNGfbL2clS8CQKVDGLTtXagQhkkFaqJ4HM9BDjYuzQhAJxNYxOWrYthjW7DWSypSKAQ8SlsusKlATUxA7z7TXLlX5YqVXQTRnBLgZ4RmMCsppLcbbxbfEkFCDemHLJPE/SKGFLWsFyVqUK5kk0gk2+SVLck1JPmTDRG2USlpWDeUhQUwwoXZ4rGNHPKdm6SpakysTebxb6xjMxalKJVVRJKuZx8YnT7U3SybMvh2hj0EVKXtZC1dolJJftBhXjFJfBGPyPxGt7jIazS/yv3kn5xkgjZd0kNIljRCfIQojkc2haAJig/poEVLebaN20zBoR/iI7G9Rmi7PT1nHCqEk4XSS+I5Pq0BSCccQT3Y61iVmjt8NygilwRQq/f3DDq0ILpQnHDmxLQNjoVXPhL7UGeG1XYmufodYTUgU4t2VZvjhwjO5ocqtbFsscMILNtjAHHX6w2QQBUcRh3Uw0hvOSLzMHz6YY8coe4thG27QVUJJGY8IhFbZny7xlTFBmN0soVxYKcQ/tZZCXzcA8Hb5RAIZRU5oUJ8hFcS3ZLK9kTdm36tKfiRLV0IPgW8IcK9pMxIrZknktQ80mKUZSySxJDliVEZwtKkKbH734lP5RbSS1NFyHtROdlX/rLf4Qon2krV8NmHVSj5JEQFvtstcpCEJKFpIvLvr7TBtNaxzZc4BKyvtNRISEjt5XyWJAcnN2Azh6EGtlt2pvTaRJQtHu0FaQr4SpQBD4KDd8Mt2baubMClrK1lKzePOUA2goaCImRb1LRMSpQISgMWAoD8JakLbry1FSGN15a6jEssOPAQKCp/Zicnavyi8iamrNkRQ9YQnWoAitD4YQ2NjP3lqNNWB7sh84S+wIbAlw/aJL8+McqTOoNO2mgZjiHGOkIfb3PZBIpRjjCqLIh+ykCmADUGUOkSOGhhOxqhFC1n7uOphZKFmrgYn5Q5lyvPzxhdMtg30whU2FjL7KrNXowiuxpet4iuekSig3hFd3h2gE/wANB7ajUjIacz5QNJIcU5OkRQSlcwkAXU0HFsT3xbbN8A4RX9k7POkTm0rSiXLJJAuhydAMTEkvc7KpJBFrvqAL3fNooW/u88kJTKQoLWlZKgn4UsGYnB64DSGW3N9FLCpVmCmUGMztJNcbgoRo8VT7AmWy5hcnBL1ObK4Hvjoxxek480k5bDe0WidODqVdRoKDgeMJSAkEJQgrWcAAVHoB67zD6VJXOVR0y9aAtXDjGlbg7MQmUsoSB22fMskYnHONfCJ/LM+TsS33bwkqSniUg9zvEPa1LQbk5DHjj0Ij0OqyJuCmcZTvdYwtc5IFUqVd5jKB2hKmVbY9sIUEE9hRZJORyHKPRmwEXZaRokeAjzPsxF6ZLR+KYgd6gI9PbMSyOkCQNmSb1TCbXOIB+Ju4AfKBHdp2omdN/Ov/ACMCFQzVEszKxoBkD+/GAvHT5v6xiOmW/AM9A+NDkfAw0mWxXa7BLuA4AocRWrRO0aoe2i0JAq7kmnxHSozpDSZahepgMakMfu+HKI202ibSgF3N6uxwHEPV4jVhaheKsWJozD6tjAMkptqF3tG9ewOAr17LABmEN5m0QlR7TMMHDB3yAAenjDJdjckEqNKAmmneCRHUWRF0G67HHF6tV8sTAkwsEzbDgAE6qA48ADnmXhP7ctThKFErcJOAA1rx1GkOfdBywxDktp8mrCiXoaOCRTMivn5RpIVkTa1zVVACQAwq2OjYYHxiP2aXxH3B4RO7SYIWMWGPFsulesQuzUfD+SOjFHZnPme6BJQwah6cXeOoHZfAXgMs8IXskhS1hCGvKLVLAZknQAOSdBEjZjIRLmlEv3pQUALXeurWtYAuIBACWCyLzksMMI2S5IpcsCl4d2MJ2WWe1zAfnhEvbbahKwibZ0UvAlDoWkihYglB6gw0FjCCFoVflrWChTMQx7SFj7q00fIggihjSB7HJllEuQog9ohieDZCJPdL/voGktb9SFfOG+2R/ApwA7q+Jgm71uRJnBcxTIuXSWJxCRlFYx9L+zIyl6lflGgplBhjQE/R4BRrkPE4wzse27PMa5OQo1BTeDkcjD0rFK5HqI897HpITQipyYU9esIWR9ISKsOXnCdptiJSFLWoJSnEnTTnGTQ8SR4+ecdveuUVWXtq0zy9nkAIJpMmm6/JIc97R2ZaLekfDIVQ0dY6PAInbfbghClqdkh2GrsB1JinbKlrnzDMUMSSDk504DKJBVonWhCpa5BQSUub6VJIxoRV6ChEOLbaRYrPfUHJohOalZDlrpEnbdHViSjFyY+m2tElHaIS2JPnFA3o2wq1K93LLSR8SsL5GX5R4xEWgLmLM20rK1HBL0AyCRgAIkt3tnC1rXeN2Uil0UvHidP1iqioK5E3kllemC/JHy9nL7AlILrLJWoXU6veNAGzhztvdtNnMsLWZi1JKl5IFWASNMamNGlSfehIQwTLNdGAZhFT37/76AMkDxJhxlKUbZjJjjBpJ2/crzDKkaDuMj+WJ1WryA+UZ6DGk7mIayI4qWf9x+kOPJOXBPtQdYyXaa3nzTqtf+RjXFZcoxuct1rOqlHvJjUuEZhyVzYVlfaElGXvgf8ASq98o9H2aksnhGB7pyr21ZfBa1dyFfON4ta7lnWdEKPgYUQZjU5TqJ1JPeXjkEgRgoakoM4OCu+oJIw0AbnDdcpRcZhiCevLJh1iVWAVFmw4eshDVUsXcHAqoGlCXI6Ux0jJki51nNMjmDSmJx6d8N/souqDPw1OJfnExaCAx1o3SGyQRSob4SeGdeMaoY1FlAUM7rOWLviMqv8AKE5ksXRh2jplk9dHhxNVn0JyOT6fFWGtoI7WQOOujDQt5wxCE0pvKLDCg168cIImhQMh4ElvrHVK7QyLOfpR6u0cvUTqTxwwxzNSYaAabQHYXVmD8TT6UiKsGKPy/OJHa6+xMUcGZNXdmc4UGERVhnNcDCoxzxNI6sS9P5OTM/V+CQsaC9pCASv3JCQASarQlbAZ3SrvMOtmbOUlEkLABC12haVHtdjsSU3Q6iCsHAff6RFrtRlTytgoMQpJwWlQIUk8wTDq0hZs612ZSppJkoQEJPvJSEdploS5BCkS+0KFic2glyKPB07AF9K50w/EyiVJQKlip1XioONE0Lw6QuUbOtEs0SuUql5gtQWCAVEqPYBepHZDNHP/AOAqaApaVpYVWslKQ5JLqXTFz1hzLsUpKUS0KUpKVFalM19ZTdfUJSmgHEnOHFCk0IbcR/BQOXkIJumi9PSMOwpvAw43stAEuSlqYDWogu7xSLRLuhQZBvOXdQBcilBhSOiP+Of2ZzS2yw+5YLTseRMAC5aDRnKRefgRV/pEYrYa0Ae5nzZWIuk35bjVK6gcjFmKnHFj3wmVPhn66GPJtnsbFclbanyW+0yryGYzZTkDQrR8Q5h4RmTkWy0y0BYXJQj3nZLpUq8EpCuVS0WRUnM6P3ZHh9Yj0ybPZr89VyXeqpVEvwbMmBAyQnT0Sw6lBKXzpwAGpOkQ+1NsXE31q92gYADtr5A/tzikb/7wGcBKQUCXeCgXdZIwUMgMcNccWJu7u9aLaErnrUiSn4piiXUEg0SVFnaj8ekVhFL2Jyb8jjZG99sClsUKSSWvJ+FqD4SMgOsN7ftFcxd5alTFmgo7P91CR8oJtq0SxMEmzS2AF1CEdtazWqiMVHM4DpF13Y2EJUpK1oCZ5HbLhRS/3UZCjP5wJRi9g1Sap8FRTsFd4m0q92kJCiHBUxyUcuQiZ3StkpUwSZSFgXSSopuhksBQl3L6RYrfsNE342WXxJLuMDwhtsbdwWeaZqVEi6U3TxIzbhEpJylb4OiOVRhUdmWizSwElgAGyjK9/rfdtpS4ohHzPzjVZc4XS5aMl3zN+1TCzp7IDjFkgUfjG8jqJHGrluRCbeMxGs7pH+UlHVJPeomMVm2Ej4XHI0ja91pZTZLOk4iWh+54xjbbN5UkiZtS7qSdEv4RjSdY1feGdckzCMpavBJjEZu0VBCnxZtMYpN1SJ41dslPZsL+0irRC1d5A+cbPvGu7Y5p/oV5NGQeyCW9pmKz92G6rD+UarvtMCbEviAO8gQ1wJ8mTwITvQImUNkXUAuQrjzc41wENFTPioKOG1z5Vh0tYDHEUHAUd693dCC0/dLNiNdcwRQkQGRs9GAJGhGGdODtDSYo9oAgnSt7SulcIc2lYapqC3XQ8D6MM5yi7mjM49McT4QAJzZrFOYFAXzwqW58aQxmLSxD1CnfXEs/INBlrdgK3jQEsQMHqKZnrDacui1DCoALNx+UMBvarddWhLOZj3sQyU1OGNSlPUw4CqF6XcGxbD5K74pNp2wZdrUpQvBKrrH8IcFn1+JoscnakpSHM1NalIoonABscBpGhDKbthM1NoSkNdN05gh6EdXHSGmyyVXK1AV4ExA7NQ0xQSTm4DsQ2J4VeJaXKmI+BSc6KTSuMduHG5Q9K9zhz5IqdSdbEsuyTJy1BCQohCSapTjebE8DCE3YNqCQEI7V8EFMyW4dhkulSO8QvJs61MU2lCFsxumagtoSAx74efYrWQAm2pcF3+0KflXlCljmnuhxyQpU0SKbPPKe0laqAgvepTifxJpjUQvLssxFVoIDkPk9QzjilXdEUvZ9sx+1pAZm+0lmAZmusQ0NLXsy0LDTLUhYd2M9ag9fwyz+I98NKfCRlvHy5Dze6aLsqocHDo/yg+50wmeD+FCieVB8xEftTZFqASmZLTLSKpYlRNGdwwAbI15RNbnSLnvFnIJQDq5vEf7UxbeOGcnw1RJOMs0YrlMtpKg10a4tHCs8Bpzhuq0PyOH68IJMtQAJJYZvQBs48k9cWtM8JSpS1MAK8P0jMtvbZTbFhKg0sKup/EXLAj8I8THd7N41zjclgmW4wB7eZNMsGeImWlN9NGZSa5UisYe7Jyl4GOwbEubMShCCtZwAD9W05xfN47ZaLyNnSEXbqUrWoKClqKnHaUOyhIrQcOUQns8BFpmJH4FilCwWiNFRLwPQcR5QnJpUg0p7sjN2dhIsyPhSZpHbWHfHBJOCQGpR8c4sCf14GE0UA6tB0r+nPlGDQoDifXKD+8PzhJJw9d8dHfDAUvwhaLMhYKVpSoYMoAwohDwomXXweCxFatu6UhYN0KQT+E07lRO2AXEIRUhKQkFme6Gwh2hFKcQOkBcknDmOLYiCNLgHb5IXevaCBJmAqqtBSkavSMa25MoEDOp+Ub5OsSFJKVpBTgQahjrx4xgG1ZQ+1TEAulC1BJ/pSWEEvVJMaemLRa/ZQlP2tYKLxTLDLci72u0OLv8A7YuftUnpEiWg3gpS3T2mT2RV9aGkV72QqQJlocG8VIYscADTvMTPtYtCCmSh3WFFTZhN0gnvIgm6iwxq5IzO+rUwIM0COPU/J3aV4NzKeyGHxFyknAYkB/KOcdGZ++nPnCuI7VFDmK/tBF4g4HPNsz1BjrRwjBa6BjTM1d8tc6YxHWl6pfHjVnbXmYk1JxYueNW/QkwwtEpWQJGTsC+A+cIYwmHk+GWB16CElgOxwZ306d0LrkKIZVAa4VxoDyhNdldnY6k517oAKRt/ZqVrC0mpoQ2LUvdWhjI2dMwAbifTxfl7ORVqesobKsSUi8cEgkjhnBbCkRW6NhlotiO05KV9lTG8LrGmmMXW0br2dZdN5B/pLp7j8iIx9FqWJhtAJSxJSQWIyAB4CLJs/wBok5LBdyZz7CvCnhHTiyShw6OfLjjPlWXizbloD35y1HK6lKe97zw5/wCjpeU1fcg/KK/ZvaQj78hf9q0nzAh/L9otmzlzh/bLP/OLfU5PJD6bF/ElRucj/wDZf+lEKq3VIlqQia4UQTeSCxGaSnCj0z4RGD2iWb8E8/2I/wDuOH2jyfuyZp5lA8lGF9Rl8i+kxfxLRJ2IpUlMmdMvpSzXU3TSgF4k0alAMIqHtKn/AGWVZ0Wfsdu8wq4Skg3n+JyoY6Ryb7RpiuzKkJCjheUVnuSA8GsNmXaD761pC5gIuJIF1CWoABQV60iE5tqrOiGKMXaXxfvQtY5pUhC1C6VJSVJ/CohyO+KNv1t9RP2dHZSwK1Cl/MJH9OsaYtIzwNK6/KIba+7sudQpF7H1+kSSpl3ujH0WwgBisEBgAWSWwJ4tlwiUsC3Qg9O4tD3bO6C5dUAs/OEtg2NawEJSSpKlONBRydAHxi0XZKSokdyDdt6w7OJg/wBwPyjTEKOLdPmNf0ihbr7JUm0zJ5cpQpaaCjqODn4m4UFK6X5KDUA1Z2xESk0mUinR1646/tClz0fMaQeVKduI7jDiTLoHxZi2DROzVCCUfUdIOmWRSuDj6P6xh4iSzcKeUKolAMdKQwGkuW+oevGHKJNTo4I+fzhVwM84IFvg+Y5cYEhBkSwPPvgq1hIqwAzLYQnMSo4lqYCIe2pClNU51LxqgIbfLe+XJQqWhV6YoFho710bjGPWP7yzjUv4k98TvtAmPa5mgCEjldB+fjEbYJLmWj8S0g9SPqIcfIpL2RsG4+z0WaSg3e2sJVMObkP4Q49oOxkT0KmPdXKQpQLOCAHKTzaJFMvtAcQIb77TrtmtH5Lv+ohPzjU0tLFBvUq8mMtAgKMCPOPTs3hEkspKlOOAIejnF6fSO+5DB64VNXhYqoSMKv0p1wgA0DZ+FI7jzRAyanKgfxhrOk0wb94kAO5hTPx9UhJYF00p44wgIidZ66YsIjZskgHmfrFlmIwprDWfId/DD00Kh2V5aOozH01iG3rXdsyynO6OQUQ47ni2LslK4Bq590Q28OzveSVoHxEUPFLFL11hoGZfJWS1H4fpEftKzsokAAOA2hLk+XjC6FXSxoNDkRz6eWsKW6UFJCgOYAwOtCfGN8ozwyORLEO5Uvie8xxFlUcPMQ5l2RYyHeI0kZbDypPE95h+mWloaosy9PGF02deo9c4dGbZNbsyQq1SU/0rJbk0aLLlMMe0MVZHOrDPGM53ZnJkT0LWTd7V4ghRqkgUTU1pGogOkKTSoehGPDupE5bFI7iClZ5HJqP+LUac4WSHIHANBhJ7SqEpLYUr5ZeELolgMaMM/nyiWplKQxmSQpIBDpNCDVtMYj07FQm+zHNwKlqhKjiRn0EWBMmjVxf00KIQKGmnXCGm0DSI2z2VjhiNKAigh7JlYahnMKhhRqhVPXB/CDEku2HJsDU6wUDZxEoDIUYj6+cLKUPIvBSg+vD5QqmWBlVv3Ih0KxMLcOBBrhONOA15wtR8sPCOv5+dYdCsTCRRuPWmEccN0/WOlXrlCE1WtKeeMaSEIWqcK+sYZykUKtR+0GWLyvOENv2xMmzzJp+4gluOCe8sIyxoxre+emZbpl34QoJfUpACj3jwg+wkXrXIT/7ED/cFHyiJshKlKWqpLknUmp9cYnNy03rfZh/WpR6IUfkI09kl5Et234NulJ7aeYiv7/zP5Zf9S0D/AHP8oskgdoesopvtHnNIQHa9M8kq+oh5O1ixd6MxmmpxgQnMm1OEcjio77PQ6VdkEYnLnWDHJiMS/Fg0EvUH4nSO6v1HWAtYJGL9pqGv6R1HCHSoPhWj8B+/lBAOySMrw5nVueXGO3+2ciwcjy1/eCJNVAhi6gDzwwPWAAxHGr1EJEVpiWx9GFLzpAND2T41+cdUASCaMSHo1cMOXjAMZLQQ4GGYw6nP94h7b2as6S3HHX1lFiWiod66U9UhjbrIF3ge8fPWEBkG+WzAiZ7xA7Cz2m+6qp8Q7cTEFZpv3VVBoRjhmAaEjU8eEaTtSy35akLGdXOBfzpjwjPNq7OVJW33T8KtWyPJnPONRYmiS3ds8pU0SZyim/8A9tYPZJ/DVnfJhieMW/8A6MQU3hMUMaEDAa0x+cZ5KUFpumhyNAR1+6jh6GlbjbyJmj7NaGE1IZKzS+kdAxDAB6locl4EhM7mJBT26HhXg9IcSt0UJvP2q9mjBuOesXL7O7ijh/Q4GFLicaVo0YNkVsvZKEMUpFKOAAXfGg6cIlkSQFMRRwcfVRjHEMCWq9dccxw0plBk3iBQBsH5Y+dIVDs6KBzQgsRR9APF46VgHJm8cMOkAIdqmtaZZ+MdSgBmzP1YePhDoQQFTuzM+LDHP9IPc1Pdg5NBriYUINTnjj9OEFWvEl2bu/X6QUIASBozdXxfzg48wwehgoPCrV+nKOq+XUawwD0IrmK9PH9oO3lCRevrp3v3wbWGICm7qdI4A1TqXxzwgKZzrSCLVAAFnweGU1b6uzQeatw3rpBUJcvA2COyUN4xn/tW2ndlIkDGYbyvyowHVRB/tMaHMNKeshGFb3bR+021aknsJNxOl1DgnWqrx6w6CyOloZAGav38osns6l3tooP4ULP+27/yiAAdXKmGZi3ey+z/AM6tRylKHepP0jDdzS8G0qg35NalCvQxm3tUndmSjUrV/iPmY0pNAo8Iyf2nreZLH4UE/wCpR/8AmKZO1k8XcigGBBYEcx0npUpJA1BFTnqPF44yVEapJB9dIECKsgdSl8aFmBB4nXrBjKciuLHSo0074ECAASQ5KXNGNcWIPBo6hAulyzaf0nrTrAgQDOrQCBkxHTLSCTUZiowPR9YECACt7Ys4SpgGBCqDF6nkM9YjpmxUT0qlrAIoAcFNjjwHfhAgQDM129saZZZplqIJxSoYKGrPQcD+xbOu+ElJKZiS6FChvBmDjAAs3ToIEUiTkaZuTvQbQDLmUnISAVMWUkEAF3JKiSp3aLgmWCkVcHHEUxECBGGaQdQugaEjmA1AOrd8KBJdQJfMcMad4PfHIEMDt6gOdAfXfASMeJofPxeBAhAdd35+H7vAUfi8eMdgQAFzxxFOfpo6pWeYFeI9PHIEMAxHHKh9dIClY9/MR2BAITmVNOBBgqjx18IECGA3FQeArCk6cEDU4ga/KBAgQMq++G3VyLOtQYKIuIxJdbhycKBzGO2FDAq0p4P5ejhAgQ48ikaTsDdCXMsktUwkLWPeXk/EAqoGhDNTnEpuzsBVjmzFlaVJWhKQwIUGJJcVGmcCBAkrC3Rb/eAoURwjKN/F3rSR+FCB3ufnAgQ8naGLuKeqxRyBAjnOg//Z",


        };
        return urls;
    }
    public static String[] getAppliancesnames(){
        String[] names = new String[]{
                "Washing Machine",
                "Tv",
                "Refrigerator",
                "Fan",
                "AC",
                "Carpet Clreaner",


        };
        return names;
    }
    public static String[] getAppliancesdescriptions(){
        String[] desc = new String[]{
                "30% Offer",
                "20% Offer",
                "15% Offer",
                "15% Offer",
                "15% Offer",
                "15% Offer",
        };
        return desc;
    }

    public static String[] getAppliancesprice(){
        String[] price = new String[]{
                "25000",
                "20000",
                "18000",
                "4000",
                "30000",
                "2500",
        };
        return price;
    }


    //HomeCeremony



    public static String[] getHomeCeremonyUrls() {
        String[] urls = new String[]{
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Home/hd20.png",
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Home/hd2.jpg",

        };
        return urls;
    }
    public static String[] getHomeCeremonynames(){
        String[] names = new String[]{
                "HomeCeremony",
                "HomeDecoration"


        };
        return names;
    }
    public static String[] getHomeCeremonydescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "25% Offer",
        };
        return desc;
    }

    public static String[] getHomeCeremonyprice(){
        String[] price = new String[]{
                "25000",
                "33000",
        };
        return price;
    }

    //BirthdayCeremony


    public static String[] getBirthdayCeremonyUrls() {
        String[] urls = new String[]{
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Birthday/b11_prev_ui.png",
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Birthday/b8_prev_ui.png",

        };
        return urls;
    }
    public static String[] getBirthdayCeremonynames(){
        String[] names = new String[]{
                "With Decoration",
                "Without Decoration",


        };
        return names;
    }
    public static String[] getBirthdayCeremonydescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "25% Offer",
        };
        return desc;
    }

    public static String[] getBirthdayCeremonyprice(){
        String[] price = new String[]{
                "35000",
                "25000",
        };
        return price;
    }
    //MarriageEvent



    public static String[] getMarriageEventUrls() {
        String[] urls = new String[]{
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Marriage/mar15.jpg",
                "https://i.pinimg.com/originals/14/76/58/14765886e92bc7150b7bfaa714ca32a0.jpg ",
                "https://5.imimg.com/data5/ANDROID/Default/2020/12/XV/XD/ZU/15513705/prod-20201229-091844383910326006642889-01-jpg-1000x1000.jpg",
                "https://5.imimg.com/data5/IK/NC/SE/SELLER-82006211/img-20200302-wa0002-500x500.jpg",
                "https://i.pinimg.com/originals/8c/e7/40/8ce74055e491f96e78c9679a60785356.jpg"


        };
        return urls;
    }
    public static String[] getMarriageEventnames(){
        String[] names = new String[]{
                "Marraige Event",
                "Marraige Event",
                "Marraige Event",
                "Marraige Event",
                "Marraige Event"



        };
        return names;
    }
    public static String[] getMarriageEventdescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer"

        };
        return desc;
    }

    public static String[] getMarriageEventprice(){
        String[] price = new String[]{
                "35000",
                "35000",
                "35000",
                "35000",
                "35000"
        };
        return price;
    }
    //HaldiCeremony



    public static String[] getHaldiCeremonyUrls() {
        String[] urls = new String[]{
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+C/Marriage/mar12.png",
                "https://images.meesho.com/images/products/215662082/o3wfb_512.jpg",
                "https://5.imimg.com/data5/SELLER/Default/2022/10/UW/DM/SW/150930028/haldi-decoration-in-bhubaneswar-1000x1000.jpg",
                "https://i.pinimg.com/originals/4c/1d/ea/4c1dea856388879fa5ea59fa90c73bff.jpg",
                "https://www.shaadidukaan.com/vogue/wp-content/uploads/2021/01/1.jpg"



        };
        return urls;
    }
    public static String[] getHaldiCeremonynames(){
        String[] names = new String[]{
                "Haldi Event",
                "Haldi Event",
                "Haldi Event",
                "Haldi Event",
                "Haldi Event"


        };
        return names;
    }
    public static String[] getHaldiCeremonydescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer"
        };
        return desc;
    }

    public static String[] getHaldiCeremonyprice(){
        String[] price = new String[]{
                "35000",
                "35000",
                "35000",
                "35000",
                "35000"
        };
        return price;
    }
    //SangeethEvent



    public static String[] getSangeethEventUrls() {
        String[] urls = new String[]{
                "https://i.pinimg.com/736x/01/76/a8/0176a868bdd7115810be32104d2bf2f7.jpg",
                "https://i.pinimg.com/originals/6d/c4/50/6dc450c5b255acaabcbd5fa3aeedad9c.jpg",
                "https://i.pinimg.com/736x/2f/58/4d/2f584ddefd1afc8bb320d2741957b85a.jpg",
                "https://eventmanagementudaipur.in/wp-content/uploads/2019/08/2-1.jpg",
                "https://i.pinimg.com/originals/15/6f/fb/156ffb9097e69cbd90d35ad11dea7dba.jpg"


        };
        return urls;
    }
    public static String[] getSangeethEventnames(){
        String[] names = new String[]{
                "Sangeeth Event",
                "Sangeeth Event",
                "Sangeeth Event",
                "Sangeeth Event",
                "Sangeeth Event",



        };
        return names;
    }
    public static String[] getSangeethEventdescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",
                "20% Offer",

        };
        return desc;
    }

    public static String[] getSangeethEventprice(){
        String[] price = new String[]{
                "35000",
                "35000",
                "35000",
                "35000",
                "35000",
        };
        return price;
    }

    //Toys



    public static String[] getToysUrls() {
        String[] urls = new String[]{

                " data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExIVFRUVFRUVFhUYFxUWGhcXFRcXGBcVFRgYHSggGB0lGxYVITEiJikrLi4uGSAzODUsNygtLisBCgoKDg0OGxAQGi0mICUtLS0tLS0tLy0tLy0tLS0tLS0tLS8tLS8wLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIANQA7gMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAYDBQcCAQj/xABCEAACAQIDBQUFBQUHBAMAAAABAgADEQQSIQUxQVFxBhMiYYEHMpGhsRRCUnLBI5LR4fA0U2KCosLxFWOy0jNDc//EABsBAQACAwEBAAAAAAAAAAAAAAACBAEFBgMH/8QAMhEAAgECAwUHBAICAwAAAAAAAAECAxEEITEFEkFRYRNxgZGhsfAiMsHRFPEGMyNCUv/aAAwDAQACEQMRAD8A7jERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAERK7t3tKlEFUAZ7NqdEUgfebifIa/CCUISm7RRuMbjadJS9R1RRvLG3/MpO3faKKZy0aRa4uGqAgEcCqjUjz0lR29tPEuVNQnvHQ5hmuQjE2Q0yuWmbctTbW002Mrs7XcAEACwULYDcLDqZKx1Gz9hQdp1vqWfHLlw17796N1jO3WNqH/AOXIOSgJ89/zken2uxgN/tD+rFh8DNNli0ydDHZ+GirKnG3cjpHZv2iBmFPFAC+gqqMo/wA6306idDRwwBBuDqCOIn5xInUfZZt1qiHDubmmMyk78twCvoSPjMNHNbZ2RClDt6KslquHevydAiIkTmRERAEREAREQBERAEREAREQBERAEREAREQBMdSoFBJIAGpJ4SLtTaVOghqVWyjcOJZjuVFGrMeQlC7TbTfEC1RzTol9CniWwGq191je/lpbfeZSLOGw0q00tFztfy5vojYdoO0b1AyUe8VV9/KgNQrr4srkeA2O65PoRKhitpCmR3bGnp41ypq5+8F17veSdR0kTHbSzMiYcEBV7pWPvleO73Qf6tukHH4dKa5cwdzvsbqvlm4npoPOZ0OuwezYU4KM1rwyv3y4dVxWmqPlbGMSTexN8xvctf8AEd/wsJGDCYu8mM1x+IfESLkbxbsOhMDCfGtI+efe8i5JSR9Jlu9lKk40kblpVC3QlQPmRKY73E7F7Nuzxw1A1Ki2q1rEg71W2gPIkkk9QOEXNNtvEwp4WUXrLJfny/XMukREHBiIiAIiIAiIgCIiAIiIAiIgCIiAIiIAmt21telhqRqVGtbcOJPICedu7XTDUjUbU2ORLhS5AJsCdALAkngBOYY/b+Z82JsxK95SdVNqZZbooVxY24G2/fxIyi7g8FPEO9nZctX3fv0byJW39tln/b38VMtSKAK9HPcZbNuBAFzodfhT2rEjICQt7kfibdmbz+k900qV6nFmJuTfd5kncBMeNKqcim/M8zxtyHCZudzhMJTwyUFrk3yXX5rrzMZrWuAd+h8/IyO9TmZ4J4bydwnUexHYBVy18Wt30ZKRtlTkXH4v8O4cbndBttkcftClhYb09XouL+fOCKj2d7D4rFgOQKNI7mcHxflXQsPM2Gul5ttt+zGtTTNQrNWIGq5VU9VF9R5XvyvOwRMbpyNTbWLlU3lKy5cP369x+YMRRqUmy1Uam3IhkPwYD5za7J7PYrEkClQqMD95h3adc5AHoCT5T9FRMbpZe36u7aMFf08svW5Q+yPs/TDstbEFatUWKqB4EI4i+rsDuJAtwF9ZfIiSSsaaviKlee/Ud3805CIiZPEREQBERAEREAREQBERAEREAREQBIO1doph6TVahsqi/mTwUcyZOnGfaP2j+0Vu6pt+zpm3kW1u/puH84Rd2fgni6yhw1b6ft6I1u3+0tTFPnI0DXC3uoUEFVK7jYgm/G/lIOMxb4ipme1yAotoABc+eg1JJ85CSTMGt9L2ubX4gDVj8LfOZud7DD0qEU4RStp0vr86Eh6/dU7LozggHdcbix5a6KOABO+xmlqPJGLq5mJtbkOQGgUdBYekx7Nw/e16VI7nqoh/z1FU/ImRbDapQcn3v50R0r2Y9kgFXGV1uzeKip3KulqpH4jw5DXedOlzHTpgAACwAAAHADcBMkJWPnmJxE8RUdSfH0XL536iIiZPARMOIrKilnZVUb2YgAdSZWdo+0HAUrjvu8I4UwW+DGy/OD0p0p1HaEW+5XLZE5djva4gP7LDkjm7gH91Q3/lIae1qtfXD07cvGD8b/pMXRdjsnFy0h5uK9G7nXYkHZGPWvRpVlBAqIrgHeMwvY9N0k1qyqLswUcyQB85k1zydmZYmuO28Ne32mjf/wDSn/GScNjKb+5UR/ysG+kGXFrNokREQYEREAREQBERAEREAREQDQds9pfZ8HVqA2YjIvV9Ppc+k4OW4zsXtYQnAi3CqpP7rj6kTjamZOx/x2nFYdy4t+yX7ZnItaSMO1jfyYD/ADgr+vymBl8wek9vXuqiwFgRpvNyTc8zrboBInRSzViNUmXYWJFPF0Kh3JWpsegqJf5SO5mXY2BbEYmjRXfUdV6Le7t6KGPpMFTFtdlLe0s791j9KxESR83EqPbjtimBTKtnrsLqp3KN3eVLa2vew3m3UjbdpttphMO1Z9baIu4u591R+vIAnhPzztXaL16r1qjZmY3Y/oOQAsAOQEw3Y2mzMAsRLfn9q9Xy7uflxuZttber4l89aq7HeLnRfyKNF9Jqy0+kDl9ZKw+BF/dueW8Dr59dB9IanVxhZbsEkvJEOnSdiCosPxHQenP0mz7sfeLN8h+t/lJAoNcbzfcBc38hz9Lzd7O7KVamrkIPPU/ujQfGQqVqdFXqSsek+yoRvVna/wAySz9CJS7S4paS0UrulNBZVU5bDf7yWJ47yZBq4iqxuxJY8Tck+p1lvXYmDoDNUfNbi7BVueGlgek2OEeiFzUadPL+JMtvPUShU2vCK3oQbWl9FfvzNW9q4Wk/+Gnd+C8eL9ClYbZ2Jb3Eqn0YD4mwmww+wsYpzKSp597Y/Izb4/tBUSr3WQe6GF2Zc1wScllIsADqSNZMwuLFdA6l1zZl1FijDSxHMb+Wk862OxkIKo6aUXbPXW9tHxs/7yKD/wAinOThBRuuFm/dpG57KbbxSsKWLQkNolXRrHgKjDgd1zbXnfS8zjWEwWMpOLMzWYXbvGdHW4BLioxKm2Y3XjYaiXzZm2WGhNxyP6GWpY+nTkozlFp8Y6eKzt/admjRzr/yJOfZ7r4pKy71w77ZdC0xMGHxKuLqeo4iZ5fTTV0eYiImQIiIAiIgCIiAaztDswYnD1aO7OvhPJhqp+IE/P2Kw7U3ZHBUglWB4EGxE75tmuxK0U95t/6D9T5TSdo+wdLEoCGyVQAC9swe3B1+hGvO8rQxG/VlTiso6vrrZeGvLQ3myccsJlVf0yz7uF+56eBxvNPheWzE+zfHKbBEqDmrqB/rymZsF7McW5HeNTprxu2Y+iLof3p7nSvamFUb9ovP8a+hSDdiALm5AAGpJOgAHEzsHs37HHCqa9Yft6i2VP7pDrb8x0vy3c77Xs12Lw2E8YBqVf7xwLj8g3J9fOWiFHizmtp7X/kLs6WUeL4v9ITFWqhVLMQFUEknQADUkzzicQtNSzmwH9aDjKH2429UfCvkplaJKqKh3ubk2HlZTe1/SQlWhGag3m+Gvi+S6uxqqFCVWSS0btf5r4FO9p/aQ4qoi079zTuNdLsd7kcrAAX1GvOUXMZt6VYEFX3GQcThyptv5HnJSR2dGgqNNQjoj7gKd/Efu7uvP0/rdN7s/BNUZVXUm58gBYXb+HTnpApUwq5eX9E/G8vXZnBd3SDEeN/EeYH3V9B8yZTxmK/j07rV5I9sVX/h0E19z0+dF62J2E2cqHMfE5ADObXNtwHBR5Cwk4ICLTypmZROUnOU5OUndnIzk5O7NPtTZYqAKSUZWz03ABsRxsdD0kLY+w+4qsxqAiouUooIUnfmsTpxsOFzLUFBFiJqdrYWpkdaRCuV8DaDjqL8DbTyvLdDG1lD+MppQlk76JN+LtfPLTOy1KVSjBz7W2azy7v0Z3wwIAZFe2ouBcdL7vSRmxVKgFVhlDE5URGYm2pOVAeJ1PnNPszEYlKtNT3rqQq1UqK5ynL4nWqRbQ8ASDw8t5jdmpVADXBW+R1tcZtCDfQgjQgz0nh44epGnWneDz+nh4d/JO60bPONTfg504/V1+enmZKWJp1Uz03zLe2hOh00IOoOo0M0uL2tXpVGDLTADeBWBXMnBhUva/PgOO8TY7K2UlJ2IbMXCg6ZRZL26tqdSZtGQ2t9RIxrYahWkox7SD03snwfLwvZN8LBxq1ILPdfT586mTZG0Syo4upZQwvvFxexlqwOOD6HRuXPzE59jNqrSYIUd2IzeHILDMF3uwF7kCwm22TtNKy3Qm6mxBGVlYfdYcDPbDVq+FSm4vsnpneyby/Sb18iTlBvd3lvLX8l5iQdmYvOtj7w3+fnJ06SE4zipR0ZARESYEREAREQDT4P+01L6m2n+n+U3E1GPU0nFZVuLWcD6/T4SVR2nSYaOB10+soYapCk5Upu0t6TV8rqTbTXPWztxR71IuSUksrL0JsSL9tp/jX4iehi6f41+IlztIc15njuy5MkSDjccE8IGZzuUTHXx2bwUvEx48F8yZlwWCCeI+Jzvb9ByErSrSrPcoPLjLVLouDfouN9D0UFHOfl++S9eRFpbMznPXs54JvQenH6dd8rHtdqWw1JedW/wRh/ul+nH/altSpUrHDmwSkQVta5zKCSSes9oUY0o2jx8W3zb4subPjOtiYvlnyy6FBI1mQHS3Df68xMSkg2b0PPrMiz11O2gsrMm0KYLAG1i6A9GYfK150jDjQTmaPp66Hp/Ql82HtNaqAcRoRyM0W2YS+mXDT53mq25Cb3Z8NO7j6m0USQkxT3TM0BzjJRF9fj15+v8Z8ekGFj/wAeYhJNpKpG+x+X8pjVkGaGrRINiT/GaRO1SgFnp2QHKbPmdb5rF6eUAe6dM1+st2Ow1+VxqCNfSaHHbFo1CS1LxNo2VmXNbXxBSL7pewM8JGTWJi2stNVz5arjw5WbK9dVmk6TV+p72jQNeky06mXOqlHBNjqG3jWxGh8jNXs+hiKVVMqMqE2qIWDU8ut2U30INrW1PG2ssWDwZCBcoUAWA5AbgB0tM/2NeJJ8twkqWOlRpypJJxd9euXDJ5W1vZq6s73xPDqclNuzXIgYrA03ADrfLqpBysvQj+jPuz8AKZYqGu9szNvOUWUcBoJswANwAnipVldV6vZ9lvPd5Xy1v72fVrO56ulDe37Z8yRhMVkdW89enGW2cw2pthKdwCC3L+Ml9iO05LrQqNdW0Qnep4C/I7utp0OyVNUmpLK+X5/BZez6sqTrJZL1XFruOiRETamuEREAREQBIr4GmTcopPQSVEjKKkrSVzKbWhE/6dS/u1+Ef9Ppf3a/CS4kOwpf+V5Iz2k+b82YqVJV0UAdBaZYieiSSsiInJtv9kalfE1arYp7mo2RAAVCg2UOSLnSw0ta06zKLi9qg1mYo2QuQHtpobDhu0nnVqwpq83b58z0LWFdVSfZfM7/AI049TlO1dmvSc03FmGo5HkR5SIh/nOt9p9ijEUDb31GZD5jh0O6cpxSaht1vCw5cvW9xJnY7PxyxNLef3LJ/hnxTM+ExLU3DqbWOn8DzEjAz6DMuKaszZ5NWZbMH2tNwKlNbcSoKnrYsZZMHtBH1QhgeIInM1nujUINwWB5gkH5TVYjZNKf+v6X5p/nyNZiNjUan+v6X5r9+KOvUGBmVWnLcPtiuugqn1Nx8T+slp2ixR0zKT5C/wBJrZbEr3ycX5/o1k9h108pR82vwdHBvu16TGXAnO22xi99yvmEI+FxIlfauIb36rk/nYfS0nDYlW2ckvN/hCGwqz/7R8Lv8HSquNUDVgPlNZiu0lFfvg+SkN/Kc+LMdSxvzOp+JjLLdPYkF982+5W97+xdp7Agvvm33K3vf2LRie15PuJfzb+AJ+s1GL25Vqb3sOQuvz3zWkQJsaWz8PTzjHzz9zZUdm4annGCv1z9z2zzPgsQyOrccwI9DpPmz8E9Z1p02VHchVZxdVuQLkfe36DibDjNTS72jjKuEr5TWpMAxQBUqL4bNkAADAMrXAHhzX3CW3kVsXtCjSxEcNJX3tXwV8l339L3P0lhq4dFcbmUMPUXmearsu+bCUD/ANsD4afpNrInBzjuSceTa9RERBEREQBERAEREAREQBOdtVZajU3F6WfujpuO7f8AOdElN7RYQLVbMcqVGWoG4ZgAGU8r2vKeNUt1Si7Wfg+j6N6lrCOO81Ja/LrqkZtischQnWmxQ+YG75ETm3bfZoo4pwB4KgzDlc3zfMXnQNk1rmq43M+nnYAXlf8AaOoNNHP3Tb94gfWTw0k6UbaaLuTsn4qzNlgK7oYy745PxSfuc6Wm3pzmUKOV+s8sslbC2HUx1c0w7U6NMA1HTQkncoPofhPe9jqK+IhQpupIwdyOHh6QLg2PoZ0er7PaPdBaTuHF7M7F7/muSZRsdgXou1KstiPnyIPETJjA7Ro4q6hk1w+WI6NPRAN/oZgGhsfQ85lEybJGSkFsTmNxuFv1vp8DJuzMCtYMvehKlrorDRz+EOT4T1HHrNdPdOZTMTg2nuys+dk7fP6aJuG2ezFvC1ksCALszswRaSj8TOQovoNSbAGV/a21cRg6/c47CGiGAYZSrOFJtmDapUGh0GXda6y2l6jbNxhoFvtNB8NiUIPiy0nzFxf3soWoSOnMX5h2y7U19o1hWrH3UCKoCgKBqbWAvdiTrrrbhBxe1tqYn+Q6cJOKjlk7XfP9cLF4qpaxuGDKrKwvldWAKst+YINjqL2Os8AT1haAXCYG2b+zsfHa4zVGcjTgc6Mv+ErPkknkdNsvEzxGFjUnrp324kvB4D7RTxGHVstSrSPcm+X9tSdKqKDwv3RX1lG7K0apxjtVViyLVFY1M2ZGcGmpa+ubvGRdeJlvRrEHiCLdQbj5ibXH7cNUKrE6EEAszEkAgE31NgTvufOYZqdqbMqVsXCtD7cr56WfLqjpfYHHCpQZONJwvoyK4PxZh6S0znnsrRs2IcjRu7+IzWHULa86HInObSgoYqaXO/i0m/cREQUhERAEREAREQBERAEjY7CLVQowBB5i9jwMkxMNXyYTKpWwb0rDIbcMgLD5DSVbb+ycZi2VKWHcIDq9S1IX3C4bxW1vopOgtOqRMbiWh6RqtO5yLa/s0qUaAehUNZwL1EsBc86P/qTc7weEy9g8JUTDk0wFZ6tR3Jve4OQJa2lshv1nWJRtuJU+0MlO6+Ivoct7qjE+fiY+sr4p7tO+fD7dc3Y2NLGVa1PsJtWTvd9OfPobbZuLzghhlddGX9R5TX9s9hDE0cyj9rTF1PMcVMxU65tTrHRlbu6nC48xwP8ALlLGjTGErupCzd2rZ809G+T1T6pnhNyw1WNSnk/ZrVd3Lozg7LfQ7xp8J4B4GWDtxs8UsUxXQOFa3Im4NuuW/r5zQ3DdZa1O+wmJjiKSqLyPSz6BMdiOF/MR3nX4TJaubbYu0TRqBgxRhcBwA2W9rhkJAqU2suZLi+VSCpUGZMTsHZbVDWNCgDfNlpviChO/+zlUVPy95lHmNJqFudwM+lOZ9BJampxmyMLiqvaTunxtx9H6WJe1Mf3jljysBobAXsNABx4ADcAAAAIYufKAwHlIabZoZ8jVQhtclw6gDT8Kkkm+gAgtTq4bBU1GUlGK0+a+RM7gcbn+uUkYalcgAbzuE1NKsa9RlW5oBLZindmoxOoF2JC26HpOqdgOzBuuIqrYDWmp48nPly5yJSr7Upwousk7cL5Nvonn4v8AV7b2W2X9nwyIRZj426nh6AAek3MRBwtSpKpNzlq8xERBAREQBERAEREAREQBERAEREATQ9oqFilYC+Xwvb8J4+hm+nh0BBBFwdDIzjvKxKEt13KJWBWiQxBapUuLW13WItzsPjLCjyHX2MtJ8+W4vcNrYdRuB+U81cYqjfc8APET+VRqfSU8NRlTk3Lkks28k27ttLNtu5brVVNJR6t8NbZW6JFZ7ZYcVKxX/ta+rm30ac8Y2JHmVPUGx+YnUKew8TiqpdqZpU2IBL+Fu7W+irvzG7HWwGbjaSdsezPDVCWoM2HY3JA8aEniVbUehEtq9zZ7N2lDCvcqPJ8s7P8Ao5SlY85kFYy0Yr2bY1Scvd1BwIexPUMBb4yA3YnHg2+yn0emR8c0mdLDaeEkrqpHxdvexpTVM85pYKXYPaB/+jL1qUv0Yzb4D2Y4hjerVp0xyGao3+0fMxcjPauEhrUXg7+1ykXmPBdl3xFZmpo7u1r2UkiwA97co04zsey/Z7hKVi4es3+MgL+6tgR1vLVhcMlNQlNFRRuVQFA6AQ8zSY3btGdlThvW0csknztr7FJ7Jez9KIV69mYaimNVH5z98/LrL4BPsQc9XxFSvLeqO/suiQiIg8BERAEREAREQBERAEREAREQBERAEREATzlHKeogCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCIiAf/Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUSExMVFRUXFRUVFhcXFRUVFRUXGBYXFxcVFRgYHSggGBslGxUXITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGy0mICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAPMAzwMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYCAwQHAQj/xABGEAABAwEFBQUEBQoDCQAAAAABAAIRAwQFEiExBkFRYXETIoGRoVKxwdEHMkJy8BQjM0NigpKy4fEXU8IVFjRUg5Oio9L/xAAbAQACAwEBAQAAAAAAAAAAAAAABAIDBQEGB//EADgRAAEDAgQCCAUDAwUBAAAAAAEAAgMEEQUSITFBURNhcYGRodHwFCIyscEGQuEzUvEVFiRi0iP/2gAMAwEAAhEDEQA/APcUREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRERCEREQhEREIRFqfWaNSFiLUz2gqzNGDYuHiF0Alb0WLXA6LJWLiIiIQiIiEIiIhCIiIQiIiEItVWqGiSVtUHa62J54A+5Z+I1vwsWYC5JsFZEzOV1PvA7gsBeLhqAsKNdoEQuevUBOS87LiNQGB7Ztf7QAmmwtvbKpWzW1r8hkeB+HFdaq1RxaQ4ajMKx0KmJodxAK2cIxJ1U1zJRZ7bX5EHiqJ4cliNityIi2VQiIiEIuG3WmO6Nfcu5QlsMVHeHuWXi1Q+GD5NCSBfl7tZWwtDnar7Rp4tSsbRTDd60OeVg55XkH1EIjLSzX+5PBjr7rZStbmGRmN44qdo1A5ocNCJCrj3YhCl7mkUgDqC73mFsYBUP6R0N7ttcdXMfwFTUsGUO4qRREXq0kiIiEIiIhCIiIQiIiEL4VAWmmQ9+e8x4/3UhbbXGQ/HRRJJcYEkncvK47WRPLYGDM4HhzItbrTdOwi7jssCVg566qt1Vcow9Jz9yxZdFY6wPGfcsX/AEmrJsYjf3x2TYmit9QXI+XEAZk5BWizUsLGt4ABc9hu9tPPV3Hh0G5d69XhGGmka57/AKnW7gOCRqJhIQBsEREWyl0REQhFw3hZMebfrD1HBdyKqaFkzCx+xUmuLTcKrVSWmHSDwK01KqtdSmDkQCOYlYMszBmGtHgF59+AEn5ZNOsa/eycFYBu1VykDE4XAcYMea3UaxbmCrHC4a92sdmJaeWniNFVN+nnMs+nk+Yc9PAjb3qoipDj84SzW8HJ2R9P6LuBUC+zuYYMZ6EaFdVlrlkB04SY+6fkmqHEp2vMNW2xHH14a8CNFXJE22ZilUWs1WjUhRtvthLS2m7C72sIdHQHf1WvPVwwC8jgPfJUtYXbKVK5Kl5UW/WrU29ajR8VU62zzasdtXtVYzo6q3Br7DWgRyXaNmKGHDgaRERGH+WEmzFo5ATG1xt1epCaNPE213HuFvufRTjb2s50r0j/ANRnzXYxwOYMhU91wWVuQs1HxZi/mldFlf2LcNICm2fqtADZ6DJIf7kia7K9ju63qpPpWn+mT3q1Fclsrxl4np/VcTbxfy8lrfVLpPHVdqcdp3sywk3PVw927rqlsDgdVqbTL3ADU7+AG9TFlsrWDLXed5UdSc4OxCJiNy+1L1c1wp4C95BdkYEAgE+o81HBGQNfaxzuvZxFtByJ22JKKlxDbnYKZRV2rfVWJwtYP2j/AFzXPVvit/mU9NxHyXqxA48vFZ5qWDn4K1oqO+/6u6p0yAB6ZSfJddyXw51UB9QmcTS0xH1cQOWhy9VM0rw26rbXRudlCtqIiWTiIiIQi11aoaJcQBxJgLYojaN0UcUTDmkg6cPiutFyAoPdlaSu2peFJutRvmD7lzPvyiPtE9AfiqXRvLCMmtyyzByjnKPvd/tDyiOid+CI/wA2WecQHD7H+Fb3X8yYDHk9APitb9oWAEuY9sCSSMgOJ5KmvvR51e4/jll5rktlvLmOaXfWa4ZmdWka79VI0Qt/JVYxA3HoPVei1A50FzgN45LAtbvcT4KJo2sOYx/tMY7zaD8UNcL5jJWm5zMueJc4m9urZepZCbAgqSe9nNcr3Z5LkNoX2naBqeiRlkdJwA7BZXCIhd7XLYbWeSh6lsPGFx1bVzU2VUrP6ZspClLt1NueDvXLaFCPtPNavy2N6qMZfqd+atERarEy1CENqUJZxUrOw0m4nRJAIEDiZOikqOztqOuBvV0/yhOMoKmcXY0keA/Cpc6Nv1FdBtQ4qC2othb2VQSf0lMxM97A4abu4VZLPsw77dbwa34k/BTFguxlLSSTqXZlbWD4VPS1TKhwAy8L9RHWkKx8c0Lo2ncb2XlbLxJ3ehy6SNea2Me90RTJnMQ0nPw1XrnZjgPJZBe4+PPBvmvP/wCkt4vPgF5bRu+0v+rRqcJLSPMuj0UhdFx2ttcOdTwt1nE3LuuGgPML0NfIVbq15FrBWsw2JpBudDfh6L6iIk1ooiIhCLmt1lFWm6mdHCOnNdKIXCLixVXobG0gO9UqE7yMLR4CCfVb27IWcamof3gPcArCisM0h/cVUKeIftChaey9lH6snq95+K7rNdtGn9SkxvMNAPnquxFEucdyrAxo2AUdWumm4l2YJMmDl5LX/sSnxf5j5KVUPtVf1Ow2WpaamYYMmjV7jk1g5kkJN1DTONzG2/YFcJXjQOK+uuaiBJLo++QFTr9vuyUauBtopGQIY0vq1cUkEYWBxI0iBxXl1Xa62XpaRTqVjTpnE5zWaNaBJDBpO6TJzmVfrjs1KjTIpMDOJE4j952rvEqiXDIZBbI0DqAv48PNTbO9uuY/hcdv2mY0FzqVsc0AmKdnwZDWTVcHR4BV22fSNY9GWW0eNQD3OKltrrWGUKrpk9m5o6vy+K8cqDNRbgtM0318bfZWfHTc1fqn0j0/s2OfvVh/8LKzba1q36K7y/7rnOA8QyFFbA7LC1vNSqPzLDETHaPicM8AIJ6gL2CzUGU2hrA1rQIAAAAHAAJ6LA6V3zOZp2u9UlPjEzHFrTr3WHkqbdm095UHY2XdWAlpLQ6pDo3OAYZGZy5lWL/GGtT/AOIum0U9xILon9+m33qVaB1JWq025tOcwI1gwB1Mp6PDms+WPw1P5ST8TLvmkCk9lPpNsVucKbMdKoTGGoGiTwDmkjzhXheM2u9KFUjEKTiNDg7w6PAn1VsubbIiBWhzNMbfrDm4b/f1U30MrRfdcjxOB7rajtV6RaqVQOAc0ggiQRmCDoQtqTWgiIiEIiIhCItFqtLabS9xgDVVq2bUkmKYAHE5ny0US4DdXRQSS/QFbEVCffFZ2r3eGXuRlqqH7b/4nfNR6QJg0DwNSFfV8lUulaqg/WO/iK7aN51R+sB6gFSDlS6nLeIVoRQTL8j62HwMLoF/UN7wPxyUrhVFjhwUqvIPp+t+Vks05F1Ss4bjhAYyf43eS9PF80D+tZ5wvJ/pQuK1W62irQYH0W0GMa7tGAF2J7nxJ5geCg+VkYu9wA6zZGR3JeV2C1mz1hUaAe6Wxuz9yvdzba0yzs6rcALpxA5Dd3+A5+m9Ve9NjrewT+S1HDizBU9GElV4hzHYXhzD7LgWu8jBUo5WSfQQewgqJBG6vO3ldxojs+81zhLhmIgkGd+a88qD5rufa34cGI4TqJMHwXFSHeE6TmrTsuBe17HWbsrHQYMpph55l/ecfX0U2AoTZW2B9loxuYGHqzun3KXdXjqdPmtpoFhZeZcTmJdzPjdYXhbxSYc84zI1jc0cJ/GQUdRu4Vg01M5DyAyszCImIbmSchnOpzCytlBz6jWjEcLXvP1TmWloBG/eB95dlla5oAIJgPmaDRB7wjLQxGW8HmoSOy/Tv38irYGX1cPtYa9fHfhwUPel1BgBAdEDVoOeh7wUXZ6ppvy0/GSsdspYjkGAhrfsVARkXHlED4FQVopQWnKTnkZVlPIScpVVZGA0v/n3qvU9grSXUn0yZFN/d5NcMUecq1Kr7A0ooOPF/nDGhWhY1RbpXW5rdoyegZfkiIipTKIi0V64aOe4KL3hgzO2QBfQKq/SNasFFjZzc4mN5gZDnmV5/Quu8HmWUakbiW4G/wDsIXqterLsRjEMgYEgcB5LA1F5qsxaLP8AL7/PkvQUNe+lhyNY09Z18tPuvOm2G82iewc7phd7jmo+037a6ZwuZgPB7C0npOvgvVC8rntlFtRpbUYHNOoIBB80oMaDd7+/FNsxS7v/AKxMPZp9yQvLXbRWk/aaP3VhZr+eSe2rVRw7JrfGS5We+NkGGXUDgPsOksP3d7fUclTLVs1a2TioVY4tY5wPMFoKfgr2zC7HdxW1TzUM7dA1p67A91/wsrXezScn1iOLqjQfJoUVVtrycnujnUJSrYnt+sxzeoePeFz4Tz8lfmLk+yFjdWa+aybaHSO8/XiV7ZskzDY7MONJrjxl3eM+a8QDTIyO5e8XQzDQot4UaQ/8As3E3WY0df4WFj30xjrP4XW6OAXDeN00LQ3DWpMqDg9ocPXMeBXa4rEuXnXzOY64Xnct155fX0TWapJs730Dw/SU/wCFxxDwcvOr72Ct1llxpdqwZ46UvgTq5sYm+S/QVe0Bok/jktdG1NfkJkaf0K3aTFcQjj6UtL4xuT67/cKh8MZNtivC9mr/ADZ2kRLS6Z1wHQmN45cir5YrUHjGDMxPwjkp6/Ni7LapeWYKhz7RkNfPPLC/94HqqPatn7Zdplg7eh+wIewfcnMcgSOmi9dhn6hp52iN5y8r7dl9reHYsSuwpxd0kYueI59Y6/vwtxn7TUh+jPzjQzE4EgQ7FhyzAJgk/sLcXMM4SwBxwD9O04GAFxOWRADT55qGsV9We0Nw4hzaZDgehzB6hdbGVx+irFwiACXSBMxlK9CYuk1af579Vjtm6I5Xj18yPfYu59UHPEM5dlUcAA4Q36w9kT4BRlnpmvVLh9Rm8md+QnecvQr5bm1cvyquxjSfqkwSTuaNSd0ASpayUoa1rW4WDQRDieLhu6a6aZhJVldBh0Zke4F3ADX328E1DTy4gQxgIZxJ099yvmx5/MYeDj65qeVO2KtpNWvSIHdiOYyknnJVxWVTySSRh8n1HU9+q3XMaw5W7DQIiIrlFa6tQNBJ3Kv2m1SSSQPl8lIXvW0b4n4KmXoz86SdDB8NMliVn/LnNMH5QBc23J007gmohkbnsuqleLnVRnDZiOI4nmplpVdq4NWHPFlugRl/dSd12hzpBzjeszFKAGJs8TcrWgAg6Hffr37SrY5Ncp1UkuqnTBGi5GrNtQjRZlNJHC67xcHRWPaTsue00oK6LFXgEHdp0Wu0vxLlmCl2zimqHPj+nX33KzLnbYrrtOAjRQ9exU3a0mHqxp+C73LU8KmerdK64AHZopxtDVEVbms51oUv+235KxUxAA4CFHOapNdje525KlLwWL1hKycsYSsurlWFX73rnHHAAeJzJ9fRcNnrFrgu697OQ881HspFfS8PbH8LGG/TlH8/lZ0l857Vb6FSWg8Qtpg5FctmbDGjgAtuNfPhIGPc0bXPhw8lo5bqDvrZKyWg4n0hi9pvdd6Ks1vo6og5Va8cO0cPDJX8vWmqnm4jURNtG9w7ygwsd9QB7Qqldeylns5xMpjH7biXv/idJ8lLtowQu5wWlwSclRLK67ySetWgBo0WOxjot1UcQ74H4L0JUPZyjFuxDQscfRXxfRKRwdAwjkFjSizz2oiImFWq9bqk1D1jyyUDb647YSJDcj46+9We13cZJaZnON6iTYwHYi3vaHw+K8jI51LVSS1DDZwcARtr18NFoCz2AMO1lDvDS4YQQNM1O2ekGiAuR1hGPENJkj5LualsTro52xNicSADcEk6nmTuRz9VKKMtvdZtR5X0LCosmY2jVnFYErU9bCtb0kDdWtWQWD1k1ZQhqLrna2SIG/8AuVILCx/b6Ae9JWr8P0cUbidXAnssbD7KsvzOI5LJfCsS5YkqghdstdpoNfrqtFKwNaZOfu8eK6iViSmY6ueOMxteQ08FzowTdCVi5ywe9cFrt4acObnHRrc3dTuaOZgKFPTOkcGsbcnkuveGC7jYLsdUVVvDbamysaNNuPCYc/FDZ0IbGscfepCqyrUBl3Zggjud5+eX1jkD0B6qJp7GWZsd05ftu+a9TSfpuUtLpbA8Bfz0+ySbi1IHfPmI6h6kFWGy2wVGhw3iYW8GVG0LOxgAaXZZDOR7l20XJd/6eqozfLfsN/LQoZilO82Bt2+7Kc2epfnC7g33kKyKG2fYMLnSMzGu4KZW7SxmOINO6oldmcSERETCrXNbq2FjiNYgdSqXabQQTDiIzmYk8+KsW1NctpDDqXQDwyMnwVErUqjYLhkcwRPnDhmOYTMVN0rTcpOorOhcABdd1XaLBM4XCRyMHmN46LrbtHRyBD5M6YSBGpmRkoGpZ2u1DXdRB8wtDrrYdzmyI7rpy8VnTfpuB5vlHddvkNPJWsxhltQR5q40L1pvEsD3ZTkAcvNbu1JIilVzynAY6kg5BU26bQKBPZWluQwltSm4tOektjOd4U6/aN9IB1WhLPbov7TLiWvDSB0JSb/0tE75SHdlwrxisVrhwt13/wAeamzZ3+yfRa3Wd/s+5ZWS3MqsFSm4OacwdPAg5g8l0CqeKSH6YpRpnf4j/wApoVrtwAudtB3D1COou4eq6xWKGsu/7aphs53l6LvxbuS5aYLcUiJiM1jK3VRi6rmdlkVlYlRSU7gN2DRp6uR69UxDIHjrWUr5KxlYFyzcqYss3OWp9RfHFRF83j2beJPda0aucd3xJ3AKxkLpHBrRck2Ci54aLnZZ222Oc7s6ZgwC58SGNMgQN7jBgaZEncDlZ6bGCAJJzO9zj7T3HMn8aLhuumWU+8Ze5xc8xEuOXkA0Acmhb3uhfSsKw1lJEB+47n8A8vReRr60zP8A+o2H57V1CoBrmtdWpi3QOC1ALOg6HDqFqZbJHMTosHt5LWXEKztptcCCAeolRF5WJrRib5KDJQ42IU5KcsGYFcllvJ9N2JpIPLfyI3q53NfDa4jIPGo482/jJUCoFroWp1Nwe0wRmETUolFxuuU9c6J1nbL1lFH3LeTbRSDxro4cHbwpBZBBBsV6AEEXCr22FMmmwj7LpPiIVEvK0OOFnekkAAzpviV6hedAPpkESN44jeqGbgDHktcORLRig7pGqfo52NbZ3csvEKWSQ3YN91xsbAWFqaSx8a4SpE3c/iOAyPzWLLM8d4YSBrr4pvp2b3CSNNJa2U+Cgtn7IWl7wO8GNFMxOF1RzmucBIzGECZ0J4qcflSEh2YBlzseImZicwIg58UoWR4OKnhLcwWukAjhIBg5DduXy8GPe0NDfIyBwEmPQJd7g6oD76dqYjBbSGMtOYdR113WezhDWuA0JJy3Hgfep1lcKsXXaOzGCWhs6nUneSdFMUagOhaehBSs7g6Qkc1pUrDHC1rt7KWxr6CuMVHb2+iB54qlXrtWLhOv9lzG0ga6LP8AKWHR0dVFzWuBa4XBXQSDcLF9E9fetJXR2/MHoQtTq4PP1WRNgkD9YyW+Y996aZVvG+q4rZVgKu2dhqVDVdoJawcGzmepInpCtD6RP2SejT8lwtumqMm0nR90/JNYVhjKabpHuBPDS1vuk8QqHyRZWDtsuOdOpWNodmFttFBzJa4FrhGR1Wi06L1EWy85NcXWym9blztK2F2SkuXsu2zXk5usO6rO124PaRBBy5qILl9L1zoRe4R8Q+2W6ywSuW1U4XRSqLC15tKsuQVQ4BzLqQ2HvEsr9mT3agjo4aH3hejLxiwViyq1w3EH+FwK9laZCzMQYGyXHFbOEzGSCx4FHCRCrF6WVzSY1HqFaVy2yyioOBGhSQNlqKpk5TyafMpTbBI5qWr3cc5bPMTu0OS0upYZOFxnWGucT5D0CmHLllwlga3cJ+OqzuWy9rVGXdbDnf6R5+5BZa9d0NpuY32qgLAP3T3ifDxVku2wNoswtzJMucdXHj/RRJRZcN67NUK5LoLHnVzIE9QQQesSo4bB0N9Wsf3mD/QrYiiuqg33sg6izHZH1cgcbcbsZG4swwMs5ESd3On/AO3rTTDprPPDFD/5gV7cq9fWyVntJLyHU3nV9MgYvvNILXHnE80FduvOae0VZ4H5zPk1gJ8gtjLfUOr3eeXorT/hwz/magG+GUxPopKxbDWRkF7XViP8x0jxY0Bp8QV264oXZa6nWl3aPk0WnfP5w+yM82jefDivQQFgxgAAAAAyAGQA4ALYuIRERCFXNraQIa4jRrzzygqjtvCi5jHGo1gcCWio5rTA1z0MTuXpV8UcTAeBz6EQfevG74uCpTqPAY/DJjKQRucIyz3xv1Xfi5YLZdRyTVLhVLXuLJXZXcCLajXTXTks7y2qp0hhpN7R25xEUh0GrvCOqlLst76tKnVcGEOaCcLNDmHAQdxBVX/3dtFQhraLjO9zXNYOZcREK1B4oMZRZngaGzoTGp8TJ8UQ1k8jy52gV+I4Rh9LEyOH5nX1JNzYDw8FJ2ezteJgeZ+fNPyYb2n1KkrloF1Fr3aulwgRlMD0C6exCaFTJzWEaKC+jQoYWADc7xgD1K7rquRtdzmvxBoA0IkyT1yyW3seQ/h+anbgp5PdxIHlr71x9TJbddbRQj9oXPZtkrKwg9niI9pxPpop4L6iXc9zzdxumI4mRizAB2CyIiKKmiIiEIiIhCIiIQiIiEIiIhCIiIQiIiELB7ZBB35Ks3vYj9XeNDxVpWqtRa8Q4SF0FC85Yyq0loaSCvlDZd1VwNRzg2c4MEjeB81da93ubm3vcsg71yPouCvag0S6WffBb7wuqWZbDDQGiABAgaADIAeC1PWllsY7Jpk8B3vKF1ULDVfo3AOLsj4N184RdRWinTLnBrRmT6cTyVks9EMaGjQD+5Wqx2NtMZZk6k6n5DkutRQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQiIiEIiIhCIiIQv//Z",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUTExIVFhUXGBcXFxgYGBcVGhgYFRUYFxUWGBcYHSggGBsoHhYVITEiJSkrLi4wFx8zODMsNygtLisBCgoKDg0OGxAQGy0lICUtLS0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgEDBAUHCAL/xABHEAACAQIEAgcDBwgJBAMAAAABAgADEQQSITEFQQYHIlFhcYETkaEyQlKCscHwFBUjYnKS4fEzU2OTorLC0dIkQ4OzFhdk/8QAGwEBAAMBAQEBAAAAAAAAAAAAAAECAwQFBgf/xAA4EQACAQIEAQoFAgUFAAAAAAAAAQIDEQQSITFBBRMiUWFxgZGhsQYywdHwFFJCgqLS8RUzU5Lh/9oADAMBAAIRAxEAPwDuMREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBETU8bxzplSmO23O17Dv85KVyG7G2iRHFYvGYYe2Z/bUxq6MqhgvMqVA1A77yU0KodQym6sAwPeCLgw1YJl2UvMfGVsiFu7bzOg+M0L8NerdqlR78srEW7rAbekJBsk8SM8AxlRKzYaq2fse0psd8oOVlY87XBB8TJNIegTEREEiIiAIiIAiIgCIiAIiIAiIgCIiAIiIAiIgCImi6Y9IFwGEqYlhmKgBFvbM7HKi35C5uTyAMA3s0HSOsKLJVIJX5JtyN7r77n3CcExfWdxV2LHGFAfmolJVHgLqT7yTMHH9PsXWpNQq4lnpvlzK2VrlWDAhiLrqBseUulZlG7nbOOdKFqU/Y00Jer2EBsLs5ygD3+lpt8D0j4fh6VOi2Ow2ami0zetTGqKFOl/CeYjxcXvma42OY3HkZf4bx5KNNqfscNUBbMDVp5ypsosO0NLDb9YxZC7PS2J6UYCspSnjcMzn5IFVDdgbgb94nxh+kNNVNwBa4OuxGhBPIjxnm7E9IFqFLpSQJewpIKYOY3JOpudBL3/yGn4m/wCtJsiT0V0bP5RWfFaZAppJbW5uGdvLRQPWSmeVB02xC0vY0sRUp07k5Vcr3cwQeW15aTpbjL6Y3E+QxFUf6pGW5F7HrCJxLq86xa4qpRxLtUpuQoZ9WQsbA5jqwvvcnmfPtsrKLRZO4iIkEiIiAIiIAiIgCIiAIiIAmt4zxalhaRq1nCoNPEk7Ad5/2mynDuvPjuesmFU9lBdvFjY/Ds+5pDfBGtKCk25bJXfslx3bSvZ2vsTM9bnDPpVj5U/4y2euDhn9v/dfxnn+VjJ2+xPOQ/YvOX3O/f8A3Dw3/wDR/dD/AJQeuPhv9v8A3Y/5Tz/KGWydr/PAjnY/sX9X9x6BXrg4b/bj/wAf8ZEOsbphg+JJRp06z01psXIekWDEqVXRW5XPPnOWxCg+t+n2J52H/HHzl/cdA6vcfw3AvUes/tyy5V/RAZdbnsuTrpvf0nRKPWdwsaKGUdwWmPseeexKlb6SMkm/m9ETz9FL/a/ql9bnpfAdNsJVdEy1EznKGdVVb8hcMZKsg7h7p5+492cOiH5lJjbzF/vkm6X9YT4bheCFJv8AqcTh6TltyimmM7i/zi1wD4E8rHGjOU737PY9HljAUsJKHN31vo3fZ23styc8e6YYHCNkq1L1NP0dNDVcX2zBAcl/1rTQ0etfh7NZqOKQfSahdfchZvhPPn5WTqTqbkm5JJY3JJOpOu51Mp+U+M6sqPEcmes+H4/DYunmpNTqodDoDa/JlOqnwImB0i4Tw9MNWevhqHslRmf9El7AX7NhfNta2t7Tzfwvi1ehlrYeoUqIw1HMdrssDow8DJ50n6wfzjgKNFRldmviANrUrZRt85u1Ybez7jGTXQZtCEYJfkqQcoNy2gYqTYG2wa19LkX5z1Jw+pmpU2F7MinXfVQdfGeV8ZizS9mFtmqNmN+SXsPx5z1B0eN8Lhz/AGNL/wBayanAiBsYiJkaCIiAIiIAiIgCIiAJzTrH6xquAxC4fDpSZsgd2qZmAzE5VAVl1sL3J+cJ0uee+vDhzJxE1SDkqUqZDcsy3Qi/eMqn6wkrVkPY3vR/rcxDYmnSxKUBTZahLIrqQVRmQAs5BuQF23acw4xxBsTXq1mNy7Fj6m+nhrLPCFNRnbuQqD+s4Kj7/fH5sxA/7R+H+8zdSmpu7St9f8flz0I4LEPDRlCEpKTb0TekdFsnu3J9tk1sWJUy4cDiP6o/GfDUao3pOPqt9wl1Uh+5eaMJYPEx3pTX8kvsW7wI17jLftR+LTRa7HLJ5fm0LkqZbWqPL8eEuXuLjaTZkKSezKAzKwC5qqDvYTEm46K0g+JT9W5Put94lKjtB9x1YKGfE049cl5Xu/RMkfSt+wwBtZLe8gffInicK+JFMmo16dNKSjJ2QtMWUBs+vM7bkzbdMK57YHeB7muf8s0mAxgVQCp8ZhhEmm31v0PW+I5S5+EFwgvNtsxavCK637DWHPKwFhz2mJ+TP4e8SWUuKUwpKqc/LMBYeO+s0PG6x9oCb3KKSe86j7AJ1ySXE+dUmxw9HsyEqt7EFiLab7eBm2wFIZPFjl9+rfC8xOFcNzrncsLggAAHTm2vjNxwfgIBJ9o1vIb285jHE01LLxPXjyFjalJVVFWequ0tO7cj/HT/ANURcED2drcgUVrehYz1X0Xe+Cwx76FL/wBazh1Lg+HzZmpqzaXLC+wte23LunS+rSqAKydwQgeAzDQd20jnMwxHJcsPSzuV7JaJPrS38SdxESTzRERAEREARKEzW8Y4tSwyZ6h/ZUasx7gPvOghuxaMXKSjFXbNnMPF8QpUv6Soq+BOvoNzOeca6bVqmiEIncp7Xq3+1poKPGadyKgJvpfc673mLrxva57VHkKtKOafktX9vcmfHus7CYc5FSrWfTRAFGveWI+AJmjxPTHimJH6BMPhh3O2dz7xZT4FfWQziQT2l6LXW1gx0IHMAkXtMU1H7z75zyxdtMvqepQ+G4XzufcnFeqf/htD0d4hXdqjUUZ3N3cOgBNgLnXXYc+UjvGOj1Sg36ajYm9tWPxBMz0xVQbMw9SJvOHLinTP7Uqn6zWvbuB5eMxhUu+hmT7/APB6lfBpJc+6bitEnC1uxav2IImBUEEAgjYgkGXvzOctwtUKNb2Fv3pJ6yu7Xy5yNt1B9VG0sYzh+JqAB2YL9BafZH3k+JJmkKk3e82l4/T7nJicFhqaWTDRk31ZYpeLcXfwZHfydhtiai+p+wNCGr8lcWrH6LEN9s3lLgajdR6uFH7oN/hL9OhQpm5qL5Itr/vWJ+MSmtlq+2MV9Lk0cLOXSqdCPVCrVbXe1JRXr2mjfC1bdp6Wb9amhXyJy/i8sHCMW1pULaXI7LeOX2Wnvm8q8RoXyqlz3uT8dvs5jvExnqsw7CZO18ohcuXvs3av9XX10zvNcEvC3tY6FRw8mrSnK17xzZ0+9SzLu2XYYh4fS/q/8TD/AFTb8AoKhawCgKfUnTU7zFy2v2r3y6W0VhuQe4z5VmG0xdSaau213s9Cng6NnKFOMG9L5Yp27119/euBrOPjML3t2+feQdJoWpshsylT3EEfbN5xmg5UMu4bW176gc5j0qbuwatUJsNCxZza/wAkX/lPUwSvS8WfE/EXRx0m1ukWMHreX8gqVmFzlVQDb9VBm+N/dLI4XTFtXPra/ul05aXySqna19/C07FpufPvXYvVQQtgNtrSX8Pb9Evv+EhhxQNgvaO2m1/ObqmrlQupC6WG1wdZw4ucYtWWuuiPr/hunWqKpn+Xo6t31V9F4P0Rv1xK/SA9RJV1esfysb2KP366X9ZzCvxIUeWZtwNreJO/umb0V6b4iliqVVyq0w4DKBvTY2e53uASfMCUpVNMzOvlSMLSowd5Wfdt5HpaJQSs6z4kREQBKGVmr6Q4/wDJ8NVrWLZFJAAubnRfS5Fz3XgGj4v0jc1TRoEaGzuRfXmqctNrm/Pzls8ANft1XYm1r7298iPCOO02yWRUI1JAtc8h8SfdOj8N4lTZBqNpGTXXU6XiEoJUk49b4vx6jmXSbg3sXUWuCWF9tFsb/HaROpQLVmoqGLJp4X2Iv4EH3TpPSrGq1ZEBBs3nuyqfsnMKGLIp4ir87K4vzu49mT6e1JnNUowelupeb+x7OC5SxEEnmurTk/5YpJeMt/y9jC4oVFzIzELctmU6ADMSfADWXKVfOLhlI7+WnjMfCYkU8BUI0LjIPr1Rf3pTdfrS7TdafD376ns6f94zVT8KRHrMXhYN2TesmvBXv7Hox5drwi3OMXlpxk3qulNxyrfRWkvJmVSuf4bTaYZHOnamBwHDqMJUNh/R2H7VWqq388paS3ojwouqrfxvvYdw93xiOEurp8WvLiTW+IMklGULdCMnZ7NpO1rdq1ua0YNra3+MwOKUnRQRcKTYtvuDbfxnXX6N0smgIPf4+MgvSTDlKdROXygO5h/KX5nm5KT1MIcqfrKc6UbxbT2dmu1NdpDwGdc2YAena5MNjY6b+UxmoLzF7eGXN+0d2lvC4guGUfNI1XvIN5eWgPnX9dfiZjXeSbjFW7j1uS4LFYWFao3Nta3d1dPXRaNXXb7nz7YDb4f8pQ1DM+h+T/PWp6Efest4k0PmK58yv2BfvmDUn1eZ7EXbTK/S3uYeY98vUKYN7m1trDU/tMe16/ZvPggLqSFH6xmK3HaSMCMxIPJftzW0mtDMpX3OXlFUpUnCVRwb2alZ+9+9GZUp3BXmRYeN75Zoi4UXOokhSutS1SnYKSLW2W2jC3LXlNBjE0YeNvcZ6NCUc0su2h8by1SrOhh5VnefSi31q6yu/bHXxNfW4k2y2UfH3y3QNkLaXO34859W/Fuc+kKllB2BuSNdtfumslmsjx6M+ZvUa4O3jx8jY8IwoX0sPrAXJ98mlDBhMOGJtmAXyZhmZvRMvraRfhOHJyjm1vH5RvtNx01x+SiU2OXLbuasdR9VBl+rPOk89WT7bL87j7bCw/SYGnF6Wi5S8rv1dvIhOKx61KjNf5RNvIbD3RTqLe11+jMbDUdhYTZrwamy3F1bkRte3d3Xnb+mT2Z8ouVakXmkk34np/odjvb4HC1b3L0aZJ8QoDfEGbuRbqxwzU+F4RGtcUgdDf5TFh8CJKZc857iIiCBExsdi0o03q1GyoilmPcALnznG+Pda+JrNbBgUEBvdgr1GseYN1UHmBc+IkpNkN2Os1eA4VmznDUS3f7Nbnz01nNem2P9ji6lNTYWQgLYWuq6aba3mFi+tbFNhWp+yRa7DKKysVAB3YIQbN3a2vr4TmX54fMQWLm5ZmJLG+mlyddhr4mUqQll03OvBVKUatqqvF/dNepNhxItiqWuy0z/AIzI1gqy/k+LB+i4HndSvxWF4yrCmSgD09A+obLcmzG9m1Ol5k0Bhs9QI7olUOWzWqezLBgMt7FlBYb6zDOlbNo+jv2aM9b9LOpmdO0k+eXRafzK8dN9WrbaMwV14c37VM+odx/qMu48A8PTwrUPjQxH3iXaPC2ag+HSpSZhZ1NyiuRUByqXC9rKTobDQ6ylbB1zhGpimxZHptUVRnIC56d+ze4vUGo75eDWaNv3S9bnNiIyVGqpKz5qi3fR9FwTvfuNlw+pbBN+1Q/1/wCwk36GcSVSpOxAHu0+6c6oYjJgXBBBvR5WtZmBv3b28yJsODY+1JNfL94yIyVOmr9bXqy1fDyxWKnGG+SEl/0gt+5s7+MUpXcWnM+kuMFSqEXXO1h45jYD4iadeNuFy5yR3TQcR4o4rCoNcpB9R/HWTnp1XlvoUjhMVg4Orl6T0SXStxbdu6xKK/RTEJf9Ff8AZZLegJB+EUei7/OSoP8Axsfskap9OsQu4P1WZfvmWnWVUIKtmFxbcfblM0WFo8H9TRfEOPgrSjHya+tvQyeN4FEp501SwYvtck2ygXuZCcbxfUil8n6e/wC6J94ziDNSCZQFAAGt/I/D4zUZZyypJS7fyx6tLlTEVKdovR8bNN9e/DhsttEuN4MzXLEs3jLNVJkYVd5dehpK63LKk507mV0XxHbaidn1X9tdh6i490pxddamoHaJufFrzWsGQhwbEEEHxGokobArWIqk9h7OAORK6i/gcw9JrTmoXl2HNXwtXFU4Ydfwyvrwi09fbQi6UwdlZz3mwE2uH4NUb5dlX6I0/j9k3eQU7ZAo7yeW3M698tmuBexLnTU6Dnt+9K1K8suskuxbnVhOR6MKtnCU2t5P5dr6L+L8uXcCipUW7AAXYk6eAmh6W4nPUQd+aoefyjZPgD75t6KljfUnw5SP8coZMRYnUqh77WGW3wlMJaU11as6/iGThhHbdtJ912/eyPrDYYAADVmIFhrqfCT3B8LSnWpYU0VctSNSszfNvcKEPzbEG58RrI10dbNXD/KFGm9Uac0QlBb9rLJTxKu64Z2UO1erRp0bgMWAawckgaf0h8rCexFaH5zJtuxPuqusRh6uHLZhQrEId70qqrVQ3+s0m8531VUSjV0O4pYQkeNqw28lA9J0Sc81aTN4O8UIiJUsaHpvTJwNewJyqHIAuStN1dwBz7KnScVxeAXEVcSlWktNqNM1kr0rgVEJ7AdGuGJ1u4IN0aehyLzkvSjgZwCV+xmwz06lKi4t+h9rqlGovNQ1gjjYGx7zeD4FJricaLE3uLjmd7ecGmoHZAEuslRAbaAixIsQR5i4Mx6VPv7pdlSjoCIXDm9lNvGSLiHQvFUwjUgayuiPouUgtuuQnMbGwLW562miqYeqDY0nuFznQg5AbF7EfJvz2lZRT3NoVZw2+x806tUGwa9pk4Ti9ZDdd+8E3+Exkq+cqHGsxeGpvgd0OVsTBWzPueq9UbWj0orUs7KbtU7LBrNm1DdoEa6gb+E+fzuGNzZT3BQi+i2AE1K0E3vc+e0+vZNyt6SJYaLjlVzWjyvVjVdRqN7JbJWS4XWvVvfsNzU4jpvMKpiCR5zXewYcj9suPXYbqPiJgsNKO2p6v+sU6vz6evt9i41TWYhq67mfTOTsJZxNKoqgk6XtbmL/AMpaFFrc4sTyjG6yO/mZOOxygBV7R59wmGKjnnYeEt0aV5nYahmIA03sD+NTOiNNHnVsbVqO7lYpQZwbhj57/CbKk9S1mAYfun3jQz6p0AugsTpebPA8Dr1gTTpO47wNPLMdJpzae6MqePr0neE353Xk7owPYg6Wv9om0w9bKmQaENpp81hy9Qf3piYnDPRa1RGUjWzAj1HhvrJ5hugjHC0sVTY1Xq5SqILqqOpN2JFywOUHYDWcdeg0uifT8m8sUajjz1oyvbsd+N3suu7ttbRkNWiznmZtuE8Aq1WCrTZz9EDb7reJtOh8B6vQLNiTb+zQ/wCZvuX3ycYHA0qK5KSKi9yi3qe8+JmNPCcZHRjviOnDo0Fd9fD7vw8zzV0o4y+FrVMKiBalM5WJ1ANgeyBvvufdIsa7u2Z2JY7k/jSSvrmwJpcXrk7VBTqr5FAp/wASNIjS5TvhBR2Pk8Vja+Jd6sr9my8vvdk26E5B+UPUtlFEhr3IszKDoNZL+PcdNGjTZVzNdE7hY6X2NtANN9QJCeiVE1fa0QdaiC3iUqJUI9yNJdjXWticXRc2p0TSZW3CexWm7fG3xnVHY8yW5OerYs4xFVhYk0UOlhdKCu1vWqR6SbSOdAsMUwVN2FmrFq7DmPasWQHxCZF+rJHOaTvJs6Iq0UhERKlhIV1u4Y1OGVbJmytTY62sFqC7eOnKTOYXFsAmIo1KFQApURkIPiLcoDPKK1QKgz6jvIv8d/jNlUw6jU2y20t48785j8a4c+HrtSq6VKbFHA7QB3B13UjUHxE1lbF1EGUNdfo7j07vSbXMrXJTgeNYmkoWliHCgggN2thYLc37GnybWmXiOleJehUo1FRw9NaeYXDdm9mNjZjrtYbX3veFJxhtLqNPjMxeKodz5cvS/fJuh0iiUr5hbUC/u3lsaTOp4kG1m8pbajfa1u617eAIsYsRc7b0X6IYKlhKFZqQqVGppUZnAaxKZzlQ9le7QX8Z98V4bhMrVPySi9lc3agq6hbrdsuq3tcgmQrov1kVsMi0q9FK1NFCoQcjqAMoGoynTSbjF9YuCrpUp1aWKUVEZDlyMAGBBIs97693KQQ0QpeleAcfpOFKvjSrOv8AhsB8ZkUMTwqvmWnRxlNwpYDNTcELuASTra51ttvMZuHcHU3FXH1B9EJSQ+pIHwmVhuKUKN/yHh9mIKmrXLVWsdxlGgv4MJNw1fY03FWyOaagZVCkEoqvZ0V7OBezDNY2NtJoOIvdgvdqfM7fjxm045Vqo2eqLvULH5o1Fr6LsBcaSP0ySbk6k6/ykN3LxjYzaFAbX1Ovd5CbmlT9mt76m4tbXbv2tr8JrMHvt/LyM3XDMKcRWp01FsxCgDYd58hqZMSsmbzo1wZBSfGYn+hpgm39Yy8vK+niTbvmw6FcfxeJxDF2AohSTTCgKoHZpqltQbkegPpveLUaFfC1MLTYZKZFJiPmOoBViedmtfyYTS4XC1MDhKrFMtVgz2HLLZaY07ncMfBvCaKJm5FeJcXpcQarhRTs6ZzQqZs2Zkvpa2gYKeZ5ekx6nuLZ8EaTf9moQP2X7Y/xF/dIB1f9HMSldK7pkRbkX0J7DKLDf53dbxkr6saeWrj0FrLXygeCvVA+AEzqLo6mlN66HS3x6iYWI6Q0k3MtthQ0wMV0bWpvMDY531xvQxqU61Jh7ejdbbZ6bakeYIuPNvCcmQ/j+c9A43q2pVNzNXU6nKJ+cw8iZKdgcu4HjTSdXU9oEfwv4SY4LFLjK2QotKnUZWxLBic6pbsjbLmtbnvflrIsP1O0lN/aP7/9pvOH9XVKnsTL85pZGfN63ZK8LxikwAUi3KZ1PEgzT4Po8qbTa0cGFmZoX88T59lEAs1cUBMDEcXVZnVcHeazFcDDQDnnWRg8NjVzghK6iwbk4Gyvbu5NynG8ZTYEqwsw9bjkQZ6Kx3QhXkfxvVWjyyZVxOBus+LTttXqaU/Ob3mfVHqcQbknzJP2xclHIuCcJfEOFU5F5ub2Hu+UfATqi9FcC6BRnD2AZ1YgsebFTdQfICSLBdWipN7hOiASRck5jiugdQC9GqH8HGQ+8XBPukX4lwfE0j28PVH1GYE+BW4PoZ6Lo8DAmUnDQJZTZXKjiXQPo/WYVKtag1PZaecFSV3Y2Oo1C8uUlDcBPdOkfm4d0fm8d0o3csebesjDBMUlM3FqSn1Zmv8AALI2ifi/+86F1zYcpxG2XQ0KRHq1QXPqp90grKOff5zRbFGXKFxJL0fqexpYnE3saVIhDzFSswpIw/faRums6D0I4atfC4qmxsH9mL2vbKSwNvA2M0iiktjB6sy+Z1YtkbKL6khy+VD4mzMfSdDxj06ADHUAMQzm+UKpZiSBe1rm3uE0nDqmHR0wqdhvl0wNXLJ2876WBNr62vbumfWNPFq9NrZ1BDJmF8lRSNgezcE2v4GaWsY34keo9PGrYqlSpr+jZwrMRYtmNuyvzRqNTc+UkfVVRDnHVh8/EtryIzO4/wA8g3DeANhGrYiqdKAb2Z5OxFqR8CSV05bTq/VVw72XDaJO9W9XzDnsH90KfWZVH0dTanvoSRKUuqkvhJXLMDYthZ9gT6tKwD5An1EQBERAEREAREQBERAKWi0rEApaLSsQClotKxAKWi0rEA4v1+8NtUwuKCtYq9J3GwysHpK3nmre6cpYE7AHX3+V56j6XcCTG4Srh20zC6MDbK66o1/MC/heeY+K8Nq4eo9CuhSqhsy6b7qQRoVOhBl4vgUki3SHhaT7oLjMtDFgGzCkai/UVrn0JWc/pHvLeRH3zedHuJHD1VqWzDVXX6aMLMuvh8QJqjNmx6uaBbEmoSWYK7EkkkksASSdz2jMfDYuv+dHfDntGqy2N8rKrCmAfA2Xy0PKTrozhMFTGfDPmB3zMLqCb5SNCCNN+6RSs2H4fUqNRre3rG4W+UrTvuzsNGO+gt420l9rFNXckPSAHG4qhw6mflMHrEclUFreeXM3mUnY6VMKoVRYAAADkALASB9VnRVsPTbF4i5xFcX7Q7SITm1v85jYnuso750Gc85XZvBWQiIlC4iIgCIiAIiIAiIgCIiAIiIAiIgCIiAIiIBQmW3q2lwifDUgYBgYnioWQTp22CxqWrIRUW/s6q6Ol+X6y96nTyOs6DW4erbia3E9F6L7rAPM2OwxosRnDDvBI/wkG3l8YoVx36/jw0noLE9XOFfdBMQ9VWC/qxLqdijgjiFge4+6TjoFwrDpUWtiLOykGnT3UEbO30jfYbC19eU/w/VrhE2QTbYXolQTZYc2woGbheMq8z6eIvMehwxF2EykogShcuAysoBKwBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAEREAREQBERAP/2Q==",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9YsvOjBNIYBeVx8Nvf2cch4VD-_BWvvIkgg&usqp=CAU",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2r5e0cvL9a5w_21GMENKhTz2cCF5TYGOMUw&usqp=CAU",
                "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhUQEBIQFQ8QFRUVFRUVFRUVFRUVFhYWFxUVFhUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGi0lHyUvLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQUDBAYHAgj/xABCEAABAwEEBgcFBQcDBQAAAAABAAIRAwQSITEFBkFRYYETIjJxkaGxQlLB0fAHFGJy4SMkM3OywvE0gqIlQ2Pi8v/EABsBAQACAwEBAAAAAAAAAAAAAAAEBQEDBgIH/8QAOBEAAgECBAIHCAAEBwAAAAAAAAECAxEEEiExBUFRYXGBkbHwExQiMjOhwdEGFSPhFiQ0QlJy8f/aAAwDAQACEQMRAD8A9wREQBERAEREAREQBERAEREAREQBSoRASiIgCIiAIiIAiIgCIiAIiIAiIgIREQBERAEREAREQBFBK1qtvpN7VRvjPosSajuNzaXy94GZA7zC5zSmkS5/7N5uCMpGOMrS6c71SV+PUKVWVPK3bmrW8yVDCykr3Ot+8s99niF8OtlMZ1GDvcAuEtVZ7n3QTd78lne6603O1GEZrRL+IoZklD7/AIPfub6TtmWmm7J7DG5wK+mVmuMNc0kbAQVwLKrGXRVN5zzAnEDgZ4qGmo+brmhoMRl5BP8AEEbXdN+Jn3J9J6HKw2iu2mLzjh68AuDZZHyHF8EGZGJlWWlbbUcL4Bc44ADIBbP57GVNyUdeWt+9nn3X4kr6FhV0s8nAho3QCfErCNI1Nj1U9GAxxm9VcMy058JGCx6FplrGioQamOOZxdlPcqv+YYhu7qd1+n9dxv8AYwS2M1s1irtcWh8RwHxVpqvpp1ZzqdUy6JacBMZjDx8VzdvhtbECCRM8VvtaGi9TF14EhzcxhvWaHE6lKqnUk3067/gToRlGyR3aLltUtOGs59F7rzmC8Cc8wCD4jzXUhdZh68a1NTj9yunBwllYRSi3HkhEUoAiIgIRFKAhERAEWG01202lzjAH1AVBatNVHYUxdbv2+Kg4ziNDC/UevQtzbToyqfKXtqtbKQvPMDZvPADaqS1ade7Cm0NG84u8Mh5qsq1C4y4uJ758ioH0VzeM47VqaUfhX3/JMp4SK+bU+jaXVJvVHOgwROXJYSWtiS0E5SQJ7l90WtYHADFxkla9rsNKoWvqNk08RicMZ+CqJVPaSWeTf3f3JSiltoZy4LFVrRdAxc/IcNrjwHyXyBJx7zwG74eK0nEvxBIfaOqD7lFskkbBPxG5eIU1fX1/YyWIqNMEEdaYxGMT8licb0tbg0ZnedwWJmOIbBJNOnn/AA8JMbMWnlC3WU7ogbFmdoP1oYsYehZh1ewZHAr6YxrZiROJWaF8rVm6zGovhZmWgD/KwkKLq2QrShsYcbmepWkQNu1YhUdv8gix1X3RP0TsCy60pu9/wMpjtBBdkDUPkN53KutltFGQHF1Q4H3RyWXSFp6Fn/lft3f4XCawac+7xDXOc8kSIgZZ8cfJWOBwcsTLTX1uzXVqxpRuy8s1U03l7CQ5xmd3cuy1f1xMinaYg4CptH5t44rxOlpkVTJc9jhEG8SMTAw3Sug0XpEk3KnaG34roJ4WthF7SErrnbbv/ZDhiIV3lkrPkfoQGcQpXKaiaUNSkaLjLqPZ4sOQ5HDmF1atqVRVIKa5miUXF2YRSi2HkhFKICEREAQovis+60ncCfBL2BzulaprVuiBhrJx47efyRlhpj2Z4mSVWaIa4VCXOm+SRzBV254EA+0YHfBPoCqXhcaWJU684pycnq1fSysvAl181NqEXpY1K1hHseBOHI7Fpua0Zjv3/wCVcLS0lZ7zbwz2/A/DmtPE+F04wlWoxSa3XJrpXQ+wzQru+WTNAju+tqx1cvPkMfgBzShUkY5tMHuOXgfVfTnQY24eZXJZfi0J7MFos7nU3taYc4XQTsGRPm4rI2yNDr2y4GAbm7Y78PBPvUGm2DNUOI4Q29j6LPScHAEEEHaDK9tT9euo83NVtKXESYpgNEkkztknE7FsungsVjMtLtrnOPn+izQvM227XM7HwZ3BJO4r7RecrMXMd7vX2F9spkr7FKcV7jh5y2RjMjCVgfi8DYwXj37Fu9BxVZXfdpVKvvEgf0hevdpx3MqSOT1n0pdvPGc3GDicvieS482j9qKDgHXwL5Ocun9PFbetT3ufTDQ4in1jhh1pHiAP+S1WMpy60AkuAEicAQIxnLL1X0Dg2F9lh01pffssc7xKsp1XHe2i7TSsVnp0Gl9QS69AynMxtwy/yrG0VxeBGd0VAd4JII9Fg+49PTZLrpab2O1p2xsWK0VGmuwMxAa6meXHvVpOKy5Gvm0+xDpybm6kXrHX76HpmoWkLtek6cH/ALN3G9gPO6V62F4HqnXulp2sew+B/Re+BUfD7xU4dDL3EWbUlzRKIisSOEUIgCIiALFaGXmOb7zSPEQsqhwWGr6A4Sx1C2rTY44uyOEbOqOMEnkprWxzaj6hD+iY510XTfc67QaTdIkNxdliZncDmNK4+6c2O9CrXoReve1Mzxu3fQDwVBwD6c6drOMte2xPxEkpJ73RXMtzC+RWBax7hUnqhpAIxnYSRBywwW1TtrKj+ibJBa6XR1ZF0Fsnb1geCrfulcgitRs1STiabjTJwEOIIIOIG3YrSx2VrC4hoBc44gYxO/iZPGVfRWbQ0TUErru1RRZVC3eCOefqpqOxB3hvqfmEth/eI/F8Sh7LfrIz8F84qRyVGutr72LS94pmJx/aUeFN/o1a2jKxa2ztB6pZUkbyMR8Vs1KZvUiMQwuBjc5pA84WOyWItFO8RNJ1TLEFr70Y7MCDyW6NVKNpevm/ZqnFu1jasFMXATjIEY5ZyIWa4OIWCwu6kbiR5lZryhzl8TNjEfiKY71N9LyxcwZKdR43QtprsgtOe5JUmjiJQ31PLjc3Kr4aTuBKoNNOu2WmPej0J+K367zddj7J9FT6deTRp7sPQKXGuqjStvoeVGx53pfSBbaA0CQSA7buC+bJo4MfUa8t6OuThJnOTm0YQTvXza7RSdVc4gmqyQGjM4mMNq+rMHgNfWe+8+oAwO2A4ZHn4L6RQhlpxi+SXl+zka0s0pNc3+b6C22A1qwc4fsWgXYcIcM8pnGd2QC+m2elVceibdqUHDZAIGeA4LMKz21QKjuqb0YARjlI4EKbPRFN5YCHVKxPCGgHE8lvyrc053tfl/6burbTecNhdl9d6/QgXiOq+j4q06cyXVWzAjBzwY5AFe3BVGSMa9TKrbeNtfMuqEm6Mbvp8ORKhFK2GwhERAERJQBCiICg0/ZIPSgYHA9+wr7lXFWmHAtcJBwIVLaGGhg+TTya8bNwd81AjThhq06r0jO1+pq+r6n09PabcznFR5ryJUuMYnILF94Z7zfrgqfTemAB0dPFxwXrFcQo0YOSkm+STTu/XMzToznK1itdWvV3O2MBP1zK3RTlgbtgeK0bBZo6pzJl59GqyK4CtL4i3fQjTZULZB2bNuH0Fms9QPAc04ESF9VKF7bjsK0aDDTeaZHVdJbwOZHdmfFYSjNN8zBt07OQ453CZwO8Y+izOYN7hySzUHVJiA0GJO054DmFkNlqDLHuPzUuPDsXUgqkabaez/tuanXgnZswXdzhzS678J5r7c2oM2HwveiwuqgZhoPgVGqYerD54tdqZ7jOL2Z99b3ShcobUH4uRUy3efD5LUl0GT5eZBG8FU2kzes7D7seWCs3VReLZxGPeN4Vc8SypS2tJI7jiPipFFuLTfJpnlrQ84rsFGtXqkZGRxkA+vovq/07WFw6zKsYTiInjGQVnpWzAyXdgtLX7IAxB5b+IVDWt1Nj2Mp4sYSXHPE4L6jhqilRhNbNLxOQrQaqyTWqb16i2FubUe6i5vVaD1jGYzzy8Voau41hUIgvvBvBrWn9FZWeysN6rTd2xhubOcb19aLsc1A5uFOkCxvFxz8JPNSJyUFmlstTTBKV4R3eh32oVjv2kPOVIOdz7IHiSeS9OXMaiaO6Kz9I4Q6uQRwYMGfE8wunVTRu4ub3k2/EvcqilFctCUUItpglFCIAiIgCIiAL4e0EEEAg5r7Vdpq09HSMTef1Rwnb4StdWpGnBzlskZim2kjkX2edu/6wVba29H2boO8DHxJKuWDJV+k2L5xCV5N9exdx6DV0daXzcABAzwVoKsdoQN61NDU8TvgLc0m2KT4zj1XmpZztY2SWpkaZxGRXxaHNAl5AxwJ3rdFhu2WhVYMqbL8cR2vE4rlta65uNA2unwUmtgZ0a6pze+t+pminNTWhfUaQqU6tAuc3pWuAc0lrhebdJBGIIzXJ6u65VqDfu2kGTWoFrHPaTeDA9tLpawdkC59OHAw4EnC6ZubLXc97atN4LCOs2cQfgVc1LWyo0sqMa5rxdcHAEOBzBwMhdDw3i9KjRVGu7NaJ9XX2eViJXw8nLNHvOJbr68ursvMaKtMVLE94YLrnE0zRqNnrkVQWy2Ygk4Yj6s2vpqvsT7zG06p6G10jdJZUqS2lUBBJa28x+BgxdkdYFdG/QVgeynTNmphlAl1MARcJdeMEEGCcSMl9DVywGpUq9BSv1ovzeAJvB8hp6odeAMgTIVzTx2Gq6RqRff8Asjzptf7X4DR2nrBamvfTqUopuuuLx0UGYBl4EgkjEb1Gj69O0Pr02NLKtlqXHAuvBzXNDqdQHY1zT5HNVukdQLPUFfo3vaLQ192mYfRp1HOpvNVjcwSaTJh0QOACstXtBPsxY57qTqn3dlGq9rXNc80nHojndgMcWnqzgMdi91cHQrx+OKd+y/c0eVUcXo2V+mGOZFRo61M4jhtC0alsBu1m4jsvHD9F0+l6QJj3m4+Y+u5cDaqb6L3Bu/EbCuOlhlCtOje7i/FPp8fEsoTzRUjNpGztdIwLHjkQdi5ytoCgT/3B+C+0eZEkcQVZffS3CDd907Pyncvtlqa7Ag9xE/orzAY2phVkks0SBi8GqzzRdma1CzQBSb1WN2A3nx44d5XV6paHForNpYCmwXnAe6COqOJJGPeVS0yB1WgCcgBmeAGZXf6g6JrU3urVabmMLLrb+DnEkEm7mBhtjNTJ42pi5qOW0L7ftmijgoYdObd5dJ3DGgCBgBgBuC+1AUqwAUKUQEIpRAQiQiAIpUIAuf1kqS5jNwJPPAenmugXJ6YqXqz/AMMDwAkeapuPVcmEa/5NL8vyJGFjeoaYS10ekEjMCCF8vfGJWm7S9NpxvDlguNoXd1a6ZaNPkTZ2ljpjJb1oio0tGZGXotfR+k2V39FTl9SCYu4wM8VuVrM4dqmR/tMeK2VMNVtmUW12MOrG9nuWWq9ra6z9E8tmnLCCRi3Z5GOS4fWikAwHc7BXZfcIDR1XE3jMxhhhxKqNJ2epa3ilQY5904kZTxOQHerKWJnjPYwUdYp3emvLu79zTGEacpSvozQ1Q0QbVaWtP8On16h/CDg3mYHdO5es1dHUn9qm3kIPiFX6r6DbYqN3A1X9ao7edgHAfM7VdrqMLhVTpWmk29/XUQK1ZzndbcioqavUTlfb3On+qVyTQ7hmV6KuFr9p35ncdpVDx/DUqUIShFK7adl1G/CzbumzWLnDEg4c19N0mR7Y5/qsxdhs8Y9QqPTNh6YBt4Ng7xB81TU5Sg1lk4rqb/ZKyqW5taTdVqQ6k4XgZIwIdwVTrBRAiocJwPesBsnRNDQ+SNswe7BVttqPdg5ziBlMkealUqbzqWa++ttXfrPT0VjNo/R9W0v6OhTL3RJxDQBIEkuIwkhdXor7O6riDaajGM92l1n919wgcgVrfZWP3p/8h39dNeprpsHhqc4KcrvyK+tVlGVkVeiNA2ay/wAGk0O2vPWee9xxVoilWaSSsiK3fchFKhZARFKAhFKICJUoiAhSiID4e6ASchiuLe8uJcTi4knniuo0zVu0XT7UN8TC5Kteu9TtDeuT/iOredOknyb8dF5Mn4KO77hWHVKoNIxBV/aT1Vz2kyqOkrSSJ8Tc+zanNscdjaTzzLmD4leoLzb7Mv8AUVf5X97V6SF3PDf9Ou1+ZVYz6r7jDUszHdpjT3gFfbGBogAAbgICyKFOSS1IwREWQFxVsbFR43Pd6ldquP1oqsZVlocXwC8DyI4x8FU8YwNXF0VGkryTvbqtZm2lXhReabsjXnD/AOh81X2k8fP9FLdJM3kHcRC1bXpBg9oDmuXnhMTFZZUpJ/8AV/omwxFGWsZp96NS1u+pd8AqG1j6iPNx+C3LfpWn7w5YqjtFtLz1GPdygeJU/CYHES2pvwa8zFTF0Y/NNeJ3f2V05tFV+xlK6e9z2kY/7CvT1wX2V2hnR1aQp3arS1znZl4MgTuu44cd8rvl1GHoSo01CW5XyqxqvPHZhQiLeYClFCAlERAQiIgJREQBQpXy7JAVesLwKYac3OAHmfgueC3tMW4ViAwdVk4nbPBaDM1wfGcRDEYq9N3SSV/H9lrh4OMNTDbCqDSeRV9aVQ6SCiQ+oSI7Fn9mf+oq/wAr+9q9JC8p1J0kyz2gmpg2o25O4lzSD3YL1VpkYZLtuGTi6Cinqr+ZWYtP2lyURFYkUIiIAuI1htE13Q3AQ0neRt4fou3XCaZkWirHvfAFScKlnK7ij/o96NO80jFs92PzWjam0x7Hi3/1Vicus0d8T5hadpjY1qsVuc+72KS012jJv/E/JVVeu93ZafBXdpfGQHgqa11nHCf8L1JHqne51f2ZWw07QaLgJrgydouAuA7u14r1NeLfZ6+NIUcTj0mf8t36L2kKrxKtM6PAtulqFKKAo5MJUKVCAlQiIAiIgCIiAKu07WLaRj2iG8jn5AqxWhpqiX0XRm3rDln5SouNUnh6ihvldvA907Z1fpOXBX1GEhYQcFka5fOqb1LhmC3j225Oz4FVFrolyvKTsxsxEb8VoW+zhoLhlmpEZX+LmZi7aFNRsRaZ2rutTtIFzTQf2mCW4zhkW8iR4rgq+kdjVbai2lzrY2ThcfhyVvw2VWOJi+T0fYa8TFSpu/LU9OCIEXYFOEREAXD6fEWip3j+lq7hcTrG394fxDT/AMR8lJwv1O4ruJ/R70aD3xHEgeK0bWY7pHmtzotpk7scJWjpDLmPVWK3KCWxX25sEjcqOvmfy/3NV/pLtFUNozP5T6tXp7CmWWo7/wDqFnJzLnebHBe3BeGaoEC32ciY6QDxwle5hVmK+fuOi4f9N9oQIijE4IilAQilQgCIiAlEUICVBCIgOT01os05LRNF2f4Z2HgqthDABOA359y9AhYfuzPcZH5QudxPAI1JuVKeVPla/gTIYtxjZq5xVIb81g0qR0bpyuldhX0NRdkC0/hMeRwWq7Vii7+KXvb7pMN5hsE+KhQ4FiYvLeLXTf8AFjb73B66nktlpVKzrlFjnuOxonx3L0HUvVSpZqn3iu4X7pa1gxi9EknfhEcV11lslOkLtNjGN3NAHos4V9h+HQpSzN3Zoq4qU1ZKyCIisSKERSgC4vWgfvB/I34hdmuP1sH7ccabf6nKRhvqeJA4kv8ALvtRTPMiADmNm4gn0WnpHslbz3gNmMlpaR7J7lZI557GlpLMqgtOZ/KfUK+0jnyHoqG1Z+I8V6ewhubOq+Fus859MzLiRgvdwvBdWf8AV2c7emp4f7xmvelW4r5kdDw/6b7SUUKVFJ4UIgQBSoRAEREBKIiAhFKICFKKEBKhSiAhERAEUogIRSiAhcnrhS/aMdsc0jm0z/cusXMa50v4T9gLm8zBHoVuw7/qIh49Xw8vXM5zoycMSN0iPmsVppA9s4e63M97lmaw7D8f1WvamO+gQrRHN8istz5JKo7Wre1U6h2DzVPa7M72nsaPrvXuQgbWp1O9bbO3D+K12P4et8F7uF4ZqVZg+3UGU5cQ8Pc47Gs6xgco5r3MKrxXznQ8P+m+0lQEUqMTyFKIgIRSiAhFKICEUogIRSiAhFKICEUqEARSoQBFKhAEREAWrpCxNr0zTdMHbtBGRC20ROxhpNWZ53btF16B6zC5ux7QSI4xiOaqLRaxvx7161Cx1KLXdprT3gH1UyOMaWqv67yqnwqLfwSsuy54hbbaPeHisFn0FbLUYo0KpB9oi4zvvugHlK90p2VjcWsYDvDQD5LNCSxknsjNPhcY/NK/ccfqJqh9wDqlVzXWioI6vZY3MtBOZJAk8Bz7BEUSTbd2WcIKCyrYIilYPRCIpQEIkKUBCJCICUREAUIiAlERAFCIgJUIiAlQURAAiIgJUBEQAqURAFCIgBUoiAIiICFKIgCIiAIiID//2Q==",


        };
        return urls;
    }
    public static String[] getToysnames(){
        String[] names = new String[]{
                "LUCHILA Telephone",
                "PRABODH Mini scooter",
                "JEEP 12v",
                "HORSE Toy",
                "CAR Toy",
                "BUBBLE Blast",



        };
        return names;
    }
    public static String[] getToysdescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "15% Offer",
                "20% Offer",
                "20% Offer",
                "10% Offer",
                "2% Offer",

        };
        return desc;
    }

    public static String[] getToysprice(){
        String[] price = new String[]{
                "13999",
                "1699",
                "699",
                "990",
                "1000",
                "1400",
        };
        return price;
    }

    //Watch

    public static String[] getWatchUrls() {
        String[] urls = new String[] {
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Watchs%2CBags%2CWallets%2CLuggage/w1.jpg",
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Watchs%2CBags%2CWallets%2CLuggage/w4.jpg",
                "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Watchs%2CBags%2CWallets%2CLuggage/w2.jpg",
                "https://m.media-amazon.com/images/I/71VjM5LOeYL._AC_UL1500_.jpg",
                "https://m.media-amazon.com/images/I/71Kx6rgmlRS._UX342_.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnfFNPUG7-DM5hPym-WT2J6wmLABKj2Y5-SfrxhpnNP4EpZsXoJM6OFHH95EDNLQoQK2E&usqp=CAU",





        };
        return urls;
    }


    public static String[] getWatchnames(){
        String[] names = new String[]{
                "Fossil",
                "Fastrack",
                "Radio",
                "Biden Mens Watch",
                "Timex",
                "G Shock",



        };
        return names;
    }
    public static String[] getWatchdescriptions(){
        String[] desc = new String[]{
                "Water resistance",
                "Water resistance",
                "Water resistance",
                "10% Offer",
                "20% Offer",
                "25% Offer",




        };
        return desc;
    }

    public static String[] getWatchprice(){
        String[] price = new String[]{
                "3699",
                "2500",
                "8000",
                "2500",
                "2000",
                "5000",




        };
        return price;
    }


    //FootWear
    public static String[] getFootWearUrls() {
        String[] urls = new String[] {
                "https://media.istockphoto.com/id/185011763/photo/shoes.jpg?s=612x612&w=0&k=20&c=iyRgidzx3zqcF_XSS9kcrKam1iy0UX9lMFMIBKw7X2Y=",
                "https://img.joomcdn.net/cc725d5ad7e36f4906067e3e2b424e3f48043422_original.jpeg",
                "https://rukminim1.flixcart.com/image/832/832/xif0q/sandal/d/s/p/7-women-sandal-block-heel-7-sonuk-black-original-imaghrt8pwjx36jd.jpeg?q=70",
                "https://media.istockphoto.com/id/1226148920/photo/stylish-summer-shoes.jpg?s=612x612&w=0&k=20&c=ay2tD3LrEIFogvKY5fGotUfaozxJF1JaC8jPBGK7Nns=",
                "https://5.imimg.com/data5/EA/FD/KF/SELLER-58467973/kids-footwear-500x500.png",
                "https://3.imimg.com/data3/BS/UB/MY-8243641/kids-footwear-500x500.jpg",


        };
        return urls;
    }

    public static String[] getFootWearnames(){
        String[] names = new String[]{
                " Shoe For Men",
                "Men Flipflops",
                "  Women Foot wear",
                "  Women Foot wear",
                "Kids wear",
                "Kids wear",




        };
        return names;
    }
    public static String[] getFootWeardescriptions(){
        String[] desc = new String[]{
                "20% Offer",
                "30% Offer",
                "30% Offer",
                "30% Offer",
                "30% Offer",
                "30% Offer",




        };
        return desc;
    }

    public static String[] getFootWearprice(){
        String[] price = new String[]{
                "999",
                "1999",
                "700",
                "1200",
                "1000",
                "1100",



        };
        return price;
    }

    //Bags
    public static String[] getBagsUrls() {
        String[] urls = new String[] {
                "https://assets.ajio.com/medias/sys_master/root/20221215/9hWy/639a245df997ddfdbdd3f267/-473Wx593H-460754561-grey-MODEL.jpg",
                "https://m.media-amazon.com/images/I/61dCM74pPiL._SY450_.jpg",
                "https://5.imimg.com/data5/RP/MI/MY-46290005/ladies-hand-bags-500x500.jpg",
                "https://rukminim1.flixcart.com/image/850/850/l2p23rk0/shopsy-duffel-bag/8/s/e/55-l-purple-duffle-travel-luggage-bag-men-women-stylish-original-imagdysruk4dbkhw.jpeg?q=90",
                "https://m.media-amazon.com/images/I/71DIhFSFCNL._SX425_.jpg",
                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThRbMx_sNk39mwwDGJbH7r8wVQIpmBGHZyMw&usqp=CAU",
                "https://5.imimg.com/data5/RX/LM/SG/SELLER-86619124/american-tourister-70cm-black-500x500.jpg",


        };
        return urls;
    }

    public static String[] getBagsnames(){
        String[] names = new String[]{

                "Collega Bag",
                "Ladies Collega Bag ",
                "Hand Bag",
                "Travelling Bag",
                "Mountain Bag",
                "Mountain Bag",
                "Trolley Bag",



        };
        return names;
    }
    public static String[] getBagsdescriptions(){
        String[] desc = new String[]{

                "10% Offer",
                "20% Offer",
                "25% Offer",
                "10% Offer",
                "20% Offer",
                "25% Offer",



        };
        return desc;
    }

    public static String[] getBagsprice(){
        String[] price = new String[]{

                "900",
                "800",
                "1200",
                "2000",
                "1900",
                "3500",



        };
        return price;
    }



    //SportsProducts



    public static String[] getSportsProductsUrls() {
        String[] urls = new String[] {
                "https://m.media-amazon.com/images/I/616Otzqc8RL._SL1500_.jpg",
                "https://www.rebelsport.com.au/dw/image/v2/BBRV_PRD/on/demandware.static/-/Sites-srg-internal-master-catalog/default/dwf7d17127/images/63859001/Rebel_63859001_brown_hi-res.jpg?sw=750&sh=750&sm=fit&q=60",
                "https://cpimg.tistatic.com/05810410/b/4/Hockey-Stick-Manufacturer-in-punjab.jpg",
                "https://cdn.shopify.com/s/files/1/0641/2366/6646/products/shoes19.png?v=1654894653",
                "https://m.media-amazon.com/images/I/616Un96EQiL._SY606_.jpg",
                "https://rukminim1.flixcart.com/image/416/416/k5o7r0w0/bat/f/m/n/0-980-34-inch-wooden-baseball-bat-na-rk-original-imaffk66nhhssm86.jpeg?q=70",



        };
        return urls;
    }

    public static String[] getSportsProductsnames(){
        String[] names = new String[]{
                "Cricket Bat",
                "Basket Ball",
                "Hockey Bat",
                "Skating Shoes",
                "Cricket Helmet",
                "Baseball Bat",


        };
        return names;
    }
    public static String[] getSportsProductsdescriptions(){
        String[] desc = new String[]{
                "10% Offer",
                "20% Offer",
                "25% Offer",
                "10% Offer",
                "45% Offer",
                "30% Offer",


        };
        return desc;
    }

    public static String[] getSportsProductsprice(){
        String[] price = new String[]{
                "8999",
                "2500",
                "2000",
                "1500",
                "1300",
                "900",



        };
        return price;
    }


    public static String[] getOffersUrls() {
        String[] urls = new String[]{
                "https://static.pexels.com/photos/1543/landscape-nature-man-person-medium.jpg",
                "https://static.pexels.com/photos/211048/pexels-photo-211048-medium.jpeg",
                "https://static.pexels.com/photos/1778/numbers-time-watch-white-medium.jpg",
                "https://static.pexels.com/photos/111147/pexels-photo-111147-medium.jpeg",
                "https://static.pexels.com/photos/2713/wall-home-deer-medium.jpg",
                "https://static.pexels.com/photos/168575/pexels-photo-168575-medium.jpeg",
                "https://static.pexels.com/photos/213384/pexels-photo-213384-medium.jpeg",
                "https://static.pexels.com/photos/67442/pexels-photo-67442-medium.jpeg",
                "https://static.pexels.com/photos/159494/book-glasses-read-study-159494-medium.jpeg",
                "https://static.pexels.com/photos/1543/landscape-nature-man-person-medium.jpg"
        };
        return urls;
    }

    public static String[] getHomeApplianceUrls() {
        String[] urls = new String[]{
                "https://static.pexels.com/photos/1778/numbers-time-watch-white-medium.jpg",
                "https://static.pexels.com/photos/189293/pexels-photo-189293-medium.jpeg",
                "https://static.pexels.com/photos/4703/inside-apartment-design-home-medium.jpg",
                "https://static.pexels.com/photos/133919/pexels-photo-133919-medium.jpeg",
                "https://static.pexels.com/photos/111147/pexels-photo-111147-medium.jpeg",
                "https://static.pexels.com/photos/2713/wall-home-deer-medium.jpg",
                "https://static.pexels.com/photos/177143/pexels-photo-177143-medium.jpeg",
                "https://static.pexels.com/photos/106936/pexels-photo-106936-medium.jpeg",
                "https://static.pexels.com/photos/1778/numbers-time-watch-white-medium.jpg",
                "https://static.pexels.com/photos/189293/pexels-photo-189293-medium.jpeg"

        };
        return urls;
    }

    public static String[] getElectronicsUrls() {
        String[] urls = new String[]{
                "https://static.pexels.com/photos/204611/pexels-photo-204611-medium.jpeg",
                "https://static.pexels.com/photos/214487/pexels-photo-214487-medium.jpeg",
                "https://static.pexels.com/photos/168575/pexels-photo-168575-medium.jpeg",
                "https://static.pexels.com/photos/213384/pexels-photo-213384-medium.jpeg",
                "https://static.pexels.com/photos/114907/pexels-photo-114907-medium.jpeg",
                "https://static.pexels.com/photos/185030/pexels-photo-185030-medium.jpeg",
                "https://static.pexels.com/photos/133579/pexels-photo-133579-medium.jpeg",
                "https://static.pexels.com/photos/51383/photo-camera-subject-photographer-51383-medium.jpeg",
                "https://static.pexels.com/photos/205926/pexels-photo-205926-medium.jpeg",
                "https://static.pexels.com/photos/2396/light-glass-lamp-idea-medium.jpg"

        };
        return urls;
    }






    public static String[] getLifeStyleUrls() {
        String[] urls = new String[]{
                "https://static.pexels.com/photos/169047/pexels-photo-169047-medium.jpeg",
                "https://static.pexels.com/photos/160826/girl-dress-bounce-nature-160826-medium.jpeg",
                "https://static.pexels.com/photos/1702/bow-tie-businessman-fashion-man-medium.jpg",
                "https://static.pexels.com/photos/35188/child-childrens-baby-children-s-medium.jpg",
                "https://static.pexels.com/photos/70845/girl-model-pretty-portrait-70845-medium.jpeg",
                "https://static.pexels.com/photos/26378/pexels-photo-26378-medium.jpg",
                "https://static.pexels.com/photos/193355/pexels-photo-193355-medium.jpeg",
                "https://static.pexels.com/photos/1543/landscape-nature-man-person-medium.jpg",
                "https://static.pexels.com/photos/211048/pexels-photo-211048-medium.jpeg",
                "https://static.pexels.com/photos/189857/pexels-photo-189857-medium.jpeg"

        };
        return urls;
    }

    public static String[] getBooksUrls() {
        String[] urls = new String[]{
                "https://static.pexels.com/photos/67442/pexels-photo-67442-medium.jpeg",
                "https://static.pexels.com/photos/159494/book-glasses-read-study-159494-medium.jpeg",
                "https://static.pexels.com/photos/33283/stack-of-books-vintage-books-book-books-medium.jpg",
                "https://static.pexels.com/photos/205323/pexels-photo-205323-medium.png",
                "https://static.pexels.com/photos/38167/pexels-photo-38167-medium.jpeg",
                "https://static.pexels.com/photos/68562/pexels-photo-68562-medium.jpeg",
                "https://static.pexels.com/photos/34592/pexels-photo-medium.jpg",
                "https://static.pexels.com/photos/1579/hand-notes-holding-things-medium.jpg",
                "https://static.pexels.com/photos/26890/pexels-photo-26890-medium.jpg",
                "https://static.pexels.com/photos/67442/pexels-photo-67442-medium.jpeg"

        };
        return urls;
    }

    public void addWishlistImageUri(String wishlistImageUri) {
        this.wishlistImageUri.add(0,wishlistImageUri);
    }

    public void removeWishlistImageUri(int position) {
        this.wishlistImageUri.remove(position);
    }

    public ArrayList<String> getWishlistImageUri(){ return this.wishlistImageUri; }

    public void addCartListImageUri(String wishlistImageUri) {
        this.cartListImageUri.add(0,wishlistImageUri);
    }

    public void removeCartListImageUri(int position) {
        this.cartListImageUri.remove(position);
    }

    public ArrayList<String> getCartListImageUri(){ return this.cartListImageUri; }
}
