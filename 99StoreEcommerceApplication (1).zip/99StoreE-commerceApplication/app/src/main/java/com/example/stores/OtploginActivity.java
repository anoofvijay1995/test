package com.example.stores;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.hbb20.CountryCodePicker;

import java.util.concurrent.TimeUnit;

public class OtploginActivity extends AppCompatActivity {
    EditText phone,otp;
    Button btngenOTP,btnverify;
    FirebaseAuth mAuth;
    CountryCodePicker countryCodePicker;
    String verificationID;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otplogin);
        phone=findViewById(R.id.Mobile);
        otp =findViewById(R.id.otpverify);
        btngenOTP= findViewById(R.id.btn_continue);
        btnverify=findViewById(R.id.btn_verify);
        mAuth = FirebaseAuth.getInstance();
        countryCodePicker =findViewById(R.id.countyCodePicker);
        btngenOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String number = null;
                if (TextUtils.isEmpty(phone.getText().toString())) {
                    Toast.makeText(OtploginActivity.this, "Enter Valid Phone Number", Toast.LENGTH_SHORT).show();
                }
                number = phone.getText().toString();
                sendverificationcode(number);
            }
        });
        btnverify.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SuspiciousIndentation")
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(otp.getText().toString())) {
                    Toast.makeText(OtploginActivity.this, "Wrong otp entered", Toast.LENGTH_SHORT).show();
                }
                else
                    verifycode(otp.getText().toString());
            }
        });
    }
    private void sendverificationcode(String phoneNumber) {
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber("+91"+ phoneNumber)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(mCallbacks)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
    }
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallbacks =new  PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void  onVerificationCompleted(@NonNull PhoneAuthCredential credential) {
            final String code = credential.getSmsCode();
            if(code!=null)
            {
                verifycode(code);
            }
        }
        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {
            Toast.makeText(OtploginActivity.this, "Verification failed", Toast.LENGTH_SHORT).show();
        }
        @Override

        public void onCodeSent(
                @NonNull String s,
                @NonNull PhoneAuthProvider.ForceResendingToken token)
        {
            super.onCodeSent(s,token);
            verificationID =s;

        }
    };

    private void verifycode(String Code) {
        PhoneAuthCredential credential =PhoneAuthProvider.getCredential(verificationID,Code);
        signinbyCredentials(credential);
    }


    private void signinbyCredentials(PhoneAuthCredential credential) {
        FirebaseAuth firebaseAuth =FirebaseAuth.getInstance();
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        {
                            if(task.isSuccessful())
                            {
                                Toast.makeText(OtploginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                            }
                        }

                    };

                });
        ;}

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser =FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser!=null)
        {
            startActivity(new Intent(OtploginActivity.this,LogOutActivity.class));
            finish();
        }
    }
}



