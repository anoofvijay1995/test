package com.example.stores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class ProductsImagesAdapter extends RecyclerView.Adapter<ProductsImagesAdapter.imageViewHolder> {

    Context context;

    Adapter adapter;

    private final List<StoreFragment> storeFragments = new ArrayList<>();
    StoreFragment fragment;
    ArrayList<ProductImages>ProductsImagesArrayList;

    public ProductsImagesAdapter(Context context, ArrayList<ProductImages> productImagesArrayList, StoreFragment fragment) {
        this.context = context;
        this.fragment = fragment;
        this.ProductsImagesArrayList = productImagesArrayList;
    }

    @NonNull
    @Override
    public imageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

//        View view = LayoutInflater.from(context).inflate(R.layout.product_support_layout,parent,false);

        View inflatedView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_support_layout, parent, false);

        return new imageViewHolder(inflatedView);


    }

    @Override
    public void onBindViewHolder(@NonNull imageViewHolder holder, int position) {
        ProductImages productImages = ProductsImagesArrayList.get(position);
        holder.productName.setText(productImages.getProductName());
        holder.productPrice.setText(productImages.getProductPrice());

        String imgurl;
        imgurl=productImages.getImage();
        Picasso.get().load(imgurl).into(holder.productImage);

    }

    @Override
    public int getItemCount() {
        this.fragment = fragment;
        return ProductsImagesArrayList.size();
    }

    public class imageViewHolder extends RecyclerView.ViewHolder{

        ImageView productImage;
        TextView productName;
        TextView productPrice;
        public imageViewHolder(@NonNull View itemView) {
            super(itemView);

            productImage= itemView.findViewById(R.id.productImage);
            productName=itemView.findViewById(R.id.productName);
            productPrice=itemView.findViewById(R.id.productPrice);
        }
    }
}
