package com.example.stores;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.stores.Adapter.BestSellerAdapter;
import com.example.stores.Adapter.ClothingAdapter;
import com.example.stores.Adapter.OfferAdapter;
import com.example.stores.Adapter.The_Slide_items_Pager_Adapter;
import com.example.stores.Model.BestSeller;
import com.example.stores.Model.Clothing;
import com.example.stores.Model.The_Slide_Items_Model_Class;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.TimerTask;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    Context context;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    //        THIS IS PRODUCT PART DECLARATION
    RecyclerView recyclerView2;
    ProductsImagesAdapter adapter2;
    ArrayList<ProductImages> productImagesArrayList;

    //    RECYLERVIEWS
    private RecyclerView offerRecyclerView, bestSellerRecyclerView, clothingRecyclerView, bestSellerRecyclerView2;

    private List<The_Slide_Items_Model_Class> listItems;

    private ViewPager page;
    LinearLayout
            linearLayout1,linearLayout2, linearLayout3, linearLayout4, linearLayout5, linearLayout6, linearLayout7, linearLayout8, linearLayout9, linearLayout10,
            linearLayout11, linearLayout12, linearLayout13, linearLayout14, linearLayout15, linearLayout16, linearLayout17, linearLayout18, linearLayout19, linearLayout20;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);


        }
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view;
        view = inflater.inflate(R.layout.fragment_home2, null);
        linearLayout1 = view.findViewById(R.id.viewMoviesIcon);
        linearLayout2 = view.findViewById(R.id.viewSportsIcon);
        linearLayout3 = view.findViewById(R.id.viewMusicIcon);
        linearLayout4 = view.findViewById(R.id.viewActivitiesIcon);
        linearLayout5 = view.findViewById(R.id.viewseeIcon);
        linearLayout6 = view.findViewById(R.id.foot);
        linearLayout7 = view.findViewById(R.id.watch);
        linearLayout8 = view.findViewById(R.id.sports);

        linearLayout9 = view.findViewById(R.id.viewMoviesIcon2);
        linearLayout10 = view.findViewById(R.id.viewSportsIcon2);
        linearLayout11 = view.findViewById(R.id.viewMusicIcon2);
        linearLayout12 = view.findViewById(R.id.viewActivitiesIcon2);
        linearLayout13 = view.findViewById(R.id.viewseeIcon2);
        linearLayout14 = view.findViewById(R.id.foot2);
        linearLayout15 = view.findViewById(R.id.watch2);
        linearLayout16 = view.findViewById(R.id.sports2);
        linearLayout17 = view.findViewById(R.id.HomeCeremony);
        linearLayout18 = view.findViewById(R.id.BirthdayCeremony);
        linearLayout19 = view.findViewById(R.id.MarriagesCeremony);



        recyclerView2= view.findViewById(R.id.recyclerView2);


        CardView cardView;

        cardView= view.findViewById(R.id.cardView2);
        //offer RecyclerView

        offerRecyclerView = view.findViewById(R.id.offerRecyclerView);
        page = view.findViewById(R.id.my_pager);

        context = view.getContext();

        listItems = new ArrayList<>();
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner1, "Slider 1 Title"));
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner2, "Slider 2 Title"));
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner3, "Slider 3 Title"));
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner5, "Slider 4 Title"));
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner7, "Slider 5 Title"));
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner9, "Slider 6 Title"));
        listItems.add(new The_Slide_Items_Model_Class(R.drawable.banner10, "Slider 7 Title"));

        The_Slide_items_Pager_Adapter itemsPager_adapter = new The_Slide_items_Pager_Adapter(context, listItems);
        page.setAdapter(itemsPager_adapter);

//        The_slide_timer
        java.util.Timer timer = new java.util.Timer();
        timer.scheduleAtFixedRate(new The_slide_timer(), 2000, 3000);


        offerRecyclerView.setHasFixedSize(true);
        offerRecyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));

        //Nikon canon recycler view

        List<Integer> imageList = new ArrayList<>();

        imageList.add(R.drawable.offer_shoping);
        imageList.add(R.drawable.nikon_canon_offer);
        imageList.add(R.drawable.tv_offer);

        OfferAdapter offerAdapter = new OfferAdapter(imageList);

        offerRecyclerView.setAdapter(offerAdapter);


        // best RecyclerView

        bestSellerRecyclerView = view.findViewById(R.id.bestSellerRecyclerview);
        bestSellerRecyclerView.setHasFixedSize(true);
        bestSellerRecyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));



        // clothing RecyclerView

        clothingRecyclerView = view.findViewById(R.id.clothingRecyclerview);
        clothingRecyclerView.setHasFixedSize(true);
        clothingRecyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));

        List<Clothing> clothingList = new ArrayList<>();

        clothingList.add(new Clothing(R.drawable.levis_clothing, "Up to 30% off"));
        clothingList.add(new Clothing(R.drawable.women_clothing, "Up to 30% off"));
        clothingList.add(new Clothing(R.drawable.nikeshoes, "Up to 30% off"));

        ClothingAdapter clothingAdapter = new ClothingAdapter(clothingList);
        clothingRecyclerView.setAdapter(clothingAdapter);

        // best RecyclerView 2

        bestSellerRecyclerView2 = view.findViewById(R.id.bestSeller2RecyclerView);
        bestSellerRecyclerView2.setHasFixedSize(true);
        bestSellerRecyclerView2.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
        List<BestSeller> bestSellerList = new ArrayList<>();

        bestSellerList.add(new BestSeller("Up to 20% off", "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Electronics+and+gadgets.png/e3.png"));
        bestSellerList.add(new BestSeller("Up to 20% off", "https://i.pinimg.com/originals/2a/5f/21/2a5f21482c482d271977ac0bf2da371d.jpg"));
        bestSellerList.add(new BestSeller("Up to 20% off", "https://images010.s3.ap-south-1.amazonaws.com/Cat+A/Sport/s2.png"));

        BestSellerAdapter bestSellerAdapter = new BestSellerAdapter(bestSellerList);

        bestSellerRecyclerView.setAdapter(bestSellerAdapter);

        bestSellerRecyclerView2.setAdapter(bestSellerAdapter);



        //LINEAR LAYOUT


        linearLayout1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(context, GroceryActivity.class));
            }
        });


        linearLayout2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, EletronicGadgetsActivity.class));
            }
        });


        linearLayout3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, ClothingActivity.class));
            }
        });


        linearLayout4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, HomeAppliances.class));
            }
        });


        linearLayout5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, ToysActivity.class));
            }
        });


        linearLayout6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, FootWearActivity.class));
            }
        });


        linearLayout7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, WatchesAndBagssActivity.class));
            }
        });


        linearLayout8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, SportsActivity.class));
            }
        });


        //CATEGORY B


        linearLayout9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, PaintingServicesActivity.class));
            }
        });

        linearLayout10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, CarpenterServicesActivity.class));
            }
        });

        linearLayout11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context,PlumbingServicesActivity.class));
            }
        });

        linearLayout12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, ElectricServicesActivity.class));
            }
        });

        linearLayout13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, CLeaningServicesActivity.class));
            }
        });

        linearLayout14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, CivilWorkServicesActivity.class));
            }
        });

        linearLayout15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, LandSalesActivity.class));
            }
        });


        linearLayout16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, RentsActivity.class));
            }
        });


        linearLayout17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, HomeCeremonyActivity.class));
            }
        });


        linearLayout18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, BirthdayCeremonyActivity.class));
            }
        });


        linearLayout19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(context, MarraigeActivity.class));
            }
        });








        return view;

    }

    private class The_slide_timer extends TimerTask {
        @Override
        public void run() {
            Activity activity = getActivity();
            if (activity != null) {
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (page.getCurrentItem() < listItems.size() - 1) {
                            page.setCurrentItem(page.getCurrentItem() + 1);
                        } else
                            page.setCurrentItem(0);
                    }
                });
            }
        }


    }


}

