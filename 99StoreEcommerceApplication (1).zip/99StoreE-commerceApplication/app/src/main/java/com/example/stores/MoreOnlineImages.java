package com.example.stores;

public class MoreOnlineImages {

    String moreImage,moreTitle;

    public MoreOnlineImages(String moreImage, String moreTitle) {
        this.moreImage = moreImage;
        this.moreTitle = moreTitle;
    }

    public String getMoreImage() {
        return moreImage;
    }

    public void setMoreImage(String moreImage) {
        this.moreImage = moreImage;
    }

    public String getMoreTitle() {
        return moreTitle;
    }

    public void setMoreTitle(String moreTitle) {
        this.moreTitle = moreTitle;
    }
}
